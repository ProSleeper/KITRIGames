#include "stdafx.h"
#include "FrameManager.h"


FrameManager::FrameManager()
	: m_dwDeltaTime(0)
	, m_dwFPS(0)
	, m_dwFPSCount(0)
	, m_dwOldFPS(0)
	, m_OldDeltaTime(0)
{
	m_dwOldFPS = m_OldDeltaTime = GetTickCount();
}


FrameManager::~FrameManager()
{
}

void FrameManager::Update(void)
{
	DWORD dwCurrTime = GetTickCount();

	m_dwDeltaTime = dwCurrTime - m_OldDeltaTime;

	m_OldDeltaTime = dwCurrTime;

	//  fps
	m_dwFPSCount++;
	if (dwCurrTime >= m_dwOldFPS + 1000)
	{
		m_dwOldFPS = dwCurrTime;
		m_dwFPS = m_dwFPSCount;
		m_dwFPSCount = 0;
	}
}
