#pragma once
class Rect;
class Player
{
	D3DXVECTOR3			m_vOrgBulletPos;

	PROPERTY_FUNC(Rect*, Target, m_pRect);
	float		m_fRadius;

	LPD3DXMESH			m_pCullSphere;

	// ��ֶ���
	D3DFVF_XYZ_COLOR	m_arrNormalLine[2];

	/// �÷��̾�
	D3DFVF_XYZ_COLOR	m_arrVertexs[3];

	PROPERTY_FUNC(D3DXVECTOR3, Pos, m_vPos);
	D3DXVECTOR3			m_vRot;
	D3DXVECTOR3			m_vScale;
	PROPERTY_FUNC(D3DXVECTOR3, Dir,	m_vDir);
	D3DXVECTOR3			m_vOrgDir;


	D3DXMATRIX			m_mTM;
	D3DXMATRIX			m_mInvTM;
	D3DXMATRIX			m_mTrans;
	D3DXMATRIX			m_mRot;
	D3DXMATRIX			m_mScale;

public:
	void Init(void);
	void Update(float dTime);
	void Render(void);
	void Release(void);

public:
	Player();
	virtual ~Player();
};

