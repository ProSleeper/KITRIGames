#include "stdafx.h"
#include "myTexture.h"
#include "baseUIControl.h"
#include "UIImage.h"


void UIImage::Init(int _x, int _y, string texName)
{
	if (texName.empty() == false)
	{
		m_pTexture = TEXMGR->GetTexture(texName);
	}

	baseUIControl::Init(_x, _y,
		m_pTexture->GetWidth(), m_pTexture->GetHight());
}

void UIImage::Render(void)
{
	if (m_bIsVisible == false) return;

	SPRITE->Begin(D3DXSPRITE_ALPHABLEND);
	{
		RECT rc;
		SetRect(&rc, 0, 0, m_nWidth, m_nHeight);
		SPRITE->SetTransform(&m_mTM);

		SPRITE->Draw(m_pTexture ? m_pTexture->GetTexture()
			: NULL, &rc,
			&D3DXVECTOR3(0, 0, 0),
			&D3DXVECTOR3(0, 0, 0),
			D3DXCOLOR(1, 1, 1, 1));
	}
	SPRITE->End();

	baseUIControl::Render();
}

UIImage::UIImage()
	: m_pTexture(NULL)
{
	m_strName = "UIImage";
}


UIImage::~UIImage()
{
}
