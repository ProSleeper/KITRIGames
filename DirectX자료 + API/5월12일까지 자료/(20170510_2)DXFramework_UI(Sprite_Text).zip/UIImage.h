#pragma once
class myTexture;
class UIImage : public baseUIControl
{
	myTexture*			m_pTexture;

public:
	void Init(int _x, int _y, string texName);
	void Render(void);

public:
	UIImage();
	virtual ~UIImage();
};

