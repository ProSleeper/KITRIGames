#pragma once

enum enButtonState { BS_NORMAL, BS_OVER,
					BS_DOWN, BS_MAX };


class baseUIDialog;
class UIButton : public baseUIControl
{
	enButtonState			m_enButtonState;
	myTexture*				m_pTexture[BS_MAX];
	void					(*m_pDelegateFunc)
		(baseUIDialog* pDlg, baseUIControl* pControl);

public:
	void Init(int _x, int _y,
		string nor, string over, string down);
	void Render(void);

	void OnMouseMove(int mouseX, int kmouseY);
	void OnLButtonDown(int mouseX, int kmouseY);
	void OnLButtonUp(int mouseX, int kmouseY);

	void SetDelegateFunc(void(*Func)(baseUIDialog* pDlg, baseUIControl* pControl))
	{
		m_pDelegateFunc = Func;
	}

public:
	UIButton();
	virtual ~UIButton();
};

