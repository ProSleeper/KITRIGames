#pragma once

#define FONTMGR FontManager::GetInstance()

enum FONTTYPE { FT_DEFAULT, FT_BOADER, FT_BUTTON };

class FontManager
{
	SINGLETONE(FontManager);

	map<FONTTYPE, LPD3DXFONT>	m_mapFonts;

	GETTER(LPD3DXFONT, Font, m_pFont);

public:
	void Setup(void);
	void DrawText(int _x, int _y, D3DXCOLOR _color,
		char* msg, ...);
	void Release(void);

	LPD3DXFONT GetFonts(FONTTYPE enType);
};

