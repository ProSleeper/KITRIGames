#include "stdafx.h"
#include "Direct3DManager.h"


Direct3DManager::Direct3DManager()
	: m_pD3D(NULL)
	, m_pDevice(NULL)
	, m_hWnd(NULL)
	, m_nWidth(0)
	, m_nHeight(0)
{
}


Direct3DManager::~Direct3DManager()
{
	Destroy();
}

void Direct3DManager::Setup(void)
{
	m_nWidth = WINDOW_WIDTH;
	m_nHeight = WINDOW_HEIGHT;

	// d3d��ü ����
	m_pD3D = Direct3DCreate9(D3D_SDK_VERSION);

	if (m_pD3D)
	{
		D3DPRESENT_PARAMETERS d3dpp;
		ZeroMemory(&d3dpp, sizeof(d3dpp));

		d3dpp.BackBufferWidth = m_nWidth;
		d3dpp.BackBufferHeight = m_nHeight;
		d3dpp.BackBufferCount = 1;
		d3dpp.Windowed = true;
		d3dpp.BackBufferFormat = D3DFMT_A8R8G8B8;
		d3dpp.SwapEffect = D3DSWAPEFFECT_DISCARD;
		d3dpp.EnableAutoDepthStencil = true;
		d3dpp.AutoDepthStencilFormat = D3DFMT_D24X8;
		d3dpp.PresentationInterval =
			D3DPRESENT_INTERVAL_DEFAULT;

		//����̽� ����
		m_pD3D->CreateDevice(D3DADAPTER_DEFAULT,
			D3DDEVTYPE_HAL, m_hWnd,
			D3DCREATE_HARDWARE_VERTEXPROCESSING,
			&d3dpp, &m_pDevice);

		if (m_pDevice == NULL)
		{
			MessageBox(NULL, "����̽���������",
				"ERROR", MB_OK);
		}
	}
}

void Direct3DManager::Destroy(void)
{
	SAFE_RELEASE(m_pDevice);
	SAFE_RELEASE(m_pD3D);
}
