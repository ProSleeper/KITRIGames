#pragma once
class Player
{
	// ��ֶ���
	D3DFVF_XYZ_COLOR	m_arrNormalLine[2];

	/// �÷��̾�
	D3DFVF_XYZ_COLOR	m_arrVertexs[3];

	D3DXVECTOR3			m_vPos;
	D3DXVECTOR3			m_vRot;
	D3DXVECTOR3			m_vScale;
	D3DXVECTOR3			m_vDir;
	D3DXVECTOR3			m_vOrgDir;


	D3DXMATRIX			m_mTM;
	D3DXMATRIX			m_mTrans;
	D3DXMATRIX			m_mRot;
	D3DXMATRIX			m_mScale;

public:
	void Init(void);
	void Update(float dTime);
	void Render(void);
	void Release(void);

public:
	Player();
	virtual ~Player();
};

