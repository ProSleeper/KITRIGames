#include "stdafx.h"
#include "Player.h"


void Player::Init(void)
{
	m_arrVertexs[0].vPos = D3DXVECTOR3(-1, 0, 0);
	m_arrVertexs[0].color = D3DXCOLOR(1, 0, 0, 1);

	m_arrVertexs[1].vPos = D3DXVECTOR3(0, 1, 0);
	m_arrVertexs[1].color = D3DXCOLOR(0, 1, 0, 1);

	m_arrVertexs[2].vPos = D3DXVECTOR3(1, 0, 0);
	m_arrVertexs[2].color = D3DXCOLOR(0, 0, 1, 1);
}

void Player::Update(void)
{
}

void Player::Render(void)
{
	DEVICE->SetRenderState(D3DRS_LIGHTING, false);
	DEVICE->SetFVF(D3DFVF_XYZ_COLOR::FVF);
	DEVICE->DrawPrimitiveUP(
		D3DPT_TRIANGLELIST,		// �׸��¹��
		1,						// �ﰢ�� ����
		&m_arrVertexs,			// ���ؽ� ����
		sizeof(D3DFVF_XYZ_COLOR)// �������� ������
	);
}

void Player::Release(void)
{
}

Player::Player()
{
}


Player::~Player()
{
}

