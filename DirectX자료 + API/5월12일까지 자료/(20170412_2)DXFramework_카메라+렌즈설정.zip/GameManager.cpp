#include "stdafx.h"
#include "Player.h"
#include "GameManager.h"


GameManager::GameManager()
	: m_pPlayer(NULL)
{
	D3DXMatrixIdentity(&m_mView);
	D3DXMatrixIdentity(&m_mProj);
}


GameManager::~GameManager()
{
	Release();
}

void GameManager::Setup(void)
{
	DXMGR->Setup();

	// ī�޶� ���� //
	D3DXMatrixLookAtLH(&m_mView,
		&D3DXVECTOR3(0, 5, -5),		// ī�޶� ��ġ
		&D3DXVECTOR3(0, 0, 0),			// ī�޶� ���� ����
		&D3DXVECTOR3(0, 1, 0));			// ī�޶� ������
	DEVICE->SetTransform(D3DTS_VIEW, &m_mView);

	// ���� ���� //
	D3DXMatrixPerspectiveFovLH(&m_mProj,
		D3DX_PI / 4,			// y�� ����
		(float)DXMGR->GetWidth() / DXMGR->GetHeight(), //ȭ�����
		0.1f, 1000.0f
	);
	DEVICE->SetTransform(D3DTS_PROJECTION, &m_mProj);

	m_pPlayer = new Player;
	m_pPlayer->Init();
}

void GameManager::GameLoop(void)
{
	Update();
	Render();
}

void GameManager::Update(void)
{
}

void GameManager::Render(void)
{
	DEVICE->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,
					D3DXCOLOR(0.6f, 0.6f, 0.6f, 1), 1, 0);

	DEVICE->BeginScene();
	{
		// �Ʒ����� �׸���
		m_pPlayer->Render();
	}
	DEVICE->EndScene();

	DEVICE->Present(NULL, NULL, NULL, NULL);
}

void GameManager::Release(void)
{
	SAFE_DELETE(m_pPlayer);
}

void GameManager::WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
}
