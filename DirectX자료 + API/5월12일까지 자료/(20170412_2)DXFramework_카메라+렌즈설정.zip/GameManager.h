#pragma once

#define GAMEMGR GameManager::GetInstance()

class Player;
class GameManager
{
	SINGLETONE(GameManager);

	// ī�޶� ���� //
	D3DXMATRIX		m_mView;
	D3DXMATRIX		m_mProj;


	// ������Ʈ  //
	Player*		m_pPlayer;

public:
	void Setup(void);
	void GameLoop(void);
	void Update(void);
	void Render(void);
	void Release(void);
	void WndProc(HWND hWnd, UINT message, 
		WPARAM wParam, LPARAM lParam);
};

