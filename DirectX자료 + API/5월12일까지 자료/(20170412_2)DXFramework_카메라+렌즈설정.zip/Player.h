#pragma once
class Player
{
	D3DFVF_XYZ_COLOR	m_arrVertexs[3];

public:
	void Init(void);
	void Update(void);
	void Render(void);
	void Release(void);

public:
	Player();
	virtual ~Player();
};

