#include "stdafx.h"
#include "Player.h"
#include "WorldAxis.h"
#include "WorldCamera.h"
#include "GameManager.h"


GameManager::GameManager()
	: m_pPlayer(NULL)
	, m_pCamera(NULL)
	, m_pAxis(NULL)
{
	
}


GameManager::~GameManager()
{
	Release();
}

void GameManager::Setup(void)
{
	DXMGR->Setup();
	INPUTMGR->SetUp();

	// ī�޶� �¾� //
	m_pCamera = new WorldCamera;
	m_pCamera->SetUp(D3DXVECTOR3(0, 5, -5));

	// ���� Ŭ���� //
	m_pAxis = new WorldAxis;
	m_pAxis->Setup();

	// ������Ʈ //
	m_pPlayer = new Player;
	m_pPlayer->Init();
}

void GameManager::GameLoop(void)
{
	Update();
	Render();
}

void GameManager::Update(void)
{
	INPUTMGR->Update();

	m_pPlayer->Update();
}

void GameManager::Render(void)
{
	DEVICE->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,
					D3DXCOLOR(0.6f, 0.6f, 0.6f, 1), 1, 0);

	DEVICE->BeginScene();
	{
		// �Ʒ����� �׸���
		m_pPlayer->Render();


		// ������Ʈ �ٱ׸��� ���� Ŭ���� �׸���
		m_pAxis->Render();
	}
	DEVICE->EndScene();

	DEVICE->Present(NULL, NULL, NULL, NULL);
}

void GameManager::Release(void)
{
	SAFE_DELETE(m_pPlayer);
	SAFE_DELETE(m_pCamera);
	SAFE_DELETE(m_pAxis);
}

void GameManager::WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	m_pCamera->WndProc(hWnd, message, wParam, lParam);
}
