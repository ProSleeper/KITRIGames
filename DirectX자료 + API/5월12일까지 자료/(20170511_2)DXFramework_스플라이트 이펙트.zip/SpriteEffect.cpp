#include "stdafx.h"
#include "myTexture.h"
#include "SpriteEffect.h"


void SpriteEffect::Init(SpriteEffectInfo _info)
{
	m_SpriteInfo = _info;
	m_pTexture = TEXMGR->GetTexture("explosion.png");

	// �� ���ö���Ʈ ������ ����
	m_nTotalSpriteCnt = m_SpriteInfo.spriteCntX *
						m_SpriteInfo.spriteCntY;

	//  ���ö���Ʈ �ϳ��� ���� �ð�
	m_fNextTime = m_SpriteInfo.totalTime /
					m_nTotalSpriteCnt;

	// �̵��ؾ��� uv
	m_fSpriteU = 1.0f / m_SpriteInfo.spriteCntX;
	m_fSpriteV = 1.0f / m_SpriteInfo.spriteCntY;

	// �ʱ� ���ö���Ʈ ����ð�
	m_fAddChangeTime = m_fNextTime;

	D3DFVF_XYZ_TEX1 vtxs[] =
	{
		{D3DXVECTOR3(-1, 1, 0), 0, 0},
		{ D3DXVECTOR3(1, 1, 0), m_fSpriteU, 0 },
		{ D3DXVECTOR3(-1, -1, 0), 0, m_fSpriteV },
		{ D3DXVECTOR3(1, -1, 0), m_fSpriteU, m_fSpriteV },
	};

	DEVICE->CreateVertexBuffer(sizeof(vtxs), 0,
		D3DFVF_XYZ_TEX1::FVF, D3DPOOL_DEFAULT, &m_pVB, NULL);

	void* pData = NULL;
	m_pVB->Lock(0, sizeof(vtxs), &pData, 0);
	memcpy(pData, vtxs, sizeof(vtxs));
	m_pVB->Unlock();
}

void SpriteEffect::Update(float dTime)
{
	m_fTotalCurrTime += dTime;

	if (m_fTotalCurrTime > m_SpriteInfo.totalTime)
	{
		if (m_SpriteInfo.bLoop)
		{
			m_fTotalCurrTime = 0;
			m_fAddChangeTime = m_fNextTime;
			m_nCurrTotalFrame = 0;
		}
		return;
	}

	if (m_fTotalCurrTime > m_fAddChangeTime)
	{
		m_fAddChangeTime += m_fNextTime;
		m_nCurrTotalFrame++;

		if (m_SpriteInfo.spriteCntY > 1)
		{
			m_nCurrYFrame = m_nCurrTotalFrame /
							m_SpriteInfo.spriteCntX;
		}

		m_nCurrXFrame = m_nCurrTotalFrame %
							m_SpriteInfo.spriteCntX;
	}

	m_mTexTransform._31 = m_nCurrXFrame * m_fSpriteU;
	m_mTexTransform._32 = m_nCurrYFrame * m_fSpriteV;

}

void SpriteEffect::Render(void)
{
	DEVICE->SetRenderState(D3DRS_ALPHABLENDENABLE, true);
	DEVICE->SetRenderState(D3DRS_SRCBLEND, 
						D3DBLEND_SRCALPHA);
	DEVICE->SetRenderState(D3DRS_DESTBLEND,
						 D3DBLEND_INVSRCALPHA);

	DEVICE->SetStreamSource(0, m_pVB, 0, 
				sizeof(D3DFVF_XYZ_TEX1));
	DEVICE->SetFVF(D3DFVF_XYZ_TEX1::FVF);
	DEVICE->SetTransform(D3DTS_WORLD, &m_mTM);
	DEVICE->SetTexture(0, m_pTexture->GetTexture());

	DEVICE->SetTransform(D3DTS_TEXTURE0, &m_mTexTransform);
	DEVICE->SetTextureStageState(0,
		D3DTSS_TEXTURETRANSFORMFLAGS, D3DTTFF_COUNT2);

	DEVICE->DrawPrimitive(D3DPT_TRIANGLESTRIP, 0, 2);
}

void SpriteEffect::Release(void)
{
	SAFE_RELEASE(m_pVB);
}

SpriteEffect::SpriteEffect()
	: m_pTexture(NULL)
	, m_pVB(NULL)
	, m_nTotalSpriteCnt(0)
	, m_fNextTime(0)
	, m_fSpriteU(0)
	, m_fSpriteV(0)
	, m_fAddChangeTime(0)
	, m_fTotalCurrTime(0)
	, m_nCurrTotalFrame(0)
	, m_nCurrXFrame(0)
	, m_nCurrYFrame(0)
{
	D3DXMatrixIdentity(&m_mTexTransform);
	D3DXMatrixIdentity(&m_mTM);
	ZeroMemory(&m_SpriteInfo, sizeof(m_SpriteInfo));
}


SpriteEffect::~SpriteEffect()
{
	Release();
}
