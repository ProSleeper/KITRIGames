#pragma once
class SpriteEffect
{
	D3DXMATRIX			m_mTM;
	D3DXMATRIX			m_mTexTransform;

	SpriteEffectInfo	m_SpriteInfo;
	myTexture*			m_pTexture;
	LPDIRECT3DVERTEXBUFFER9 m_pVB;

	int					m_nTotalSpriteCnt;
	float				m_fNextTime;
	float				m_fSpriteU;
	float				m_fSpriteV;
	float				m_fAddChangeTime;
	float				m_fTotalCurrTime;

	int					m_nCurrTotalFrame;
	int					m_nCurrXFrame;
	int					m_nCurrYFrame;

public:
	void Init(SpriteEffectInfo _info);
	void Update(float dTime);
	void Render(void);
	void Release(void);

public:
	SpriteEffect();
	virtual ~SpriteEffect();
};

