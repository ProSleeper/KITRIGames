#pragma once
class Player
{
	LPDIRECT3DVERTEXBUFFER9		m_pVB;

	// ��ֶ���
	D3DFVF_XYZ_COLOR	m_arrNormalLine[2];

	/// �÷��̾�
	D3DFVF_XYZ_COLOR	m_arrVertexs[3];

	PROPERTY_FUNC(D3DXVECTOR3, Pos, m_vPos);
	D3DXVECTOR3			m_vRot;
	D3DXVECTOR3			m_vScale;
	D3DXVECTOR3			m_vDir;
	D3DXVECTOR3			m_vOrgDir;


	D3DXMATRIX			m_mTM;
	D3DXMATRIX			m_mTrans;
	D3DXMATRIX			m_mRot;
	D3DXMATRIX			m_mScale;

public:
	void Init(void);
	void Update(float dTime);
	void Render(void);
	void Release(void);

public:
	Player();
	virtual ~Player();
};

