#include "stdafx.h"
#include "myTexture.h"
#include "Rect.h"


void Rect::Init(void)
{
	m_arrVertexs[0].vPos = D3DXVECTOR3(-1, 2, 0);
	m_arrVertexs[0].u = 0; m_arrVertexs[0].v = 0;
	m_arrVertexs[0].w0 = 1.0f;
	m_arrVertexs[0].w1 = 0;

	m_arrVertexs[1].vPos = D3DXVECTOR3( 1, 2, 0);
	m_arrVertexs[1].u = 1; m_arrVertexs[1].v = 0;
	m_arrVertexs[1].w0 = 1.0f;
	m_arrVertexs[1].w1 = 0;

	m_arrVertexs[2].vPos = D3DXVECTOR3(-1, 1, 0);
	m_arrVertexs[2].u = 0; m_arrVertexs[2].v = 0.5f;
	m_arrVertexs[2].w0 = 0.3f;
	m_arrVertexs[2].w1 = 0.4f;

	m_arrVertexs[3].vPos = D3DXVECTOR3( -1, 1, 0);
	m_arrVertexs[3].u = 0; m_arrVertexs[3].v = 0.5f;
	m_arrVertexs[3].w0 = 0.3f;
	m_arrVertexs[3].w1 = 0.4f;

	m_arrVertexs[4].vPos = D3DXVECTOR3(1, 2, 0);
	m_arrVertexs[4].u = 1;	m_arrVertexs[4].v = 0;
	m_arrVertexs[4].w0 = 1.0f;
	m_arrVertexs[4].w1 = 0;

	m_arrVertexs[5].vPos = D3DXVECTOR3(1, 1, 0);
	m_arrVertexs[5].u = 1;	m_arrVertexs[5].v = 0.5f;
	m_arrVertexs[5].w0 = 0.3f;
	m_arrVertexs[5].w1 = 0.4f;

	m_arrVertexs[6].vPos = D3DXVECTOR3(-1, 1, 0);
	m_arrVertexs[6].u = 0;	m_arrVertexs[6].v = 0.5f;
	m_arrVertexs[6].w0 = 0.3f;
	m_arrVertexs[6].w1 = 0.4f;

	m_arrVertexs[7].vPos = D3DXVECTOR3( 1, 1, 0);
	m_arrVertexs[7].u = 1;	m_arrVertexs[7].v = 0.5f;
	m_arrVertexs[7].w0 = 0.3f;
	m_arrVertexs[7].w1 = 0.4f;

	m_arrVertexs[8].vPos = D3DXVECTOR3(-1, 0, 0);
	m_arrVertexs[8].u = 0;	m_arrVertexs[8].v = 1;
	m_arrVertexs[8].w0 = 0;
	m_arrVertexs[8].w1 = 0;

	m_arrVertexs[9].vPos = D3DXVECTOR3(-1, 0, 0);
	m_arrVertexs[9].u = 0;	m_arrVertexs[9].v = 1;
	m_arrVertexs[9].w0 = 0;
	m_arrVertexs[9].w1 = 0;

	m_arrVertexs[10].vPos = D3DXVECTOR3(1, 1, 0);
	m_arrVertexs[10].u = 1;	m_arrVertexs[10].v = 0.5f;
	m_arrVertexs[10].w0 = 0.3f;
	m_arrVertexs[10].w1 = 0.4f;

	m_arrVertexs[11].vPos = D3DXVECTOR3(1, 0, 0);
	m_arrVertexs[11].u = 1;	m_arrVertexs[11].v = 1;
	m_arrVertexs[11].w0 = 0;
	m_arrVertexs[11].w1 = 0;

	//�޽�
	D3DXCreateSphere(DEVICE, m_fRadius, 10, 10, 
						&m_pCullSphere, NULL);

	m_pTexture = TEXMGR->GetTexture("texture.jpg");
}

void Rect::Update(float dTime)
{
	//m_vRot.y += D3DX_PI *dTime;

	D3DXMatrixTranslation(&m_mTrans, m_vPos.x, m_vPos.y,
		m_vPos.z);
	D3DXMatrixScaling(&m_mScale, m_vScale.x,
		m_vScale.y, m_vScale.z);
	D3DXMatrixRotationYawPitchRoll(&m_mRot,
		m_vRot.y, m_vRot.x, m_vRot.z);

	D3DXMATRIX mBillboard;
	D3DXMATRIX mView;
	DEVICE->GetTransform(D3DTS_VIEW, &mView);
	D3DXMatrixIdentity(&mBillboard);

	mBillboard._11 = mView._11;
	mBillboard._13 = mView._13;
	mBillboard._31 = mView._31;
	mBillboard._33 = mView._33;

	D3DXMatrixInverse(&mBillboard, 0, &mBillboard);

	m_mTM = m_mScale * m_mRot * m_mTrans;// *mBillboard;

	D3DXMatrixIdentity(&m_m0);
	D3DXMatrixIdentity(&m_m1);
	D3DXMatrixIdentity(&m_m2);

	static float angle1 = 0.0f;
	static float angle2 = 0.0f;

	angle1 += D3DX_PI * dTime;
	angle2 += D3DX_PI * 2 * dTime;

	float s1 = cosf(angle1);
	float s2 = cosf(angle2);

	D3DXMatrixTranslation(&m_m1, s1/5.0f, 0, 0);
	D3DXMatrixTranslation(&m_m2, 0, 0, s2 / 5.0f);
}

void Rect::Render(void)
{
	DEVICE->SetTransform(D3DTS_WORLD, &(m_mTM*m_m0));
	DEVICE->SetTransform(D3DTS_WORLD1, &(m_mTM*m_m1));
	DEVICE->SetTransform(D3DTS_WORLD2, &(m_mTM*m_m2));
	DEVICE->SetRenderState(D3DRS_VERTEXBLEND,
								D3DVBF_2WEIGHTS);

	DEVICE->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
	//DEVICE->SetTransform(D3DTS_WORLD, &m_mTM);

	DEVICE->SetRenderState(D3DRS_LIGHTING, false);
	DEVICE->SetFVF(D3DFVF_XYZ_WEIGHT_TEX1::FVF);

	DEVICE->SetTexture(0, m_pTexture->GetTexture());

	DEVICE->DrawPrimitiveUP(
		D3DPT_TRIANGLELIST,		// �׸��¹��
		4,						// �ﰢ�� ����
		&m_arrVertexs,			// ���ؽ� ����
		sizeof(D3DFVF_XYZ_WEIGHT_TEX1)// �������� ������
	);

	DEVICE->SetTexture(0, NULL);

	DEVICE->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);


	//�޽�
	m_mTM._42 = 1;
	DEVICE->SetTransform(D3DTS_WORLD, &m_mTM);
	DEVICE->SetRenderState(D3DRS_FILLMODE, D3DFILL_WIREFRAME);
	//m_pCullSphere->DrawSubset(0);
	DEVICE->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
}

void Rect::Release(void)
{
	SAFE_RELEASE(m_pCullSphere);
}

Rect::Rect()
	: m_vPos(3, 0, 0)
	, m_vRot(0, 0, 0)
	, m_vScale(1, 1, 1)
	, m_pCullSphere(NULL)
	, m_fRadius(1.0f)
	, m_pTexture(NULL)
{
	D3DXMatrixIdentity(&m_mTM);
	D3DXMatrixIdentity(&m_mTrans);
	D3DXMatrixIdentity(&m_mRot);
	D3DXMatrixIdentity(&m_mScale);
}


Rect::~Rect()
{
	Release();
}
