#pragma once
class myTexture;
class Rect
{
	D3DXMATRIX			m_m0;
	D3DXMATRIX			m_m1;
	D3DXMATRIX			m_m2;

	myTexture*			m_pTexture;
	LPD3DXMESH			m_pCullSphere;

	GETTER(float, Radius, m_fRadius);

	D3DFVF_XYZ_WEIGHT_TEX1			m_arrVertexs[12];

	PROPERTY_FUNC(D3DXVECTOR3, Pos, m_vPos);
	D3DXVECTOR3			m_vRot;
	D3DXVECTOR3			m_vScale;

	D3DXMATRIX			m_mTM;
	D3DXMATRIX			m_mTrans;
	D3DXMATRIX			m_mRot;
	D3DXMATRIX			m_mScale;

public:
	void Init(void);
	void Update(float dTime);
	void Render(void);
	void Release(void);
	 
public:
	Rect();
	virtual ~Rect();
};

