#pragma once

#define GAMEMGR GameManager::GetInstance()

class Player;
class WorldCamera;
class WorldAxis;
class WorldGrid;
class Rect;
class GameManager
{
	SINGLETONE(GameManager);

	// ī�޶� //
	WorldCamera*		m_pCamera;

	// ���� Ŭ���� //
	WorldAxis*			m_pAxis;
	WorldGrid*			m_pGrid;

	// ������Ʈ  //
	Player*		m_pPlayer;
	Rect*		m_pRect;

public:
	void Setup(void);
	void GameLoop(void);
	void Update(float dTime);
	void Render(void);
	void DrawDebugFont(void);
	void Release(void);
	void WndProc(HWND hWnd, UINT message, 
		WPARAM wParam, LPARAM lParam);
};

