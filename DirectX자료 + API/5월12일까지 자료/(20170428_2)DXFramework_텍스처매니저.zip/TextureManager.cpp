#include "stdafx.h"
#include "myTexture.h"
#include "TextureManager.h"


myTexture * TextureManager::GetTexture(string _Texname)
{
	if (m_mapTextures[_Texname] != NULL)
		return m_mapTextures[_Texname];

	myTexture* pTex = new myTexture;
	pTex->Init(_Texname);

	return (m_mapTextures[_Texname] = pTex);
}

void TextureManager::Release()
{
	for each(auto p in m_mapTextures)
	{
		SAFE_DELETE(p.second);
	}
	m_mapTextures.clear();
}

TextureManager::TextureManager()
{
	m_mapTextures.clear();
}


TextureManager::~TextureManager()
{
	Release();
}
