#include "stdafx.h"
#include "Player.h"
#include "WorldAxis.h"
#include "WorldCamera.h"
#include "WorldGrid.h"
#include "Rect.h"
#include "Terrain.h"
#include "GameManager.h"


GameManager::GameManager()
	: m_pPlayer(NULL)
	, m_pCamera(NULL)
	, m_pAxis(NULL)
	, m_pGrid(NULL)
	, m_pTerrain(NULL)
	, m_pRect(NULL)
	, m_bWire(false)
{
	
}


GameManager::~GameManager()
{
	Release();
}

void GameManager::Setup(void)
{
	DXMGR->Setup();
	INPUTMGR->SetUp();
	FONTMGR->Setup();

	// ī�޶� �¾� //
	m_pCamera = new WorldCamera;
	m_pCamera->SetUp(D3DXVECTOR3(0, 5, -5));

	// ���� Ŭ���� //
	m_pAxis = new WorldAxis;
	m_pAxis->Setup();
	m_pGrid = new WorldGrid;
	m_pGrid->Setup();

	// ������Ʈ //
	m_pPlayer = new Player;
	m_pPlayer->Init();

	m_pRect = new Rect;
	m_pRect->Init();

	m_pPlayer->SetTarget(m_pRect);

	m_pTerrain = new Terrain;
	m_pTerrain->Init(64);
}

void GameManager::GameLoop(void)
{
	FRAMEMGR->Update();

	float dTime = FRAMEMGR->GetDeltaTime();

	Update(dTime);
	Render();
}

void GameManager::Update(float dTime)
{
	INPUTMGR->Update();

	if (INPUTMGR->GetKeyDown(VK_F1))
	{
		m_bWire ^= true;
		
		DEVICE->SetRenderState(D3DRS_FILLMODE,
			m_bWire ? D3DFILL_WIREFRAME :
			D3DFILL_SOLID);
	}

	m_pPlayer->Update(dTime);
	m_pRect->Update(dTime);
	m_pTerrain->Update(dTime);
}

void GameManager::Render(void)
{
	DEVICE->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,
					D3DXCOLOR(0.6f, 0.6f, 0.6f, 1), 1, 0);

	DEVICE->BeginScene();
	{
		// �Ʒ����� �׸���
		//m_pPlayer->Render();
		m_pRect->Render();

		m_pTerrain->Render();

		// ������Ʈ �ٱ׸��� ���� Ŭ���� �׸���
		m_pGrid->Render();
		m_pAxis->Render();

		// ��Ʈ�� ���� ������
		DrawDebugFont();
	}
	DEVICE->EndScene();

	DEVICE->Present(NULL, NULL, NULL, NULL);
}

void GameManager::DrawDebugFont(void)
{
	int _x = 10;
	int _y = 10;

	D3DXCOLOR _color = D3DXCOLOR(0, 1, 0, 1);

	FONTMGR->DrawText(_x, _y, _color, "FPS : %d",
					FRAMEMGR->GetFPS());

	// ���ΰ� ����
	_y += 15;
	_color = D3DXCOLOR(1, 1, 0, 1);
	FONTMGR->DrawText(_x, _y+=15, _color, 
						"< ���ΰ� ���� >");
	FONTMGR->DrawText(_x, _y += 15, _color,
							"- ��Ʈ��(��,��,��,��)");
	FONTMGR->DrawText(_x, _y += 15, _color,
		"- Pos(%.2f, %.2f,%.2f)",
		m_pPlayer->GetPos().x, 
		m_pPlayer->GetPos().y,
		m_pPlayer->GetPos().z);

	
	FONTMGR->DrawText(_x, _y += 15, _color,
		"TEX Count : %d",
		TEXMGR->GetTextureCount());
}

void GameManager::Release(void)
{
	SAFE_DELETE(m_pPlayer);
	SAFE_DELETE(m_pCamera);
	SAFE_DELETE(m_pAxis);
	SAFE_DELETE(m_pRect);
}

void GameManager::WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	m_pCamera->WndProc(hWnd, message, wParam, lParam);
}
