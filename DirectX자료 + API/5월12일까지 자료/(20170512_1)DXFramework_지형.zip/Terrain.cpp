#include "stdafx.h"
#include "myTexture.h"
#include "Terrain.h"


void Terrain::Init(int tileCnt)
{
	InitVB(tileCnt);
	InitIB(tileCnt);

	m_pTexture = TEXMGR->GetTexture("Field1.dds");
}

void Terrain::InitVB(int tileCnt)
{
	m_nTotalVtxCnt = (tileCnt + 1)*(tileCnt + 1);

	m_pOrgVB = 
		new D3DFVF_XYZ_NORMAL_TEX1[m_nTotalVtxCnt];
	ZeroMemory(m_pOrgVB,
		sizeof(D3DFVF_XYZ_NORMAL_TEX1)*m_nTotalVtxCnt);

	int nStartX = -(tileCnt/2);
	int nStartZ =  (tileCnt/2);

	for (int z = 0; z < (tileCnt + 1); ++z)
	{
		for (int x = 0; x < (tileCnt + 1); ++x)
		{
			int idx = z * (tileCnt + 1) + x;

			m_pOrgVB[idx].vPos.x
				= nStartX + x;

			m_pOrgVB[idx].vPos.y = -0.01f;

			m_pOrgVB[idx].vPos.z
				= nStartZ - z;

			m_pOrgVB[idx].vNormal 
				= D3DXVECTOR3(0, 1, 0);

			m_pOrgVB[idx].u = x;
			m_pOrgVB[idx].v = z;
		}
	}

	DEVICE->CreateVertexBuffer(
		sizeof(D3DFVF_XYZ_NORMAL_TEX1)*m_nTotalVtxCnt,
		0, D3DFVF_XYZ_NORMAL_TEX1::FVF, D3DPOOL_DEFAULT,
		&m_pVB, NULL);

	void* pData = NULL;
	m_pVB->Lock(0,
		sizeof(D3DFVF_XYZ_NORMAL_TEX1)*m_nTotalVtxCnt,
		&pData, 0);

	memcpy(pData, m_pOrgVB,
		sizeof(D3DFVF_XYZ_NORMAL_TEX1)*m_nTotalVtxCnt);

	m_pVB->Unlock();
}

void Terrain::InitIB(int tileCnt)
{
	m_nTotalFaceCnt = tileCnt*tileCnt * 2;
	m_pOrgIB = new D3DINDEX[m_nTotalFaceCnt];
	int nSize = sizeof(D3DINDEX)*m_nTotalFaceCnt;
	ZeroMemory(m_pOrgIB, nSize);

	D3DINDEX* pIndex = m_pOrgIB;
	D3DINDEX  _IndexData;

	for (int z = 0; z < tileCnt; ++z)
	{
		for (int x = 0; x < tileCnt; ++x)
		{
			_IndexData._0 = z * (tileCnt + 1) + x;
			_IndexData._1 = _IndexData._0 + 1;
			_IndexData._2 = (z+1)*(tileCnt + 1) + x;

			*pIndex++ = _IndexData;

			_IndexData._0 = (z + 1)*(tileCnt + 1) + x;
			_IndexData._1 = z * (tileCnt + 1) + x + 1;
			_IndexData._2 = _IndexData._0 + 1;

			*pIndex++ = _IndexData;
		}
	}

	DEVICE->CreateIndexBuffer(nSize, 0,
		D3DFMT_INDEX32, D3DPOOL_DEFAULT,
		&m_pIB, NULL);

	void* pDtat = NULL;
	m_pIB->Lock(0, nSize, &pDtat, 0);
	memcpy(pDtat, m_pOrgIB, nSize);
	m_pIB->Unlock();
	
}

void Terrain::Update(float dTime)
{
}

void Terrain::Render(void)
{
	D3DXMATRIX m;
	D3DXMatrixIdentity(&m);
	DEVICE->SetTransform(D3DTS_WORLD, &m);

	DEVICE->SetStreamSource(0, m_pVB, 0,
		sizeof(D3DFVF_XYZ_NORMAL_TEX1));
	DEVICE->SetFVF(D3DFVF_XYZ_NORMAL_TEX1::FVF);
	
	DEVICE->SetTexture(0, 
		GAMEMGR->GetWire() ? NULL :
		m_pTexture->GetTexture());

	DEVICE->SetIndices(m_pIB);

	DEVICE->DrawIndexedPrimitive(D3DPT_TRIANGLELIST,
		0, 0, m_nTotalVtxCnt, 0, m_nTotalFaceCnt);
	DEVICE->SetTexture(0, NULL);
}

void Terrain::Release(void)
{
	SAFE_RELEASE(m_pIB);
	SAFE_RELEASE(m_pVB);
	SAFE_DELETE_ARRAY(m_pOrgVB);
	SAFE_DELETE_ARRAY(m_pOrgIB);
}

Terrain::Terrain()
	: m_pIB(NULL)
	, m_pOrgIB(NULL)
	, m_pOrgVB(NULL)
	, m_pVB(NULL)
	, m_pTexture(NULL)
	, m_nTotalFaceCnt(0)
	, m_nTotalVtxCnt(0)
{
}


Terrain::~Terrain()
{
	Release();
}
