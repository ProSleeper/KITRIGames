#pragma once
class Terrain
{
	LPDIRECT3DVERTEXBUFFER9		m_pVB;
	LPDIRECT3DINDEXBUFFER9		m_pIB;
	myTexture*					m_pTexture;

	D3DFVF_XYZ_NORMAL_TEX1*		m_pOrgVB;
	D3DINDEX*					m_pOrgIB;

	int							m_nTotalVtxCnt;
	int							m_nTotalFaceCnt;

public:
	void Init(int tileCnt);
	void InitVB(int tileCnt);
	void InitIB(int tileCnt);
	void Update(float dTime);
	void Render(void);
	void Release(void);

public:
	Terrain();
	virtual ~Terrain();
};

