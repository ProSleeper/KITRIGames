#include "stdafx.h"
#include "BoxMesh.h"


BoxMesh::BoxMesh()
	: m_vPos(0,0,0)
	, m_vRot(0,0,0)
	, m_vScale(1,1,1)
	, m_pParentTM(NULL)
	, m_pMesh(NULL)
	, m_vRePos(0,0,0)
{
	D3DXMatrixIdentity(&m_mTM);
	D3DXMatrixIdentity(&m_mTrans);
	D3DXMatrixIdentity(&m_mRot);
	D3DXMatrixIdentity(&m_mScale);
	D3DXMatrixIdentity(&m_mRePos);
}


BoxMesh::~BoxMesh()
{
	Release();
}

void BoxMesh::Init(float w, float h, float z)
{
	D3DXCreateBox(DEVICE, w, h, z, &m_pMesh, NULL);
}

void BoxMesh::Update(float dTime)
{
	D3DXMatrixTranslation(&m_mRePos,
		m_vRePos.x, m_vRePos.y, m_vRePos.z);
	D3DXMatrixTranslation(&m_mTrans,
		m_vPos.x, m_vPos.y, m_vPos.z);
	D3DXMatrixScaling(&m_mScale,
		m_vScale.x, m_vScale.y, m_vScale.z);
	D3DXMatrixRotationYawPitchRoll(&m_mRot,
		m_vRot.y, m_vRot.x, m_vRot.z);



	D3DXMatrixInverse(&m_mRePosInv, 0, &m_mRePos);

	if (m_pParentTM)
	{
		m_mTM = m_mScale * m_mRePos * m_mRot * m_mTrans * m_mRePosInv
			*(*m_pParentTM);
	}
	else
		m_mTM = m_mScale * m_mRot * m_mTrans;
}

void BoxMesh::Render(void)
{
	DEVICE->SetTransform(D3DTS_WORLD, &m_mTM);
	m_pMesh->DrawSubset(0);
}

void BoxMesh::Release(void)
{
	SAFE_RELEASE(m_pMesh);
}
