#pragma once
class BoxMesh
{
	PROPERTY_FUNC(D3DXVECTOR3, Pos, m_vPos);
	PROPERTY_FUNC(D3DXVECTOR3, RePos, m_vRePos);
	PROPERTY_FUNC(D3DXVECTOR3, Rot, m_vRot);
	PROPERTY_FUNC(D3DXVECTOR3, Scale, m_vScale);

	PROPERTY_FUNC(D3DXMATRIX*, ParentTM, m_pParentTM);
	GETTER(D3DXMATRIX, mTM, m_mTM);
	GETTER(D3DXMATRIX, mTrans, m_mTrans);
	GETTER(D3DXMATRIX, mRot, m_mRot);
	GETTER(D3DXMATRIX, mScale, m_mScale);
	GETTER(D3DXMATRIX, mRePos, m_mRePos);
	GETTER(D3DXMATRIX, mRePosInv, m_mRePosInv);

	GETTER(LPD3DXMESH,	Mesh, m_pMesh);

public:
	D3DXMATRIX* GetTMAddr(void)
	{
		return &m_mTM; 
	}

public:
	void Init(float w, float h, float z);
	void Update(float dTime);
	void Render(void);
	void Release(void);


public:
	BoxMesh();
	virtual ~BoxMesh();
};

