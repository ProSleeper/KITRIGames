#include "stdafx.h"
#include "myTexture.h"
#include "mouseRay.h"
#include "Terrain.h"


void Terrain::PickTerrain(int x, int y, bool up)
{
	mouseRay ray;
	ray.CreateRay(x, y);

	D3DXMATRIX mView;
	DEVICE->GetTransform(D3DTS_VIEW, &mView);
	ray.RayTransform(mView);

	D3DXVECTOR3 vPos[3];
	float fDis;

	for (int i = 0; i < m_nTotalFaceCnt; ++i)
	{
		D3DINDEX _currIdx = m_pOrgIB[i];

		vPos[0] = m_pOrgVB[_currIdx._0].vPos;
		vPos[1] = m_pOrgVB[_currIdx._1].vPos;
		vPos[2] = m_pOrgVB[_currIdx._2].vPos;

		if (D3DXIntersectTri(&vPos[0],
			&vPos[1], &vPos[2], &ray.Getpos(),
			&ray.Getdir(), NULL, NULL, &fDis))
		{
			m_PickIndexInfo = _currIdx;
			//UpdateTerrain(up);
			UPdateRectTerrain(up, i);
			break;
		}
	}
}

void Terrain::UpdateTerrain(bool up)
{
	D3DXVECTOR3 vUp(0, 0.1f, 0);
	if (up == false)
		vUp = -vUp;

	m_pOrgVB[m_PickIndexInfo._0].vPos += vUp;
	m_pOrgVB[m_PickIndexInfo._1].vPos += vUp;
	m_pOrgVB[m_PickIndexInfo._2].vPos += vUp;

	D3DFVF_XYZ_NORMAL_TEX1* pData = NULL;
	m_pVB->Lock(0,
		sizeof(D3DFVF_XYZ_NORMAL_TEX1)*m_nTotalVtxCnt,
		(void**)&pData, 0);
	pData[m_PickIndexInfo._0].vPos += vUp;
	pData[m_PickIndexInfo._1].vPos += vUp;
	pData[m_PickIndexInfo._2].vPos += vUp;
	m_pVB->Unlock();
}

void Terrain::UPdateRectTerrain(bool up, int idx)
{
	D3DXVECTOR3 vUp(0, 0.1f, 0);
	if (up == false)
		vUp = -vUp;

	int _PickX = (idx/2) % m_nTileSize;
	int _PickZ = (idx/2) / m_nTileSize;

	int nStartX = _PickX - (m_nPickSize / 2);
	int nStartZ = _PickZ - (m_nPickSize / 2);

	int pickIdx = 0;
	for (int z = 0; z < m_nPickSize; ++z)
	{
		for (int x = 0; x < m_nPickSize; ++x)
		{
			int idx = (nStartZ+ z) * m_nTileSize
						+ nStartX + x;
			idx = idx * 2;

			m_pPickIB[pickIdx++] = m_pOrgIB[idx];
			m_pPickIB[pickIdx++] = m_pOrgIB[idx+1];
		}
	}

	set<int> m_setIdx;
	for (int i = 0; i < m_nPickSize*m_nPickSize * 2; ++i)
	{
		D3DINDEX _index = m_pPickIB[i];
		m_setIdx.insert(_index._0);
		m_setIdx.insert(_index._1);
		m_setIdx.insert(_index._2);
	}

	D3DFVF_XYZ_NORMAL_TEX1* pData;
	m_pVB->Lock(0, sizeof(D3DFVF_XYZ_NORMAL_TEX1)
		* m_nTotalVtxCnt, (void**)&pData, 0);

	
	for each(auto p in m_setIdx)
	{
		m_pOrgVB[p].vPos += vUp;	
		pData[p].vPos += vUp;
	}
		

	m_pVB->Unlock();

	UpdateNormal();
}

void Terrain::UpdateNormal(void)
{
	D3DFVF_XYZ_NORMAL_TEX1* pData;
	m_pVB->Lock(0,
		sizeof(D3DFVF_XYZ_NORMAL_TEX1)*m_nTotalVtxCnt,
		(void**)&pData, 0);

	D3DXVECTOR3 vNormal;
	for (int i = 0; i < m_nTotalFaceCnt; ++i)
	{
		int _0 = m_pOrgIB[i]._0;
		int _1 = m_pOrgIB[i]._1;
		int _2 = m_pOrgIB[i]._2;

		D3DXVECTOR3 vTemp0
			= m_pOrgVB[_1].vPos - m_pOrgVB[_0].vPos;
		D3DXVECTOR3 vTemp1
			= m_pOrgVB[_2].vPos - m_pOrgVB[_0].vPos;

		D3DXVec3Cross(&vNormal, &vTemp0, &vTemp1);

		
		m_pOrgVB[_0].vNormal = m_pNormals[_0] + vNormal;
		m_pOrgVB[_1].vNormal = m_pNormals[_1] + vNormal;
		m_pOrgVB[_2].vNormal = m_pNormals[_2] + vNormal;

		D3DXVec3Normalize(&m_pOrgVB[_0].vNormal,
			&m_pOrgVB[_0].vNormal);
		D3DXVec3Normalize(&m_pOrgVB[_1].vNormal,
			&m_pOrgVB[_1].vNormal);
		D3DXVec3Normalize(&m_pOrgVB[_2].vNormal,
			&m_pOrgVB[_2].vNormal);

		pData[_0].vNormal = m_pOrgVB[_0].vNormal;
		pData[_1].vNormal = m_pOrgVB[_1].vNormal;
		pData[_2].vNormal = m_pOrgVB[_2].vNormal;
		
	}

	m_pVB->Unlock();
}

void Terrain::Init(int tileCnt, int pickSize)
{
	m_nTileSize = tileCnt;
	m_nPickSize = pickSize;
	m_pPickIB = new D3DINDEX[pickSize*pickSize*2];
	ZeroMemory(m_pPickIB, sizeof(D3DINDEX)
		*pickSize*pickSize * 2);

	InitVB(tileCnt);
	InitIB(tileCnt);

	m_pTexture = TEXMGR->GetTexture("Field1.dds");
}

void Terrain::InitVB(int tileCnt)
{
	m_nTotalVtxCnt = (tileCnt + 1)*(tileCnt + 1);

	m_pOrgVB = 
		new D3DFVF_XYZ_NORMAL_TEX1[m_nTotalVtxCnt];
	ZeroMemory(m_pOrgVB,
		sizeof(D3DFVF_XYZ_NORMAL_TEX1)*m_nTotalVtxCnt);

	m_pNormals = new D3DXVECTOR3[m_nTotalVtxCnt];
	ZeroMemory(m_pNormals, sizeof(D3DXVECTOR3)*m_nTotalVtxCnt);

	int nStartX = -(tileCnt/2);
	int nStartZ =  (tileCnt/2);

	for (int z = 0; z < (tileCnt + 1); ++z)
	{
		for (int x = 0; x < (tileCnt + 1); ++x)
		{
			int idx = z * (tileCnt + 1) + x;

			m_pOrgVB[idx].vPos.x
				= nStartX + x;

			m_pOrgVB[idx].vPos.y = -0.01f;

			m_pOrgVB[idx].vPos.z
				= nStartZ - z;

			m_pOrgVB[idx].vNormal 
				= D3DXVECTOR3(0, 1, 0);

			m_pNormals[idx] = D3DXVECTOR3(0, 1, 0);

			m_pOrgVB[idx].u = x;
			m_pOrgVB[idx].v = z;
		}
	}

	DEVICE->CreateVertexBuffer(
		sizeof(D3DFVF_XYZ_NORMAL_TEX1)*m_nTotalVtxCnt,
		0, D3DFVF_XYZ_NORMAL_TEX1::FVF, D3DPOOL_DEFAULT,
		&m_pVB, NULL);

	void* pData = NULL;
	m_pVB->Lock(0,
		sizeof(D3DFVF_XYZ_NORMAL_TEX1)*m_nTotalVtxCnt,
		&pData, 0);

	memcpy(pData, m_pOrgVB,
		sizeof(D3DFVF_XYZ_NORMAL_TEX1)*m_nTotalVtxCnt);

	m_pVB->Unlock();
}

void Terrain::InitIB(int tileCnt)
{
	m_nTotalFaceCnt = tileCnt*tileCnt * 2;
	m_pOrgIB = new D3DINDEX[m_nTotalFaceCnt];
	int nSize = sizeof(D3DINDEX)*m_nTotalFaceCnt;
	ZeroMemory(m_pOrgIB, nSize);

	D3DINDEX* pIndex = m_pOrgIB;
	D3DINDEX  _IndexData;

	for (int z = 0; z < tileCnt; ++z)
	{
		for (int x = 0; x < tileCnt; ++x)
		{
			_IndexData._0 = z * (tileCnt + 1) + x;
			_IndexData._1 = _IndexData._0 + 1;
			_IndexData._2 = (z+1)*(tileCnt + 1) + x;

			*pIndex++ = _IndexData;

			_IndexData._0 = (z + 1)*(tileCnt + 1) + x;
			_IndexData._1 = z * (tileCnt + 1) + x + 1;
			_IndexData._2 = _IndexData._0 + 1;

			*pIndex++ = _IndexData;
		}
	}

	DEVICE->CreateIndexBuffer(nSize, 0,
		D3DFMT_INDEX32, D3DPOOL_DEFAULT,
		&m_pIB, NULL);

	void* pDtat = NULL;
	m_pIB->Lock(0, nSize, &pDtat, 0);
	memcpy(pDtat, m_pOrgIB, nSize);
	m_pIB->Unlock();
	
}

void Terrain::Update(float dTime)
{
}

void Terrain::Render(void)
{
	D3DXMATRIX m;
	D3DXMatrixIdentity(&m);
	DEVICE->SetTransform(D3DTS_WORLD, &m);
	DEVICE->SetMaterial(&m_Material);
	DEVICE->SetStreamSource(0, m_pVB, 0,
		sizeof(D3DFVF_XYZ_NORMAL_TEX1));
	DEVICE->SetFVF(D3DFVF_XYZ_NORMAL_TEX1::FVF);
	
	DEVICE->SetTexture(0, 
		GAMEMGR->GetWire() ? NULL :
		m_pTexture->GetTexture());

	DEVICE->SetIndices(m_pIB);

	DEVICE->SetRenderState(D3DRS_LIGHTING, true);

	DEVICE->DrawIndexedPrimitive(D3DPT_TRIANGLELIST,
		0, 0, m_nTotalVtxCnt, 0, m_nTotalFaceCnt);
	DEVICE->SetTexture(0, NULL);
	DEVICE->SetRenderState(D3DRS_LIGHTING, false);
}

void Terrain::Release(void)
{
	SAFE_RELEASE(m_pIB);
	SAFE_RELEASE(m_pVB);
	SAFE_DELETE_ARRAY(m_pOrgVB);
	SAFE_DELETE_ARRAY(m_pOrgIB);
}

Terrain::Terrain()
	: m_pIB(NULL)
	, m_pOrgIB(NULL)
	, m_pOrgVB(NULL)
	, m_pVB(NULL)
	, m_pTexture(NULL)
	, m_nTotalFaceCnt(0)
	, m_nTotalVtxCnt(0)
{
	ZeroMemory(&m_PickIndexInfo, 
		sizeof(m_PickIndexInfo));
	ZeroMemory(&m_Material,
		sizeof(m_Material));

	m_Material.Diffuse = m_Material.Ambient
		= D3DXCOLOR(1, 1, 1, 1);
}


Terrain::~Terrain()
{
	Release();
}
