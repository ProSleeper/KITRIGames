#pragma once
class Terrain
{
	D3DMATERIAL9				m_Material;
	LPDIRECT3DVERTEXBUFFER9		m_pVB;
	LPDIRECT3DINDEXBUFFER9		m_pIB;
	myTexture*					m_pTexture;

	GETTER(D3DFVF_XYZ_NORMAL_TEX1*, orgVB, m_pOrgVB);
	GETTER(D3DINDEX*, orgIB, m_pOrgIB);
	
	int							m_nTotalVtxCnt;
	int							m_nTotalFaceCnt;

	GETTER(D3DINDEX, PickIndexInfo, m_PickIndexInfo);

	D3DINDEX* m_pPickIB;
	int		  m_nPickSize;
	int		  m_nTileSize;
	D3DXVECTOR3*		m_pNormals;

public:
	void PickTerrain(int x, int y, bool up);
	void UpdateTerrain(bool up);
	void UPdateRectTerrain(bool up, int idx);
	void UpdateNormal(void);

public:
	void Init(int tileCnt, int pickSize=3);
	void InitVB(int tileCnt);
	void InitIB(int tileCnt);
	void Update(float dTime);
	void Render(void);
	void Release(void);

public:
	Terrain();
	virtual ~Terrain();
};

