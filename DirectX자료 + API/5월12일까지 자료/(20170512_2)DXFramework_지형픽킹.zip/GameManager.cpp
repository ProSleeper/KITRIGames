#include "stdafx.h"
#include "Player.h"
#include "WorldAxis.h"
#include "WorldCamera.h"
#include "WorldGrid.h"
#include "Rect.h"
#include "Terrain.h"
#include "GameManager.h"


GameManager::GameManager()
	: m_pPlayer(NULL)
	, m_pCamera(NULL)
	, m_pAxis(NULL)
	, m_pGrid(NULL)
	, m_pTerrain(NULL)
	, m_pRect(NULL)
	, m_bWire(false)
{
	
}


GameManager::~GameManager()
{
	Release();
}

void GameManager::Setup(void)
{
	DXMGR->Setup();
	INPUTMGR->SetUp();
	FONTMGR->Setup();

	D3DLIGHT9 l;
	ZeroMemory(&l, sizeof(l));
	l.Type = D3DLIGHT_DIRECTIONAL;
	l.Direction = D3DXVECTOR3(1, -1, 1);
	l.Diffuse = D3DXCOLOR(1, 1, 1, 1);
	DEVICE->SetLight(0, &l);
	DEVICE->LightEnable(0, true);

	// ī�޶� �¾� //
	m_pCamera = new WorldCamera;
	m_pCamera->SetUp(D3DXVECTOR3(0, 5, -5));

	// ���� Ŭ���� //
	m_pAxis = new WorldAxis;
	m_pAxis->Setup();
	m_pGrid = new WorldGrid;
	m_pGrid->Setup();

	// ������Ʈ //
	m_pPlayer = new Player;
	m_pPlayer->Init();

	m_pRect = new Rect;
	m_pRect->Init();

	m_pPlayer->SetTarget(m_pRect);

	m_pTerrain = new Terrain;
	m_pTerrain->Init(32);
}

void GameManager::GameLoop(void)
{
	FRAMEMGR->Update();

	float dTime = FRAMEMGR->GetDeltaTime();

	Update(dTime);
	Render();
}

void GameManager::Update(float dTime)
{
	INPUTMGR->Update();

	if (INPUTMGR->GetKeyDown(VK_F1))
	{
		m_bWire ^= true;
		
		DEVICE->SetRenderState(D3DRS_FILLMODE,
			m_bWire ? D3DFILL_WIREFRAME :
			D3DFILL_SOLID);
	}

	if (INPUTMGR->GetKeyDown(VK_LBUTTON))
	{
		POINT pt;
		GetCursorPos(&pt);
		ScreenToClient(DXMGR->GethWnd(), &pt);

		m_pTerrain->PickTerrain(pt.x, pt.y, true);
	}

	if (INPUTMGR->GetKeyDown(VK_RBUTTON))
	{
		POINT pt;
		GetCursorPos(&pt);
		ScreenToClient(DXMGR->GethWnd(), &pt);

		m_pTerrain->PickTerrain(pt.x, pt.y, false);
	}

	m_pPlayer->Update(dTime);
	m_pRect->Update(dTime);
	m_pTerrain->Update(dTime);
}

void GameManager::Render(void)
{
	DEVICE->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,
					D3DXCOLOR(0.6f, 0.6f, 0.6f, 1), 1, 0);

	DEVICE->BeginScene();
	{
		// �Ʒ����� �׸���
		//m_pPlayer->Render();
		//m_pRect->Render();

		m_pTerrain->Render();

		// ������Ʈ �ٱ׸��� ���� Ŭ���� �׸���
		m_pGrid->Render();
		//m_pAxis->Render();

		// ��Ʈ�� ���� ������
		DrawDebugFont();
	}
	DEVICE->EndScene();

	DEVICE->Present(NULL, NULL, NULL, NULL);
}

void GameManager::DrawDebugFont(void)
{
	int _x = 10;
	int _y = 10;

	D3DXCOLOR _color = D3DXCOLOR(0, 1, 0, 1);

	FONTMGR->DrawText(_x, _y, _color, "FPS : %d",
					FRAMEMGR->GetFPS());

	// ������ŷ ����
	_y += 15;
	D3DINDEX _index = m_pTerrain->GetPickIndexInfo();
	if( _index._0 == 0 &&
		_index._1 == 0 &&
		_index._2 == 0) { }
	else
	{
		FONTMGR->DrawText(_x, _y, _color, 
			"pickIdx(_0:%d, _1:%d, _2:%d)",
			_index._0, _index._1, _index._2);
	}

	
	
}

void GameManager::Release(void)
{
	SAFE_DELETE(m_pPlayer);
	SAFE_DELETE(m_pCamera);
	SAFE_DELETE(m_pAxis);
	SAFE_DELETE(m_pRect);
}

void GameManager::WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	m_pCamera->WndProc(hWnd, message, wParam, lParam);
}
