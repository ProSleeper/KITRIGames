#pragma once

#define TEXMGR TextureManager::GetInstance()

class myTexture;
class TextureManager
{
	SINGLETONE(TextureManager);

	map<string, myTexture*>		m_mapTextures;

public:
	myTexture* GetTexture(string _Texname);
	void Release();
	int GetTextureCount(void)
	{		return (int)m_mapTextures.size();	}
};

