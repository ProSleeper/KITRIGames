#pragma once
class mouseRay
{
	GETTER(D3DXVECTOR3, pos, m_vPos);
	GETTER(D3DXVECTOR3, dir, m_vDir);

public:
	void CreateRay(int x, int y);
	void RayTransform(D3DXMATRIX m);
public:
	mouseRay();
	virtual ~mouseRay();
};

