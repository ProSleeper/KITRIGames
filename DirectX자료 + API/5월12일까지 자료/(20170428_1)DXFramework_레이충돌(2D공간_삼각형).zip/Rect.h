#pragma once
class Rect
{
	LPD3DXMESH			m_pCullSphere;

	GETTER(float, Radius, m_fRadius);

	D3DFVF_XYZ_COLOR	m_arrVertexs[6];

	PROPERTY_FUNC(D3DXVECTOR3, Pos, m_vPos);
	D3DXVECTOR3			m_vRot;
	D3DXVECTOR3			m_vScale;

	D3DXMATRIX			m_mTM;
	D3DXMATRIX			m_mTrans;
	D3DXMATRIX			m_mRot;
	D3DXMATRIX			m_mScale;

public:
	void Init(void);
	void Update(float dTime);
	void Render(void);
	void Release(void);

	D3DXVECTOR3 GetPickPos(mouseRay ray);
	 
public:
	Rect();
	virtual ~Rect();
};

