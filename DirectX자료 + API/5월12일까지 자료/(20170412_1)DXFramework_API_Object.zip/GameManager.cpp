#include "stdafx.h"
#include "Player.h"
#include "GameManager.h"


GameManager::GameManager()
	: m_pPlayer(NULL)
{
}


GameManager::~GameManager()
{
	Release();
}

void GameManager::Setup(void)
{
	DXMGR->Setup();

	m_pPlayer = new Player;
	m_pPlayer->Init();
}

void GameManager::GameLoop(void)
{
	Update();
	Render();
}

void GameManager::Update(void)
{
}

void GameManager::Render(void)
{
	DEVICE->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,
					D3DXCOLOR(0.6f, 0.6f, 0.6f, 1), 1, 0);

	DEVICE->BeginScene();
	{
		// �Ʒ����� �׸���
		m_pPlayer->Render();
	}
	DEVICE->EndScene();

	DEVICE->Present(NULL, NULL, NULL, NULL);
}

void GameManager::Release(void)
{
	SAFE_DELETE(m_pPlayer);
}

void GameManager::WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
}
