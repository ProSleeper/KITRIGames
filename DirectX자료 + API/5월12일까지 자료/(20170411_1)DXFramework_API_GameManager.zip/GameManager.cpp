#include "stdafx.h"
#include "GameManager.h"


GameManager::GameManager()
{
}


GameManager::~GameManager()
{
	Release();
}

void GameManager::Setup(void)
{
	DXMGR->Setup();
}

void GameManager::GameLoop(void)
{
	Update();
	Render();
}

void GameManager::Update(void)
{
}

void GameManager::Render(void)
{
	DEVICE->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,
					D3DXCOLOR(0, 0, 1, 1), 1, 0);

	DEVICE->BeginScene();
	{
		// �Ʒ����� �׸���

	}
	DEVICE->EndScene();

	DEVICE->Present(NULL, NULL, NULL, NULL);
}

void GameManager::Release(void)
{
}

void GameManager::WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
}
