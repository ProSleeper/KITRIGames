#pragma once

#define GAMEMGR GameManager::GetInstance()

class GameManager
{
	SINGLETONE(GameManager);

public:
	void Setup(void);
	void GameLoop(void);
	void Update(void);
	void Render(void);
	void Release(void);
	void WndProc(HWND hWnd, UINT message, 
		WPARAM wParam, LPARAM lParam);
};

