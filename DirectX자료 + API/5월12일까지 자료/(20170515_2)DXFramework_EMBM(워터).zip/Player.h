#pragma once
class Rect;
class Player
{
	PROPERTY_FUNC(Rect*, Target, m_pRect);
	float		m_fRadius;

	LPD3DXMESH			m_pCullSphere;

	// ��ֶ���
	D3DFVF_XYZ_COLOR	m_arrNormalLine[2];

	/// �÷��̾�
	D3DFVF_XYZ_COLOR	m_arrVertexs[3];

	PROPERTY_FUNC(D3DXVECTOR3, Pos, m_vPos);
	D3DXVECTOR3			m_vRot;
	D3DXVECTOR3			m_vScale;
	D3DXVECTOR3			m_vDir;
	D3DXVECTOR3			m_vOrgDir;


	D3DXMATRIX			m_mTM;
	D3DXMATRIX			m_mTrans;
	D3DXMATRIX			m_mRot;
	D3DXMATRIX			m_mScale;

	GETTER(bool, IsPick, m_bIsPick);

public:
	bool IsRaySphere(D3DXVECTOR3 vRayPos,
		D3DXVECTOR3 vRayDir, D3DXVECTOR3 vTargetPos,
		float fTargetRadius);

	void Init(void);
	void Update(float dTime);
	void Render(void);
	void Release(void);

public:
	Player();
	virtual ~Player();
};

