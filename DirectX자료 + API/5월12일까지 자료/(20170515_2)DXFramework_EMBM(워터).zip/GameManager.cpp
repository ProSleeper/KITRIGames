#include "stdafx.h"
#include "Player.h"
#include "WorldAxis.h"
#include "WorldCamera.h"
#include "WorldGrid.h"
#include "mouseRay.h"
#include "Rect.h"
#include "GameManager.h"


GameManager::GameManager()
	: m_pPlayer(NULL)
	, m_pCamera(NULL)
	, m_pAxis(NULL)
	, m_pGrid(NULL)
	, m_pRect(NULL)
{
	
}


GameManager::~GameManager()
{
	Release();
}

void GameManager::Setup(void)
{
	DXMGR->Setup();
	INPUTMGR->SetUp();
	FONTMGR->Setup();

	for (int i = 0; i < 8; ++i)
	{
		DEVICE->SetSamplerState(i,
			D3DSAMP_MINFILTER, D3DTEXF_ANISOTROPIC);
		DEVICE->SetSamplerState(i,
			D3DSAMP_MAGFILTER, D3DTEXF_ANISOTROPIC);
		DEVICE->SetSamplerState(i,
			D3DSAMP_MAXANISOTROPY, 16);
		DEVICE->SetSamplerState(i,
			D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	}

	// ī�޶� �¾� //
	m_pCamera = new WorldCamera;
	m_pCamera->SetUp(D3DXVECTOR3(0, 5, -5));

	// ���� Ŭ���� //
	m_pAxis = new WorldAxis;
	m_pAxis->Setup();
	m_pGrid = new WorldGrid;
	m_pGrid->Setup();

	// ������Ʈ //
	m_pPlayer = new Player;
	m_pPlayer->Init();

	m_pRect = new Rect;
	m_pRect->Init();

	m_pPlayer->SetTarget(m_pRect);
}

void GameManager::GameLoop(void)
{
	FRAMEMGR->Update();

	float dTime = FRAMEMGR->GetDeltaTime();

	Update(dTime);
	Render();
}

void GameManager::Update(float dTime)
{
	INPUTMGR->Update();

	m_pPlayer->Update(dTime);
	m_pRect->Update(dTime);

	if (INPUTMGR->GetKeyDown(VK_LBUTTON))
	{
		POINT pt;
		GetCursorPos(&pt);
		ScreenToClient(DXMGR->GethWnd(), &pt);

		mouseRay ray;

		ray.CreateRay((int)pt.x, (int)pt.y); // �����

		D3DXMATRIX view;
		DEVICE->GetTransform(D3DTS_VIEW, &view);
		ray.RayTransform(view);

		D3DXVECTOR3 _vPos = m_pRect->GetPickPos(ray);
		m_pPlayer->SetPos(_vPos);
	}
}

bool GameManager::IsRaySphere(D3DXVECTOR3 vRayPos,
	D3DXVECTOR3 vRayDir,
	D3DXVECTOR3 vTargetPos, float fTargetRadius)
{
	// Ÿ�ٰ� ���� �Ÿ�
	D3DXVECTOR3 vTargetDis = vTargetPos - vRayPos;

	// �����ϴ� ����
	float len = D3DXVec3Dot(&vTargetDis, &vRayDir);

	// ������ ���� ��ǥ
	D3DXVECTOR3 vPos = vRayPos + vRayDir * len;

	// ������ ������ Ÿ�ٰ� �Ÿ�
	vTargetDis = vPos - vTargetPos;

	// ����
	len = D3DXVec3Length(&vTargetDis);

	// ����
	if (len < fTargetRadius)
		return true;

	return false;
}

void GameManager::Render(void)
{
	DEVICE->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,
					D3DXCOLOR(0.6f, 0.6f, 0.6f, 1), 1, 0);

	DEVICE->BeginScene();
	{
		// �Ʒ����� �׸���
		//m_pPlayer->Render();
		m_pRect->Render();


		// ������Ʈ �ٱ׸��� ���� Ŭ���� �׸���
		//m_pGrid->Render();
		//m_pAxis->Render();

		// ��Ʈ�� ���� ������
		DrawDebugFont();
	}
	DEVICE->EndScene();

	DEVICE->Present(NULL, NULL, NULL, NULL);
}

void GameManager::DrawDebugFont(void)
{
	int _x = 10;
	int _y = 10;

	D3DXCOLOR _color = D3DXCOLOR(0, 1, 0, 1);

	FONTMGR->DrawText(_x, _y, _color, "FPS : %d",
					FRAMEMGR->GetFPS());

	// ���ΰ� ����
	_y += 15;
	_color = D3DXCOLOR(1, 1, 0, 1);
	FONTMGR->DrawText(_x, _y+=15, _color, 
						"< ���ΰ� ���� >");
	FONTMGR->DrawText(_x, _y += 15, _color,
							"- ��Ʈ��(��,��,��,��)");
	FONTMGR->DrawText(_x, _y += 15, _color,
		"- Pos(%.2f, %.2f,%.2f)",
		m_pPlayer->GetPos().x, 
		m_pPlayer->GetPos().y,
		m_pPlayer->GetPos().z);

	RECT rc;
	GetClientRect(DXMGR->GethWnd(), &rc);
	FONTMGR->DrawText(_x, _y += 15, _color,
		"��ŷ:%s", m_pPlayer->GetIsPick() ? "����" : "����");
}

void GameManager::Release(void)
{
	SAFE_DELETE(m_pPlayer);
	SAFE_DELETE(m_pCamera);
	SAFE_DELETE(m_pAxis);
	SAFE_DELETE(m_pRect);
}

void GameManager::WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	m_pCamera->WndProc(hWnd, message, wParam, lParam);
}
