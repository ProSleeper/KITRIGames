#include "stdafx.h"
#include "mouseRay.h"
#include "Rect.h"


void Rect::Init(void)
{
	m_arrVertexs[0].vPos = D3DXVECTOR3(-10, 0, -10);
	m_arrVertexs[0].u = 0;
	m_arrVertexs[0].v = 1;

	m_arrVertexs[1].vPos = D3DXVECTOR3(-10, 0, 10);
	m_arrVertexs[1].u = 0;
	m_arrVertexs[1].v = 0;

	m_arrVertexs[2].vPos = D3DXVECTOR3(10, 0, 10);
	m_arrVertexs[2].u = 1;
	m_arrVertexs[2].v = 0;

	m_arrVertexs[3].vPos = D3DXVECTOR3(-10, 0, -10);
	m_arrVertexs[3].u = 0;
	m_arrVertexs[3].v = 1;

	m_arrVertexs[4].vPos = D3DXVECTOR3(10, 0, 10);
	m_arrVertexs[4].u = 1;
	m_arrVertexs[4].v = 0;

	m_arrVertexs[5].vPos = D3DXVECTOR3(10, 0, -10);
	m_arrVertexs[5].u = 1;
	m_arrVertexs[5].v = 1;
	

	D3DXCreateTextureFromFile(DEVICE, "water2.bmp",
		&m_pTexture);
	D3DXCreateTextureFromFile(DEVICE, "waterbump1.bmp",
		&m_pTextureBump);


	//�޽�
	D3DXCreateSphere(DEVICE, m_fRadius, 10, 10, 
						&m_pCullSphere, NULL);
}

void Rect::Update(float dTime)
{
	//m_vRot.y += D3DX_PI *dTime;

	D3DXMatrixTranslation(&m_mTrans, m_vPos.x, m_vPos.y,
		m_vPos.z);
	D3DXMatrixScaling(&m_mScale, m_vScale.x,
		m_vScale.y, m_vScale.z);
	D3DXMatrixRotationYawPitchRoll(&m_mRot,
		m_vRot.y, m_vRot.x, m_vRot.z);

	m_mTM = m_mScale * m_mRot * m_mTrans;

	m_fAngle += D3DX_PI * 0.05f * dTime;
	D3DXMatrixRotationY(&m_RotY, m_fAngle);

	m_fMove += 0.01f*dTime;
	m_mTexAni._31 = m_fMove;
	m_mTexAni._32 = m_fMove;
}

DWORD FLOATTOWORD(FLOAT f)
{
	return *((DWORD*)&f);
}

void Rect::Render(void)
{
	DEVICE->SetTexture(0, m_pTextureBump);
	DEVICE->SetTextureStageState(0, D3DTSS_COLOROP,
		D3DTOP_BUMPENVMAP);
	DEVICE->SetTextureStageState(0, D3DTSS_COLORARG1,
		D3DTA_TEXTURE);

	DEVICE->SetTextureStageState(0,
		D3DTSS_BUMPENVMAT00, FLOATTOWORD(m_RotY._11));
	DEVICE->SetTextureStageState(0,
		D3DTSS_BUMPENVMAT01, FLOATTOWORD(m_RotY._13));
	DEVICE->SetTextureStageState(0,
		D3DTSS_BUMPENVMAT10, FLOATTOWORD(m_RotY._31));
	DEVICE->SetTextureStageState(0,
		D3DTSS_BUMPENVMAT11, FLOATTOWORD(m_RotY._33));

	DEVICE->SetTransform(D3DTS_TEXTURE0, &m_mTexAni);
	DEVICE->SetTextureStageState(0,
		D3DTSS_TEXTURETRANSFORMFLAGS, D3DTTFF_COUNT2);

	//1 stage
	DEVICE->SetTexture(1, m_pTexture);
	DEVICE->SetTextureStageState(1, D3DTSS_COLOROP,
		D3DTOP_SELECTARG1);
	DEVICE->SetTextureStageState(1, D3DTSS_COLORARG1,
		D3DTA_TEXTURE);
	DEVICE->SetTextureStageState(1,
		D3DTSS_TEXCOORDINDEX, 0);

	DEVICE->SetTransform(D3DTS_WORLD, &m_mTM);
	DEVICE->SetRenderState(D3DRS_LIGHTING, false);
	DEVICE->SetFVF(D3DFVF_XYZ_TEX1::FVF);
	DEVICE->DrawPrimitiveUP(
		D3DPT_TRIANGLELIST,		// �׸��¹��
		2,						// �ﰢ�� ����
		&m_arrVertexs,			// ���ؽ� ����
		sizeof(D3DFVF_XYZ_TEX1)// �������� ������
	);

	DEVICE->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);


	//�޽�
	//m_mTM._42 = 1;
	DEVICE->SetTransform(D3DTS_WORLD, &m_mTM);
	DEVICE->SetRenderState(D3DRS_FILLMODE, D3DFILL_WIREFRAME);
	//m_pCullSphere->DrawSubset(0);
	DEVICE->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
}

void Rect::Release(void)
{
	SAFE_RELEASE(m_pCullSphere);
}

D3DXVECTOR3 Rect::GetPickPos(mouseRay ray)
{
	D3DXVECTOR3 vResult(0,0,0);
	float _u, _v, _dist;
	
	if (D3DXIntersectTri(&m_arrVertexs[0].vPos,
		&m_arrVertexs[1].vPos, &m_arrVertexs[2].vPos,
		&ray.Getpos(), &ray.Getdir(), &_u, &_v, &_dist))
	{
		//MessageBox(NULL, "���ʻﰢ�� ��ŷ", "����", MB_OK);
		//vResult = ray.Getpos() + ray.Getdir() * _dist;
		vResult = m_arrVertexs[0].vPos +
			(_u *(m_arrVertexs[1].vPos - m_arrVertexs[0].vPos))
			+ (_v *(m_arrVertexs[2].vPos - m_arrVertexs[0].vPos));
	}

	if (D3DXIntersectTri(&m_arrVertexs[3].vPos,
		&m_arrVertexs[4].vPos, &m_arrVertexs[5].vPos,
		&ray.Getpos(), &ray.Getdir(), &_u, &_v, &_dist))
	{
		//MessageBox(NULL, "�Ʒ��ﰢ�� ��ŷ", "����", MB_OK);
		//vResult = ray.Getpos() + ray.Getdir() * _dist;
		vResult = m_arrVertexs[3].vPos +
			(_u *(m_arrVertexs[4].vPos - m_arrVertexs[3].vPos))
			+ (_v *(m_arrVertexs[5].vPos - m_arrVertexs[3].vPos));
	}

	return vResult;
}

Rect::Rect()
	: m_vPos(0, 0, 0)
	, m_vRot(0, 0, 0)
	, m_vScale(1, 1, 1)
	, m_pCullSphere(NULL)
	, m_fRadius(1.0f)
	, m_fAngle(0.0f)
	, m_fMove(0.0f)
{
	D3DXMatrixIdentity(&m_mTM);
	D3DXMatrixIdentity(&m_mTrans);
	D3DXMatrixIdentity(&m_mRot);
	D3DXMatrixIdentity(&m_mScale);
	D3DXMatrixIdentity(&m_mTexAni);
}


Rect::~Rect()
{
	Release();
}
