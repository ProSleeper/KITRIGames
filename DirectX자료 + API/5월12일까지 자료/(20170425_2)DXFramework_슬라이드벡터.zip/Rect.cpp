#include "stdafx.h"
#include "Rect.h"


void Rect::Init(void)
{
	m_arrVertexs[0].vPos = D3DXVECTOR3(-1, 0, 0);
	m_arrVertexs[0].color = D3DXCOLOR(1, 1, 0, 1);

	m_arrVertexs[1].vPos = D3DXVECTOR3(-1, 2, 0);
	m_arrVertexs[1].color = D3DXCOLOR(1, 1, 0, 1);

	m_arrVertexs[2].vPos = D3DXVECTOR3(1, 2, 0);
	m_arrVertexs[2].color = D3DXCOLOR(1, 1, 0, 1);

	m_arrVertexs[3].vPos = D3DXVECTOR3(-1, 0, 0);
	m_arrVertexs[3].color = D3DXCOLOR(1, 1, 0, 1);

	m_arrVertexs[4].vPos = D3DXVECTOR3(1, 2, 0);
	m_arrVertexs[4].color = D3DXCOLOR(1, 1, 0, 1);

	m_arrVertexs[5].vPos = D3DXVECTOR3(1, 0, 0);
	m_arrVertexs[5].color = D3DXCOLOR(1, 1, 0, 1);

	//�޽�
	D3DXCreateSphere(DEVICE, m_fRadius, 10, 10, 
						&m_pCullSphere, NULL);
}

void Rect::Update(float dTime)
{
	//m_vRot.y += D3DX_PI *dTime;

	D3DXMatrixTranslation(&m_mTrans, m_vPos.x, m_vPos.y,
		m_vPos.z);
	D3DXMatrixScaling(&m_mScale, m_vScale.x,
		m_vScale.y, m_vScale.z);
	D3DXMatrixRotationYawPitchRoll(&m_mRot,
		m_vRot.y, m_vRot.x, m_vRot.z);

	m_mTM = m_mScale * m_mRot * m_mTrans;
}

void Rect::Render(void)
{
	DEVICE->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
	DEVICE->SetTransform(D3DTS_WORLD, &m_mTM);

	DEVICE->SetRenderState(D3DRS_LIGHTING, false);
	DEVICE->SetFVF(D3DFVF_XYZ_COLOR::FVF);
	DEVICE->DrawPrimitiveUP(
		D3DPT_TRIANGLELIST,		// �׸��¹��
		2,						// �ﰢ�� ����
		&m_arrVertexs,			// ���ؽ� ����
		sizeof(D3DFVF_XYZ_COLOR)// �������� ������
	);

	DEVICE->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);


	//�޽�
	m_mTM._42 = 1;
	DEVICE->SetTransform(D3DTS_WORLD, &m_mTM);
	DEVICE->SetRenderState(D3DRS_FILLMODE, D3DFILL_WIREFRAME);
	m_pCullSphere->DrawSubset(0);
	DEVICE->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
}

void Rect::Release(void)
{
	SAFE_RELEASE(m_pCullSphere);
}

Rect::Rect()
	: m_vPos(0, 0, 5)
	, m_vRot(0, 0, 0)
	, m_vScale(1, 1, 1)
	, m_pCullSphere(NULL)
	, m_fRadius(1.0f)
{
	D3DXMatrixIdentity(&m_mTM);
	D3DXMatrixIdentity(&m_mTrans);
	D3DXMatrixIdentity(&m_mRot);
	D3DXMatrixIdentity(&m_mScale);
}


Rect::~Rect()
{
	Release();
}
