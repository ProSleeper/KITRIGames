#pragma once
class Bullet
{
public:
	Bullet();
	virtual ~Bullet();
};

