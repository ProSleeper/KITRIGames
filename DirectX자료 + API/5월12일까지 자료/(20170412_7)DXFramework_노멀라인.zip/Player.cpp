#include "stdafx.h"
#include "Player.h"


void Player::Init(void)
{
	m_arrVertexs[0].vPos = D3DXVECTOR3(-1, 0, 0);
	m_arrVertexs[0].color = D3DXCOLOR(1, 0, 0, 1);

	m_arrVertexs[1].vPos = D3DXVECTOR3(0, 1, 0);
	m_arrVertexs[1].color = D3DXCOLOR(0, 1, 0, 1);

	m_arrVertexs[2].vPos = D3DXVECTOR3(1, 0, 0);
	m_arrVertexs[2].color = D3DXCOLOR(0, 0, 1, 1);

	// ��ֶ���
	m_arrNormalLine[0].vPos = D3DXVECTOR3(0, 0.5f, 0);
	m_arrNormalLine[0].color = D3DXCOLOR(0, 1, 0, 1);

	m_arrNormalLine[1].vPos = D3DXVECTOR3(0, 0.5f, 5);
	m_arrNormalLine[1].color = D3DXCOLOR(0, 1, 0, 1);
}

void Player::Update(void)
{
	if (INPUTMGR->GetKey(VK_DOWN))
		m_vPos -= m_vDir * 0.2f;
	if (INPUTMGR->GetKey(VK_UP))
		m_vPos += m_vDir * 0.2f;

	if (INPUTMGR->GetKey(VK_LEFT))
	{
		m_vRot.y -= 0.03f;
		D3DXVec3TransformNormal(&m_vDir,
			&m_vOrgDir, &m_mRot);
	}
	if (INPUTMGR->GetKey(VK_RIGHT))
	{
		m_vRot.y += 0.03f;
		D3DXVec3TransformCoord(&m_vDir,
			&m_vOrgDir, &m_mRot);
	}

	D3DXMatrixTranslation(&m_mTrans, m_vPos.x, m_vPos.y,
							m_vPos.z);
	D3DXMatrixScaling(&m_mScale, m_vScale.x,
				m_vScale.y, m_vScale.z);
	D3DXMatrixRotationYawPitchRoll(&m_mRot,
		m_vRot.y, m_vRot.x, m_vRot.z);

	m_mTM = m_mScale * m_mRot * m_mTrans;
}

void Player::Render(void)
{
	DWORD dwState;
	DEVICE->GetRenderState(D3DRS_FILLMODE, &dwState);
	DEVICE->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);

	//DEVICE->SetRenderState(D3DRS_FILLMODE, D3DFILL_WIREFRAME);

	DEVICE->SetTransform(D3DTS_WORLD, &m_mTM);

	DEVICE->SetRenderState(D3DRS_LIGHTING, false);
	DEVICE->SetFVF(D3DFVF_XYZ_COLOR::FVF);
	DEVICE->DrawPrimitiveUP(
		D3DPT_TRIANGLELIST,		// �׸��¹��
		1,						// �ﰢ�� ����
		&m_arrVertexs,			// ���ؽ� ����
		sizeof(D3DFVF_XYZ_COLOR)// �������� ������
	);

	DEVICE->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);
	DEVICE->SetRenderState(D3DRS_FILLMODE, dwState);


	// ��ֶ���
	DEVICE->DrawPrimitiveUP(D3DPT_LINELIST, 1,
		&m_arrNormalLine, sizeof(D3DFVF_XYZ_COLOR));

}

void Player::Release(void)
{
}

Player::Player()
	: m_vPos(0,0,0)
	, m_vRot(0,0,0)
	, m_vScale(1,1,1)
	, m_vDir(0,0,1)
	, m_vOrgDir(0, 0, 1)
{
	D3DXMatrixIdentity(&m_mTM);
	D3DXMatrixIdentity(&m_mTrans);
	D3DXMatrixIdentity(&m_mRot);
	D3DXMatrixIdentity(&m_mScale);
}


Player::~Player()
{
}

