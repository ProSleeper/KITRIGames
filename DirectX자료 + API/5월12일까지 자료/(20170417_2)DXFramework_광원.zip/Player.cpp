#include "stdafx.h"
#include "Player.h"


void Player::Init(void)
{
	//�Ʒ� (y = -1)
	m_arrVertexs[0][2].vPos = D3DXVECTOR3(0.5f, -0.5f, -0.5f);
	m_arrVertexs[0][1].vPos = D3DXVECTOR3(-0.5f, -0.5f, -0.5f);
	m_arrVertexs[0][0].vPos = D3DXVECTOR3(-0.5f, -0.5f, 0.5f);
	m_arrVertexs[1][2].vPos = D3DXVECTOR3(0.5f, -0.5f, -0.5f);
	m_arrVertexs[1][1].vPos = D3DXVECTOR3(-0.5f, -0.5f, 0.5f);
	m_arrVertexs[1][0].vPos = D3DXVECTOR3(0.5f, -0.5f, 0.5f);
	for (int i = 0; i < 2; i++) {
		for (int j = 0; j < 3; j++) {
			m_arrVertexs[i][j].vNormal = D3DXVECTOR3(0, -1, 0);
		}
	}
	//����(z = -1)
	m_arrVertexs[2][2].vPos = D3DXVECTOR3(0.5f, 0.5f, -0.5f);
	m_arrVertexs[2][1].vPos = D3DXVECTOR3(-0.5f, -0.5f, -0.5f);
	m_arrVertexs[2][0].vPos = D3DXVECTOR3(0.5f, -0.5f, -0.5f);
	m_arrVertexs[3][2].vPos = D3DXVECTOR3(0.5f, 0.5f, -0.5f);
	m_arrVertexs[3][1].vPos = D3DXVECTOR3(-0.5f, 0.5f, -0.5f);
	m_arrVertexs[3][0].vPos = D3DXVECTOR3(-0.5f, -0.5f, -0.5f);
	for (int i = 2; i < 4; i++) {
		for (int j = 0; j < 3; j++) {
			m_arrVertexs[i][j].vNormal = D3DXVECTOR3(0, 0, -1);
		}
	}
	//����(x = -1)
	m_arrVertexs[4][2].vPos = D3DXVECTOR3(-0.5f, 0.5f, -0.5f);
	m_arrVertexs[4][1].vPos = D3DXVECTOR3(-0.5f, 0.5f, 0.5f);
	m_arrVertexs[4][0].vPos = D3DXVECTOR3(-0.5f, -0.5f, 0.5f);
	m_arrVertexs[5][2].vPos = D3DXVECTOR3(-0.5f, 0.5f, -0.5f);
	m_arrVertexs[5][1].vPos = D3DXVECTOR3(-0.5f, -0.5f, 0.5f);
	m_arrVertexs[5][0].vPos = D3DXVECTOR3(-0.5f, -0.5f, -0.5f);
	for (int i = 4; i < 6; i++) {
		for (int j = 0; j < 3; j++) {
			m_arrVertexs[i][j].vNormal = D3DXVECTOR3(-1, 0, 0);
		}
	}
	//������ (x = 1)
	m_arrVertexs[6][2].vPos = D3DXVECTOR3(0.5f, 0.5f, 0.5f);
	m_arrVertexs[6][1].vPos = D3DXVECTOR3(0.5f, 0.5f, -0.5f);
	m_arrVertexs[6][0].vPos = D3DXVECTOR3(0.5f, -0.5f, -0.5f);
	m_arrVertexs[7][2].vPos = D3DXVECTOR3(0.5f, 0.5f, 0.5f);
	m_arrVertexs[7][1].vPos = D3DXVECTOR3(0.5f, -0.5f, -0.5f);
	m_arrVertexs[7][0].vPos = D3DXVECTOR3(0.5f, -0.5f, 0.5f);
	for (int i = 6; i < 8; i++) {
		for (int j = 0; j < 3; j++) {
			m_arrVertexs[i][j].vNormal = D3DXVECTOR3(1, 0, 0);
		}
	}
	//�� (y = 1)
	m_arrVertexs[8][2].vPos = D3DXVECTOR3(0.5f, 0.5f, 0.5f);
	m_arrVertexs[8][1].vPos = D3DXVECTOR3(-0.5f, 0.5f, -0.5f);
	m_arrVertexs[8][0].vPos = D3DXVECTOR3(0.5f, 0.5f, -0.5f);
	m_arrVertexs[9][2].vPos = D3DXVECTOR3(0.5f, 0.5f, 0.5f);
	m_arrVertexs[9][1].vPos = D3DXVECTOR3(-0.5f, 0.5f, 0.5f);
	m_arrVertexs[9][0].vPos = D3DXVECTOR3(-0.5f, 0.5f, -0.5f);
	for (int i = 8; i < 10; i++) {
		for (int j = 0; j < 3; j++) {
			m_arrVertexs[i][j].vNormal = D3DXVECTOR3(0, 1, 0);
		}
	}
	//�� (z = 1)
	m_arrVertexs[10][2].vPos = D3DXVECTOR3(0.5f, -0.5f, 0.5f);
	m_arrVertexs[10][1].vPos = D3DXVECTOR3(-0.5f, 0.5f, 0.5f);
	m_arrVertexs[10][0].vPos = D3DXVECTOR3(0.5f, 0.5f, 0.5f);
	m_arrVertexs[11][2].vPos = D3DXVECTOR3(0.5f, -0.5f, 0.5f);
	m_arrVertexs[11][1].vPos = D3DXVECTOR3(-0.5f, -0.5f, 0.5f);
	m_arrVertexs[11][0].vPos = D3DXVECTOR3(-0.5f, 0.5f, 0.5f);
	for (int i = 10; i < 12; i++) {
		for (int j = 0; j < 3; j++) {
			m_arrVertexs[i][j].vNormal = D3DXVECTOR3(0, 0, 1);
		}
	}

	for (int i = 0; i < 12; i++) {
		for (int j = 0; j < 3; j++) {
			m_arrVertexs[i][j].color = D3DXCOLOR(1, 1, 1, 1);
		}
	}

	m_Material.Diffuse = m_Material.Ambient
		= D3DXCOLOR(1, 0, 0, 1);


	// ��ֶ���
	m_arrNormalLine[0].vPos = D3DXVECTOR3(0, 0.5f, 0);
	m_arrNormalLine[0].color = D3DXCOLOR(0, 1, 0, 1);

	m_arrNormalLine[1].vPos = D3DXVECTOR3(0, 0.5f, 5);
	m_arrNormalLine[1].color = D3DXCOLOR(0, 1, 0, 1);
}

void Player::Update(float dTime)
{
	if (INPUTMGR->GetKey(VK_DOWN))
		m_vPos -= m_vDir * 5.0f * dTime;
	if (INPUTMGR->GetKey(VK_UP))
		m_vPos += m_vDir * 5.0f * dTime;

	if (INPUTMGR->GetKey(VK_LEFT))
	{
		m_vRot.y -= D3DX_PI *2 * dTime;
		D3DXVec3TransformNormal(&m_vDir,
			&m_vOrgDir, &m_mRot);
	}
	if (INPUTMGR->GetKey(VK_RIGHT))
	{
		m_vRot.y += D3DX_PI *2* dTime;
		D3DXVec3TransformCoord(&m_vDir,
			&m_vOrgDir, &m_mRot);
	}

	D3DXMatrixTranslation(&m_mTrans, m_vPos.x, m_vPos.y,
							m_vPos.z);
	D3DXMatrixScaling(&m_mScale, m_vScale.x,
				m_vScale.y, m_vScale.z);
	D3DXMatrixRotationYawPitchRoll(&m_mRot,
		m_vRot.y, m_vRot.x, m_vRot.z);

	m_mTM = m_mScale * m_mRot * m_mTrans;
}

void Player::Render(void)
{
	DWORD dwState;
	DEVICE->GetRenderState(D3DRS_FILLMODE, &dwState);
	DEVICE->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);

	//DEVICE->SetRenderState(D3DRS_FILLMODE, D3DFILL_WIREFRAME);

	DEVICE->SetTransform(D3DTS_WORLD, &m_mTM);
	DEVICE->SetMaterial(&m_Material);
	DEVICE->SetRenderState(D3DRS_LIGHTING, true);
	DEVICE->SetFVF(D3DFVF_XYZ_NORMAL_COLOR::FVF);
	DEVICE->DrawPrimitiveUP(
		D3DPT_TRIANGLELIST,		// �׸��¹��
		12,						// �ﰢ�� ����
		&m_arrVertexs,			// ���ؽ� ����
		sizeof(D3DFVF_XYZ_NORMAL_COLOR)// �������� ������
	);

	DEVICE->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);
	DEVICE->SetRenderState(D3DRS_FILLMODE, dwState);
	DEVICE->SetRenderState(D3DRS_LIGHTING, false);

	// ��ֶ���
	DEVICE->SetFVF(D3DFVF_XYZ_COLOR::FVF);
	DEVICE->DrawPrimitiveUP(D3DPT_LINELIST, 1,
		&m_arrNormalLine, sizeof(D3DFVF_XYZ_COLOR));

}

void Player::Release(void)
{
}

Player::Player()
	: m_vPos(0,0,0)
	, m_vRot(0,0,0)
	, m_vScale(1,1,1)
	, m_vDir(0,0,1)
	, m_vOrgDir(0, 0, 1)
{
	D3DXMatrixIdentity(&m_mTM);
	D3DXMatrixIdentity(&m_mTrans);
	D3DXMatrixIdentity(&m_mRot);
	D3DXMatrixIdentity(&m_mScale);

	ZeroMemory(&m_Material, sizeof(m_Material));
}


Player::~Player()
{
}

