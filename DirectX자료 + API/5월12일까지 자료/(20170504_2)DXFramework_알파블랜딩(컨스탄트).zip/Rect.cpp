#include "stdafx.h"
#include "myTexture.h"
#include "Rect.h"


void Rect::Init(void)
{
	m_arrVertexs[0].vPos = D3DXVECTOR3(-1, 0, 0);
	m_arrVertexs[0].u = 0; 
	m_arrVertexs[0].v = 1;

	m_arrVertexs[1].vPos = D3DXVECTOR3(-1, 2, 0);
	m_arrVertexs[1].u = 0;
	m_arrVertexs[1].v = 0;

	m_arrVertexs[2].vPos = D3DXVECTOR3(1, 2, 0);
	m_arrVertexs[2].u = 1;
	m_arrVertexs[2].v = 0;

	m_arrVertexs[3].vPos = D3DXVECTOR3(-1, 0, 0);
	m_arrVertexs[3].u = 0;
	m_arrVertexs[3].v = 1;

	m_arrVertexs[4].vPos = D3DXVECTOR3(1, 2, 0);
	m_arrVertexs[4].u = 1;
	m_arrVertexs[4].v = 0;

	m_arrVertexs[5].vPos = D3DXVECTOR3(1, 0, 0);
	m_arrVertexs[5].u = 1;
	m_arrVertexs[5].v = 1;

	//�޽�
	D3DXCreateSphere(DEVICE, m_fRadius, 10, 10, 
						&m_pCullSphere, NULL);

	m_pTexture = TEXMGR->GetTexture("texture.jpg");
	m_pTexture = TEXMGR->GetTexture("texture.jpg");
	m_pTexture = TEXMGR->GetTexture("texture.jpg");
	m_pTexture = TEXMGR->GetTexture("texture.jpg");
	m_pTexture = TEXMGR->GetTexture("texture.jpg");
	m_pTexture = TEXMGR->GetTexture("texture.jpg");
	m_pTexture = TEXMGR->GetTexture("texture.jpg");
	m_pTexture = TEXMGR->GetTexture("texture.jpg");
	m_pTexture = TEXMGR->GetTexture("texture.jpg");
	m_pTexture = TEXMGR->GetTexture("texture.jpg");
	m_pTexture = TEXMGR->GetTexture("texture.jpg");
}

void Rect::Update(float dTime)
{
	//m_vRot.y += D3DX_PI *dTime;

	D3DXMatrixTranslation(&m_mTrans, m_vPos.x, m_vPos.y,
		m_vPos.z);
	D3DXMatrixScaling(&m_mScale, m_vScale.x,
		m_vScale.y, m_vScale.z);
	D3DXMatrixRotationYawPitchRoll(&m_mRot,
		m_vRot.y, m_vRot.x, m_vRot.z);

	D3DXMATRIX mBillboard;
	D3DXMATRIX mView;
	DEVICE->GetTransform(D3DTS_VIEW, &mView);
	D3DXMatrixIdentity(&mBillboard);

	mBillboard._11 = mView._11;
	mBillboard._13 = mView._13;
	mBillboard._31 = mView._31;
	mBillboard._33 = mView._33;

	D3DXMatrixInverse(&mBillboard, 0, &mBillboard);

	m_mTM = m_mScale * m_mRot * m_mTrans * mBillboard;
}

void Rect::Render(void)
{
	DEVICE->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
	DEVICE->SetTransform(D3DTS_WORLD, &m_mTM);

	DEVICE->SetRenderState(D3DRS_LIGHTING, false);
	DEVICE->SetFVF(D3DFVF_XYZ_TEX1::FVF);

	DEVICE->SetTexture(0, m_pTexture->GetTexture());

	DEVICE->SetRenderState(D3DRS_ALPHABLENDENABLE,
									true);
	DEVICE->SetRenderState(D3DRS_SRCBLEND, 
							D3DBLEND_SRCALPHA);
	DEVICE->SetRenderState(D3DRS_DESTBLEND,
						D3DBLEND_INVSRCALPHA);

	DEVICE->SetTextureStageState(0, D3DTSS_ALPHAOP,
							D3DTOP_SELECTARG1);
	DEVICE->SetTextureStageState(0, D3DTSS_ALPHAARG1,
							D3DTA_CONSTANT);
	DEVICE->SetTextureStageState(0, D3DTSS_CONSTANT,
		D3DXCOLOR(1, 1, 1, 0.8f));

	DEVICE->DrawPrimitiveUP(
		D3DPT_TRIANGLELIST,		// �׸��¹��
		2,						// �ﰢ�� ����
		&m_arrVertexs,			// ���ؽ� ����
		sizeof(D3DFVF_XYZ_TEX1)// �������� ������
	);
	DEVICE->SetRenderState(D3DRS_ALPHABLENDENABLE,
		false);
	DEVICE->SetRenderState(D3DRS_SRCBLEND,
		D3DBLEND_ONE);
	DEVICE->SetRenderState(D3DRS_DESTBLEND,
		D3DBLEND_ZERO);

	DEVICE->SetTextureStageState(0, D3DTSS_ALPHAOP,
		D3DTOP_SELECTARG1);
	DEVICE->SetTextureStageState(0, D3DTSS_ALPHAARG1,
		D3DTA_TEXTURE);
	DEVICE->SetTexture(0, NULL);

	DEVICE->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);


	//�޽�
	m_mTM._42 = 1;
	DEVICE->SetTransform(D3DTS_WORLD, &m_mTM);
	DEVICE->SetRenderState(D3DRS_FILLMODE, D3DFILL_WIREFRAME);
	//m_pCullSphere->DrawSubset(0);
	DEVICE->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
}

void Rect::Release(void)
{
	SAFE_RELEASE(m_pCullSphere);
}

Rect::Rect()
	: m_vPos(0, 0, 0)
	, m_vRot(0, 0, 0)
	, m_vScale(1, 1, 1)
	, m_pCullSphere(NULL)
	, m_fRadius(1.0f)
	, m_pTexture(NULL)
{
	D3DXMatrixIdentity(&m_mTM);
	D3DXMatrixIdentity(&m_mTrans);
	D3DXMatrixIdentity(&m_mRot);
	D3DXMatrixIdentity(&m_mScale);
}


Rect::~Rect()
{
	Release();
}
