#include "stdafx.h"
#include "Particle.h"


float Particle::fRandom(float _min, float _max)
{
	int fMin = _min * 100;
	int fMax = _max * 100;

	float fResult = (rand() % (fMax - fMin)) + fMin;

	return fResult / 100.0f;

}

void Particle::Init(void)
{
	D3DFVF_XYZ_TEX1 vtxs[] =
	{
		{D3DXVECTOR3(-0.1f, 0.1f, 0), 0, 0},
		{ D3DXVECTOR3(0.1f, 0.1f, 0), 1, 0 },
		{ D3DXVECTOR3(-0.1f, -0.1f, 0), 0, 1 },
		{ D3DXVECTOR3(0.1f, -0.1f, 0), 1, 1 }
	};

	DEVICE->CreateVertexBuffer(sizeof(vtxs), 0,
		D3DFVF_XYZ_TEX1::FVF, D3DPOOL_DEFAULT,
		&m_pVB, NULL);

	void* pData = NULL;
	m_pVB->Lock(0, sizeof(vtxs), &pData, 0);
	memcpy(pData, vtxs, sizeof(vtxs));
	m_pVB->Unlock();

	InitParticleInfo();
}

void Particle::InitParticleInfo(void)
{
	m_fLifeTime = m_PtInfo.fLifeTime
				+ fRandom(m_PtInfo.fMinLifeTime, 
					m_PtInfo.fMaxLifeTime);

	m_fGrowSize = m_PtInfo.fGrowSize
		+ fRandom(m_PtInfo.fMinGrowSize,
			m_PtInfo.fMaxGrowSize);

	m_fAngleSpeed = m_PtInfo.fAngleSpeed
		+ fRandom(m_PtInfo.fMinAngleSpeed,
			m_PtInfo.fMaxAngleSpeed);

	m_vVelocity = m_PtInfo.vVelocity
		+ D3DXVECTOR3(
			fRandom(m_PtInfo.vMinVelocity.x,
				m_PtInfo.vMaxVelocity.x),

			fRandom(m_PtInfo.vMinVelocity.y,
				m_PtInfo.vMaxVelocity.y),

			fRandom(m_PtInfo.vMinVelocity.z,
				m_PtInfo.vMaxVelocity.z)
			);
}

void Particle::Update(float dTime)
{
	m_fLifeTime -= dTime;
	if (m_fLifeTime < 0.0f)
		m_bLife = false;

	m_vPos += m_vVelocity * dTime;
	m_vRot.z += m_fAngleSpeed * dTime;
	//m_vScale += D3DXVECTOR3(m_fGrowSize,
		//m_fGrowSize, 0);

	D3DXMatrixTranslation(&m_mTrans,
		m_vPos.x, m_vPos.y, m_vPos.z);

	D3DXMatrixRotationZ(&m_mRot, m_vRot.z);
	D3DXMatrixScaling(&m_mScale, m_vScale.x,
		m_vScale.y, m_vScale.z);

	m_mTM = m_mScale * m_mRot * m_mTrans;
}

void Particle::Render(void)
{
	DEVICE->SetRenderState(D3DRS_LIGHTING, false);
	DEVICE->SetTexture(0, m_pTexture);
	DEVICE->SetStreamSource(0, m_pVB, 0,
		sizeof(D3DFVF_XYZ_TEX1));
	DEVICE->SetFVF(D3DFVF_XYZ_TEX1::FVF);
	DEVICE->SetTransform(D3DTS_WORLD, &m_mTM);

	DEVICE->DrawPrimitive(D3DPT_TRIANGLESTRIP,
		0, 2);
	DEVICE->SetTexture(0, NULL);
}

void Particle::Release(void)
{
	SAFE_RELEASE(m_pVB);
	//SAFE_RELEASE(m_pTexture);
}

/*
m_bLife;
m_fLifeTime;
m_fAngleSpeed;
m_fGrowSize;
m_vVelocity;
*/
Particle::Particle()
	: m_pTexture(NULL)
	, m_pVB(NULL)
	, m_vPos(0,0,0)
	, m_vRot(0,0,0)
	, m_vScale(1,1,1)
	, m_bLife(true)
	, m_fLifeTime(0)
	, m_fAngleSpeed(0)
	, m_fGrowSize(0)
	, m_vVelocity(0,0,0)
{
	D3DXMatrixIdentity(&m_mTM);
	D3DXMatrixIdentity(&m_mTrans);
	D3DXMatrixIdentity(&m_mRot);
	D3DXMatrixIdentity(&m_mScale);
}


Particle::~Particle()
{
	Release();
}
