#pragma once

struct ParticleInfo
{
	float fLifeTime;
	float fMinLifeTime;
	float fMaxLifeTime;

	float fAngleSpeed;
	float fMinAngleSpeed;
	float fMaxAngleSpeed;

	float fGrowSize;
	float fMinGrowSize;
	float fMaxGrowSize;

	D3DXVECTOR3 vVelocity;
	D3DXVECTOR3 vMinVelocity;
	D3DXVECTOR3 vMaxVelocity;
};

class Particle
{
	PROPERTY_FUNC(ParticleInfo, ptInfo, m_PtInfo);

	LPDIRECT3DVERTEXBUFFER9	m_pVB;
	PROPERTY_FUNC(LPDIRECT3DTEXTURE9, Texture, m_pTexture);

	D3DXVECTOR3				m_vPos;
	D3DXVECTOR3				m_vRot;
	D3DXVECTOR3				m_vScale;

	D3DXMATRIX				m_mTM;
	D3DXMATRIX				m_mTrans;
	D3DXMATRIX				m_mRot;
	D3DXMATRIX				m_mScale;

	PROPERTY_FUNC(bool, Life, m_bLife);
	float					m_fLifeTime;
	float					m_fAngleSpeed;
	float					m_fGrowSize;
	D3DXVECTOR3				m_vVelocity;
	
	float fRandom(float _min, float _max);

public:
	void Init(void);
	void InitParticleInfo(void);
	void Update(float dTime);
	void Render(void);
	void Release(void);

public:
	Particle();
	virtual ~Particle();
};

