#include "stdafx.h"
#include "Particle.h"
#include "SkillEffect.h"


void SkillEffect::CreateParticle(void)
{
	if ((int)m_listParticle.size()
			> m_nParticleCount)
		return;

	Particle* _pParticle = new Particle;
	_pParticle->SetTexture(m_pTexture);
	_pParticle->SetptInfo(m_ParticleInfo);
	_pParticle->Init();

	m_listParticle.push_back(_pParticle);
}

void SkillEffect::CreateOneshotParticle(void)
{
	for (int i = 0; i < m_nParticleCount; ++i)
	{
		Particle* _pParticle = new Particle;
		_pParticle->SetTexture(m_pTexture);
		_pParticle->SetptInfo(m_ParticleInfo);
		_pParticle->Init();

		m_listParticle.push_back(_pParticle);
	}	
}

void SkillEffect::Update(float dTime)
{
	if (m_bOneshot == false)
	{
		m_fOldTime += dTime;
		if (m_fOldTime >= m_fRespawnTime)
		{
			m_fOldTime = 0;
			CreateParticle();
		}
	}
	else
	{
		if ((int)m_listParticle.size() <= 0)
			CreateOneshotParticle();
	}

	for each(auto p in m_listParticle)
		p->Update(dTime);


	for (list<Particle*>::iterator itor
		= m_listParticle.begin();
		itor != m_listParticle.end();)
	{
		if ((*itor)->GetLife() == false)
		{
			SAFE_DELETE(*itor);
			itor = m_listParticle.erase(itor);
		}
		else
			++itor;
	}
}

void SkillEffect::Render(void)
{
	for each(auto p in m_listParticle)
		p->Render();
}

void SkillEffect::Release(void)
{
	for each(auto p in m_listParticle)
		SAFE_DELETE(p);

	m_listParticle.clear();
}

SkillEffect::SkillEffect()
	: m_bOneshot(true)
	, m_nParticleCount(50)
	, m_fRespawnTime(0.05f)
	, m_fOldTime(0.0f)
	, m_pTexture(NULL)
{
	m_listParticle.clear();

	D3DXCreateTextureFromFile(DEVICE,
		"texture.jpg", &m_pTexture);
	
	m_ParticleInfo.fLifeTime = 4.0f;
	m_ParticleInfo.fMinLifeTime = -1.0f;
	m_ParticleInfo.fMaxLifeTime = 1.0f;		

	m_ParticleInfo.fAngleSpeed = D3DX_PI;
	m_ParticleInfo.fMinAngleSpeed = -D3DX_PI / 8.0f;
	m_ParticleInfo.fMaxAngleSpeed = D3DX_PI / 8.0f;

	m_ParticleInfo.fGrowSize = 0.1f;
	m_ParticleInfo.fMinGrowSize = -0.05f;
	m_ParticleInfo.fMaxGrowSize = 0.05f;
	
	m_ParticleInfo.vVelocity = D3DXVECTOR3(0, 0, 0);
	m_ParticleInfo.vMinVelocity 
		= D3DXVECTOR3(-0.5f, -0.5f, -0.5f);
	m_ParticleInfo.vMaxVelocity
		= D3DXVECTOR3(0.5f, 0.5f, 0.5f);

	
}


SkillEffect::~SkillEffect()
{
	Release();
}
