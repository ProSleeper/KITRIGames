#pragma once
class Particle;
class SkillEffect
{
	LPDIRECT3DTEXTURE9		m_pTexture;
	list<Particle*>			m_listParticle;
	ParticleInfo			m_ParticleInfo;

	int						m_nParticleCount;
	bool					m_bOneshot;
	float					m_fRespawnTime;
	float					m_fOldTime;

public:
	int GetListCount(void)
	{
		return (int)m_listParticle.size();
	}
	void CreateParticle(void);
	void CreateOneshotParticle(void);
	void Update(float dTime);
	void Render(void);
	void Release(void);

public:
	SkillEffect();
	virtual ~SkillEffect();
};

