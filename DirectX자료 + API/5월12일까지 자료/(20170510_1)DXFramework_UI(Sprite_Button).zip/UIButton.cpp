#include "stdafx.h"
#include "myTexture.h"
#include "baseUIControl.h"
#include "UIButton.h"


void UIButton::Init(int _x, int _y, string nor, 
				string over, string down)
{
	m_pTexture[BS_NORMAL] = TEXMGR->GetTexture(nor);
	m_pTexture[BS_OVER] = TEXMGR->GetTexture(over);
	m_pTexture[BS_DOWN] = TEXMGR->GetTexture(down);

	if (m_pTexture[BS_NORMAL])
	{
		m_nWidth = m_pTexture[BS_NORMAL]->GetWidth();
		m_nHeight = m_pTexture[BS_NORMAL]->GetHight();
	}
	baseUIControl::Init(_x, _y, m_nWidth, m_nHeight);
}

void UIButton::Render(void)
{
	if (m_bIsVisible == false) return;

	SPRITE->Begin(D3DXSPRITE_ALPHABLEND);

	RECT rc;
	SetRect(&rc, 0, 0, m_nWidth, m_nHeight);

	SPRITE->SetTransform(&m_mTM);

	SPRITE->Draw(m_pTexture[m_enButtonState]->GetTexture(),
		&rc, &D3DXVECTOR3(0, 0, 0), 
		&D3DXVECTOR3(0, 0, 0),
		D3DXCOLOR(1, 1, 1, 1));

	SPRITE->End();

	baseUIControl::Render();
}

void UIButton::OnMouseMove(int mouseX, int kmouseY)
{
	m_bPtInRect = IsPtInRect(mouseX, kmouseY);

	if (m_bPtInRect)
	{
		if (m_enButtonState != BS_DOWN)
			m_enButtonState = BS_OVER;
	}
	else
		m_enButtonState = BS_NORMAL;
}

void UIButton::OnLButtonDown(int mouseX, int kmouseY)
{
	if (m_bPtInRect)
		m_enButtonState = BS_DOWN;
}

void UIButton::OnLButtonUp(int mouseX, int kmouseY)
{
	if (m_bPtInRect)
	{
		m_enButtonState = BS_OVER;

		if (m_pDelegateFunc)
			m_pDelegateFunc();
	}
	else
		m_enButtonState = BS_NORMAL;
}

UIButton::UIButton()
	: m_enButtonState(BS_NORMAL)
	, m_pDelegateFunc(NULL)
{
	for (int i = 0; i < BS_MAX; ++i)
		m_pTexture[i] = NULL;
}


UIButton::~UIButton()
{
}
