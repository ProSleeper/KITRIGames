#pragma once
class baseUIDialog;
class baseUIControl
{
	PROPERTY_FUNC(string, Name, m_strName);
	PROPERTY_FUNC(baseUIControl*, 
					ParentUI, m_pParentUI);
	GETTER(D3DXMATRIX, TM, m_mTM);

protected:
	
	int				m_nWidth;
	int				m_nHeight;
	bool			m_bIsVisible;
	bool			m_bPtInRect;

	baseUIDialog*	m_pUI;

	D3DXVECTOR3		m_vPos;
	D3DXVECTOR3		m_vRot;
	D3DXVECTOR3		m_vScale;

	D3DXMATRIX		m_mTrans;
	D3DXMATRIX		m_mRot;
	D3DXMATRIX		m_mScale;

	list<baseUIControl*>	m_listChild;

public:
	virtual void Init(int _x, int _y, int _w, int _h);
	virtual void Update(float dTime);
	virtual void Render(void);
	virtual void Release(void);

	void WndProc(HWND hWnd, UINT message,
		WPARAM wParam, LPARAM lParam);
	virtual void OnMouseMove(int mouseX, int kmouseY) {};
	virtual void OnLButtonDown(int mouseX, int kmouseY) {};
	virtual void OnLButtonUp(int mouseX, int kmouseY) {};

	bool IsPtInRect(int _x, int y);

	void SetVisible(bool visible);
	void AddChild(baseUIControl* pUI);

public:
	baseUIControl();
	virtual ~baseUIControl();
};

