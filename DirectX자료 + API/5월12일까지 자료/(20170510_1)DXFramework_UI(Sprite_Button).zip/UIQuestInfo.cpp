#include "stdafx.h"
#include "UICommon.h"
#include "UIQuestInfo.h"


void UIQuestInfo::Init(string _uiname, int _x, int _y)
{
	m_strName = _uiname;

	// ui dialog
	m_pDialog = new UIImage;
	m_pDialog->Init(50, 50, "UI/panel-info.png.png");

	{
		// ok btn
		m_pBtnok = new UIButton;
		m_pBtnok->Init(150, 150,	"UI/btn-normal.png",
								"UI/btn-over.png",
								"UI/btn-Down.png");
		m_pBtnok->SetDelegateFunc(UIQuestInfo::BtnOKFunc);
		m_pDialog->AddChild(m_pBtnok);

		// BtnCancle
		m_pBtnCancle = new UIButton;
		m_pBtnCancle->Init(150, 250, "UI/btn-normal.png",
			"UI/btn-over.png",
			"UI/btn-Down.png");
		m_pBtnCancle->SetDelegateFunc(UIQuestInfo::BtnCancleFunc);
		m_pDialog->AddChild(m_pBtnCancle);
	}

	// �������� ��Ʈ
	m_pRoot = m_pDialog;
}

void UIQuestInfo::BtnOKFunc(void)
{
	MessageBox(NULL, "BtnOKFunc", "", MB_OK);
}

void UIQuestInfo::BtnCancleFunc(void)
{
	MessageBox(NULL, "BtnCancleFunc", "", MB_OK);
}

UIQuestInfo::UIQuestInfo()
{
	m_strName = "UIQuestInfo";
}


UIQuestInfo::~UIQuestInfo()
{
}
