#pragma once
class UIImage;
class UIButton;
class UIQuestInfo : public baseUIDialog
{
	GETTER(UIImage*, Dialog, m_pDialog);
	GETTER(UIButton*, BtnOK, m_pBtnok);
	GETTER(UIButton*, BtnCancle, m_pBtnCancle);

public:
	void Init(string _uiname, int _x, int _y);

	static void BtnOKFunc(void);
	static void BtnCancleFunc(void);

public:
	UIQuestInfo();
	virtual ~UIQuestInfo();
};

