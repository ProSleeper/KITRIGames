#pragma once

#define GAMEMGR GameManager::GetInstance()

class Player;
class WorldCamera;
class WorldAxis;
class GameManager
{
	SINGLETONE(GameManager);

	// ī�޶� //
	WorldCamera*		m_pCamera;

	// ���� Ŭ���� //
	WorldAxis*			m_pAxis;

	// ������Ʈ  //
	Player*		m_pPlayer;

public:
	void Setup(void);
	void GameLoop(void);
	void Update(void);
	void Render(void);
	void Release(void);
	void WndProc(HWND hWnd, UINT message, 
		WPARAM wParam, LPARAM lParam);
};

