#pragma once
class Player
{
	LPDIRECT3DVERTEXBUFFER9		m_pVB;
	LPDIRECT3DINDEXBUFFER9		m_pIB;

	D3DMATERIAL9			m_Material;

	// ��ֶ���
	D3DFVF_XYZ_COLOR	m_arrNormalLine[2];

	PROPERTY_FUNC(D3DXVECTOR3, Pos, m_vPos);
	D3DXVECTOR3			m_vRot;
	D3DXVECTOR3			m_vScale;
	D3DXVECTOR3			m_vDir;
	D3DXVECTOR3			m_vOrgDir;


	D3DXMATRIX			m_mTM;
	D3DXMATRIX			m_mTrans;
	D3DXMATRIX			m_mRot;
	D3DXMATRIX			m_mScale;

	void InitVB(void);
	void InitIB(void);

public:
	void Init(void);
	void Update(float dTime);
	void Render(void);
	void Release(void);

public:
	Player();
	virtual ~Player();
};

