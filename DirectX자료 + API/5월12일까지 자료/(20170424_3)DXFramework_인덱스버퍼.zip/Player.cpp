#include "stdafx.h"
#include "Player.h"


void Player::InitVB(void)
{
	D3DFVF_XYZ_NORMAL vtxs[] =
	{
		// �ո� {0, 1, 2}, {0, 2, 3}
		{ D3DXVECTOR3(-1, -1, -1), D3DXVECTOR3(0, 0, -1) }, // 0
		{ D3DXVECTOR3(-1, 1,  -1), D3DXVECTOR3(0, 0, -1) }, // 1
		{ D3DXVECTOR3(1, 1,  -1), D3DXVECTOR3(0, 0, -1) }, // 2
		{ D3DXVECTOR3(1, -1, -1), D3DXVECTOR3(0, 0, -1) },// 3

		// �޸� {4, 6, 5}, {4, 7, 6}											   // �ո� {0, 1, 2}, {0, 2, 3}
		{ D3DXVECTOR3(-1, -1, 1), D3DXVECTOR3(0, 0, 1) }, // 4
		{ D3DXVECTOR3(-1, 1, 1), D3DXVECTOR3(0, 0, 1) }, // 5
		{ D3DXVECTOR3(1, 1, 1), D3DXVECTOR3(0, 0, 1) }, // 6
		{ D3DXVECTOR3(1, -1, 1), D3DXVECTOR3(0, 0, 1) },// 7

		// ���� {8, 9, 10}, {8, 10, 11}											   // �ո� {0, 1, 2}, {0, 2, 3}
		{ D3DXVECTOR3(-1, 1, -1), D3DXVECTOR3(0, 1, 0) }, // 8
		{ D3DXVECTOR3(-1, 1, 1), D3DXVECTOR3(0, 1, 0) }, // 9
		{ D3DXVECTOR3(1, 1, 1), D3DXVECTOR3(0, 1, 0) }, // 10
		{ D3DXVECTOR3(1, 1, -1), D3DXVECTOR3(0, 1, 0) },// 11

		// �Ʒ��� {12, 14, 13}, {12, 15, 14}											   // �ո� {0, 1, 2}, {0, 2, 3}
		{ D3DXVECTOR3(-1, -1, -1), D3DXVECTOR3(0, -1, 0) }, // 12
		{ D3DXVECTOR3(-1, -1, 1), D3DXVECTOR3(0, -1, 0) }, // 13
		{ D3DXVECTOR3(1, -1, 1), D3DXVECTOR3(0, -1, 0) }, // 14
		{ D3DXVECTOR3(1, -1, -1), D3DXVECTOR3(0, -1, 0) },// 15

		// ������ {16, 17, 18}, {16, 18, 19}											   // �ո� {0, 1, 2}, {0, 2, 3}
		{ D3DXVECTOR3(1, -1, -1), D3DXVECTOR3(1, 0, 0) }, // 16
		{ D3DXVECTOR3(1,  1, -1), D3DXVECTOR3(1, 0, 0) }, // 17
		{ D3DXVECTOR3(1,  1, 1), D3DXVECTOR3(1, 0, 0) }, // 18
		{ D3DXVECTOR3(1,  -1, 1), D3DXVECTOR3(1, 0, 0) },// 19

		// ������ {20, 22, 21}, {20, 23, 22}											   // �ո� {0, 1, 2}, {0, 2, 3}
		{ D3DXVECTOR3(-1, -1, -1), D3DXVECTOR3(-1, 0, 0) }, // 20
		{ D3DXVECTOR3(-1,  1, -1), D3DXVECTOR3(-1, 0, 0) }, // 21
		{ D3DXVECTOR3(-1,  1, 1), D3DXVECTOR3(-1, 0, 0) }, // 22
		{ D3DXVECTOR3(-1,  -1, 1), D3DXVECTOR3(-1, 0, 0) },// 23
	};

	DEVICE->CreateVertexBuffer(sizeof(vtxs),
		0, D3DFVF_XYZ_NORMAL::FVF, D3DPOOL_DEFAULT,
		&m_pVB, NULL);

	if (m_pVB)
	{
		void* pData = NULL;

		m_pVB->Lock(0, sizeof(vtxs), &pData, 0);
		memcpy(pData, vtxs, sizeof(vtxs));
		m_pVB->Unlock();
	}
}

void Player::InitIB(void)
{
	D3D_INDEX indexs[] = 
	{
		{ 0, 1, 2 },{ 0, 2, 3 },		// �ո�
		{ 4, 6, 5 },{ 4, 7, 6 }	,	// �޸�
		{ 8, 9, 10 },{ 8, 10, 11 },	// ����
		{ 12, 14, 13 },{ 12, 15, 14 },	// �Ʒ���
		{ 16, 17, 18 },{ 16, 18, 19 },	// ����
		{ 20, 22, 21 },{ 20, 23, 22 }	// ����
	};

	DEVICE->CreateIndexBuffer(sizeof(indexs),
		0, D3DFMT_INDEX32, D3DPOOL_DEFAULT, &m_pIB, NULL);

	if (m_pIB)
	{
		void* pData = NULL;

		m_pIB->Lock(0, sizeof(indexs), &pData, 0);
		memcpy(pData, indexs, sizeof(indexs));
		m_pIB->Unlock();
	}
}

void Player::Init(void)
{
	InitVB();
	InitIB();

	m_Material.Diffuse = m_Material.Ambient
		= D3DXCOLOR(1, 0, 0, 1);


	// ��ֶ���
	m_arrNormalLine[0].vPos = D3DXVECTOR3(0, 0.5f, 0);
	m_arrNormalLine[0].color = D3DXCOLOR(0, 1, 0, 1);

	m_arrNormalLine[1].vPos = D3DXVECTOR3(0, 0.5f, 5);
	m_arrNormalLine[1].color = D3DXCOLOR(0, 1, 0, 1);
}

void Player::Update(float dTime)
{
	if (INPUTMGR->GetKey(VK_DOWN))
		m_vPos -= m_vDir * 5.0f * dTime;
	if (INPUTMGR->GetKey(VK_UP))
		m_vPos += m_vDir * 5.0f * dTime;

	if (INPUTMGR->GetKey(VK_LEFT))
	{
		m_vRot.y -= D3DX_PI *2 * dTime;
		D3DXVec3TransformNormal(&m_vDir,
			&m_vOrgDir, &m_mRot);
	}
	if (INPUTMGR->GetKey(VK_RIGHT))
	{
		m_vRot.y += D3DX_PI *2* dTime;
		D3DXVec3TransformCoord(&m_vDir,
			&m_vOrgDir, &m_mRot);
	}

	D3DXMatrixTranslation(&m_mTrans, m_vPos.x, m_vPos.y,
							m_vPos.z);
	D3DXMatrixScaling(&m_mScale, m_vScale.x,
				m_vScale.y, m_vScale.z);
	D3DXMatrixRotationYawPitchRoll(&m_mRot,
		m_vRot.y, m_vRot.x, m_vRot.z);

	m_mTM = m_mScale * m_mRot * m_mTrans;
}

void Player::Render(void)
{
	DWORD dwState;
	DEVICE->GetRenderState(D3DRS_FILLMODE, &dwState);
	DEVICE->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);

	//DEVICE->SetRenderState(D3DRS_FILLMODE, D3DFILL_WIREFRAME);

	DEVICE->SetTransform(D3DTS_WORLD, &m_mTM);
	DEVICE->SetMaterial(&m_Material);
	DEVICE->SetRenderState(D3DRS_LIGHTING, true);

	DEVICE->SetStreamSource(0, m_pVB, 0,
					sizeof(D3DFVF_XYZ_NORMAL));
	DEVICE->SetIndices(m_pIB);
	DEVICE->SetFVF(D3DFVF_XYZ_NORMAL::FVF);
	DEVICE->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 0, 0,
		24, 0, 12);
	

	DEVICE->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);
	DEVICE->SetRenderState(D3DRS_FILLMODE, dwState);
	DEVICE->SetRenderState(D3DRS_LIGHTING, false);

	// ��ֶ���
	DEVICE->SetFVF(D3DFVF_XYZ_COLOR::FVF);
	DEVICE->DrawPrimitiveUP(D3DPT_LINELIST, 1,
		&m_arrNormalLine, sizeof(D3DFVF_XYZ_COLOR));

}

void Player::Release(void)
{
	SAFE_RELEASE(m_pVB);
	SAFE_RELEASE(m_pIB);
}

Player::Player()
	: m_vPos(0,0,0)
	, m_vRot(0,0,0)
	, m_vScale(1,1,1)
	, m_vDir(0,0,1)
	, m_vOrgDir(0, 0, 1)
	, m_pVB(NULL)
	, m_pIB(NULL)
{
	D3DXMatrixIdentity(&m_mTM);
	D3DXMatrixIdentity(&m_mTrans);
	D3DXMatrixIdentity(&m_mRot);
	D3DXMatrixIdentity(&m_mScale);

	ZeroMemory(&m_Material, sizeof(m_Material));
}


Player::~Player()
{
}

