#pragma once

#define GAMEMGR GameManager::GetInstance()

class Player;
class WorldCamera;
class WorldAxis;
class WorldGrid;
class Rect;
class Bullet;
class GameManager
{
	SINGLETONE(GameManager);

	// ī�޶� //
	WorldCamera*		m_pCamera;

	// ���� Ŭ���� //
	WorldAxis*			m_pAxis;
	WorldGrid*			m_pGrid;

	// ������Ʈ  //
	Player*		m_pPlayer;
	Rect*		m_pRect;
	//Bullet*		m_pBullet;

	// �Ѿ� //
	list<Bullet*>			m_listBullets;
	void CreateBullet(D3DXVECTOR3 vPos, 
		D3DXVECTOR3 vRot,
		D3DXVECTOR3 vDir);
	void UpdateBullet(float dTime);
	void RenderBullet(void);
	void ReleaseBullet();

public:
	int GetBulletCount(void) { return (int)m_listBullets.size(); }
	float GetRectRadius(void);
	D3DXVECTOR3 GetRectPos(void);

	Player*	GetPlayerAddr(void);

public:
	void Setup(void);
	void GameLoop(void);
	void Update(float dTime);
	void Render(void);
	void DrawDebugFont(void);
	void Release(void);
	void WndProc(HWND hWnd, UINT message, 
		WPARAM wParam, LPARAM lParam);
};

