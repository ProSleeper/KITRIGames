#pragma once

#include "baseUIControl.h"

#include "UIImage.h"
#include "UIButton.h"
#include "UIText.h"

#include "baseUIDialog.h"

#include "UIQuestInfo.h"
#include "UIMain.h"
