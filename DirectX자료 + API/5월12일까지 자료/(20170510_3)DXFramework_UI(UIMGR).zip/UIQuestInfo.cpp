#include "stdafx.h"
#include "UICommon.h"
#include "UIQuestInfo.h"


void UIQuestInfo::Init(string _uiname, int _x, int _y)
{
	m_strName = _uiname;

	// ui dialog
	m_pDialog = new UIImage;
	m_pDialog->Init(50, 50, "UI/panel-info.png.png");

	{
		// ok btn
		m_pBtnok = new UIButton;
		m_pBtnok->Init(150, 250,	"UI/btn-normal.png",
								"UI/btn-over.png",
								"UI/btn-Down.png");
		m_pBtnok->SetDelegateFunc(UIQuestInfo::BtnOKFunc);
		m_pDialog->AddChild(m_pBtnok);

		// BtnCancle
		m_pBtnCancle = new UIButton;
		m_pBtnCancle->Init(150, 350, "UI/btn-normal.png",
			"UI/btn-over.png",
			"UI/btn-Down.png");
		m_pBtnCancle->SetDelegateFunc(UIQuestInfo::BtnCancleFunc);
		m_pDialog->AddChild(m_pBtnCancle);

		// Text
		m_pUIText = new UIText;
		m_pUIText->Init(100, 100, 300, 100, FT_BOADER);
		m_pUIText->SetdarwType(DT_LEFT | DT_WORDBREAK);
		m_pUIText->SetText("�ѱ�������������� �뻧 ���ػ� 5ȸ óġ�϶�");
		m_pDialog->AddChild(m_pUIText);
	}

	// �������� ��Ʈ
	m_pRoot = m_pDialog;
	m_pRoot->SetDialog(this);
}

void UIQuestInfo::BtnOKFunc(baseUIDialog* pDlg, baseUIControl* pControl)
{
	UIQuestInfo* pUI = (UIQuestInfo*)pDlg;

	pUI->GetText()->SetText("�̼�Ŭ����~");
}

void UIQuestInfo::BtnCancleFunc(baseUIDialog* pDlg, baseUIControl* pControl)
{
	UIQuestInfo* pUI = (UIQuestInfo*)pDlg;

	pUI->GetText()->SetText("�̼� ����~");
	pControl->SetVisible(false);
}

UIQuestInfo::UIQuestInfo()
{
	m_strName = "UIQuestInfo";
}


UIQuestInfo::~UIQuestInfo()
{
}
