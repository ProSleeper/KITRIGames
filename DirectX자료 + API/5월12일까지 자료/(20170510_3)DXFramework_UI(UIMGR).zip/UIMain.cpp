#include "stdafx.h"
#include "UICommon.h"
#include "UIMain.h"


void UIMain::Init(string _uiName, int _x, int _y)
{
	m_strName = _uiName;

	// btn
	m_pBtn = new UIButton;
	m_pBtn->Init(_x, _y, "UI/opton_normal.png",
		"UI/option_Over.png", "UI/option_Down.png");
	m_pBtn->SetDelegateFunc(UIMain::BtnClick);

	// ������
	m_pRoot = m_pBtn;
	m_pRoot->SetDialog(this);
}

void UIMain::BtnClick(baseUIDialog * _pDlg,
	baseUIControl * pCtrl)
{
	UIMain* pUI = (UIMain*)_pDlg;
	pUI->SettargetActive(!pUI->GettargetActive());

	if (pUI->GettargetActive())
		UIMGR->ShowUI("UIQuestInfo");
	else
		UIMGR->HideUI("UIQuestInfo");
}

UIMain::UIMain()
	: m_pBtn(NULL)
	, m_bTargetActive(false)
{
}


UIMain::~UIMain()
{
}
