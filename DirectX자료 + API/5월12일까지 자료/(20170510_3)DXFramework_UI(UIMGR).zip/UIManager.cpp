#include "stdafx.h"
#include "UICommon.h"
#include "UIManager.h"


UIManager::UIManager()
{
	m_mapUI.clear();
	m_listShowUI.clear();
}


UIManager::~UIManager()
{
	Release();
}

void UIManager::Init(void)
{
	UIMain*		pUI = new UIMain;
	pUI->Init("UIMain", 800 -100, 20);

	m_mapUI["UIMain"] = pUI;
	m_mapUI["UIMain"]->SetVisible(true);

	UIQuestInfo* pQuestUI = new UIQuestInfo;
	pQuestUI->Init("UIQuestInfo", 0, 0);
	m_mapUI["UIQuestInfo"] = pQuestUI;

	m_listShowUI.push_back(pUI);
}

void UIManager::Update(float dTime)
{
	for each(auto p in m_listShowUI)
		p->Update(dTime);
}

void UIManager::Render(void)
{
	for each(auto p in m_listShowUI)
		p->Render();
}

void UIManager::Release(void)
{
	m_listShowUI.clear();

	for each(auto p in m_mapUI)
		SAFE_DELETE(p.second);

	m_mapUI.clear();
}

void UIManager::WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	for each(auto p in m_listShowUI)
		p->WndProc(hWnd, message, wParam, lParam);
}

void UIManager::ShowUI(string uiName)
{
	m_mapUI[uiName]->SetVisible(true);

	for each (auto p in m_listShowUI)
	{
		if (p == m_mapUI[uiName])
			return;
	}

	m_listShowUI.push_back(m_mapUI[uiName]);
}

void UIManager::HideUI(string uiName)
{
	m_mapUI[uiName]->SetVisible(false);

	for (list<baseUIDialog*>::iterator itor
				= m_listShowUI.begin();
				itor != m_listShowUI.end(); )
	{
		if ((*itor) == m_mapUI[uiName])
			itor = m_listShowUI.erase(itor);
		else
			++itor;
	}
}
