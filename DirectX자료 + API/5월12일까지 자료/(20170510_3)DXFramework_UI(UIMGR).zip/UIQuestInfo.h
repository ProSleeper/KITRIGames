#pragma once
class UIImage;
class UIButton;
class UIText;
class UIQuestInfo : public baseUIDialog
{
	GETTER(UIImage*, Dialog, m_pDialog);
	GETTER(UIButton*, BtnOK, m_pBtnok);
	GETTER(UIButton*, BtnCancle, m_pBtnCancle);
	GETTER(UIText*, Text, m_pUIText);

public:
	void Init(string _uiname, int _x, int _y);

	static void BtnOKFunc(baseUIDialog* pDlg, baseUIControl* pControl);
	static void BtnCancleFunc(baseUIDialog* pDlg, baseUIControl* pControl);

public:
	UIQuestInfo();
	virtual ~UIQuestInfo();
};

