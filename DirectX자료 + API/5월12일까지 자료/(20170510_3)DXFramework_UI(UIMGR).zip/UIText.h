#pragma once
class UIText : public baseUIControl
{
	LPD3DXFONT		m_pFont;

	PROPERTY_FUNC(string, Text, m_strText);
	PROPERTY_FUNC(DWORD, darwType, m_dwDrawType);
	PROPERTY_FUNC(D3DXCOLOR, color, m_color);

public:
	void Init(int _x, int _y, int _w, int _h);
	void Init(int _x, int _y, int _w, int _h,
				FONTTYPE enType);
	void Init(int _x, int _y, int _w, int _h,
		FONTTYPE enType, DWORD drawType,
		D3DXCOLOR color);
	void Render(void);

public:
	UIText();
	virtual ~UIText();
};

