#include "stdafx.h"
#include "baseUIControl.h"
#include "UIText.h"


void UIText::Init(int _x, int _y, int _w, int _h)
{
	m_pFont = FONTMGR->GetFont();

	baseUIControl::Init(_x, _y, _w, _h);
}

void UIText::Init(int _x, int _y, int _w, int _h,
	FONTTYPE enType)
{
	m_pFont = FONTMGR->GetFonts(enType);

	baseUIControl::Init(_x, _y, _w, _h);
}

void UIText::Init(int _x, int _y, int _w, int _h, 
	FONTTYPE enType, DWORD drawType, D3DXCOLOR color)
{
	m_pFont = FONTMGR->GetFonts(enType);

	m_dwDrawType = drawType;
	m_color = color;

	baseUIControl::Init(_x, _y, _w, _h);
}

void UIText::Render(void)
{
	if (m_bIsVisible == false) return;

	//SPRITE->Begin(D3DXSPRITE_ALPHABLEND);

	RECT rc;
	D3DXVECTOR3 _vUIPos;

	if (m_pParentUI)
	{
		D3DXVec3TransformCoord(&_vUIPos,
			&m_vPos, &m_pParentUI->GetTM());
	}
	else
	{
		_vUIPos = m_vPos;
	}

	SetRect(&rc, _vUIPos.x, _vUIPos.y,
		_vUIPos.x + m_nWidth,
		_vUIPos.y + m_nHeight);

	m_pFont->DrawText(NULL, m_strText.c_str(),
		m_strText.length(), &rc,
		m_dwDrawType, m_color);

	//SPRITE->End();
}

UIText::UIText()
	: m_pFont(NULL)
	, m_strText("")
	, m_dwDrawType(DT_CENTER)
	, m_color(1,1,1,1)
{
}


UIText::~UIText()
{
}
