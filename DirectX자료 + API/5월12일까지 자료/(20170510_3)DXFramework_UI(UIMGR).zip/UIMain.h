#pragma once
class UIMain : public baseUIDialog
{
	GETTER(UIButton*, Button, m_pBtn);
	PROPERTY_FUNC(bool, targetActive, m_bTargetActive);

public:
	void Init(string _uiName, int _x, int _y);

	static void BtnClick(baseUIDialog* _pDlg,
						baseUIControl* pCtrl);

public:
	UIMain();
	virtual ~UIMain();
};

