#pragma once

#define UIMGR UIManager::GetInstance()

class baseUIDialog;
class UIManager
{
	SINGLETONE(UIManager);

	map<string, baseUIDialog*>		m_mapUI;
	list<baseUIDialog*>				m_listShowUI;

public:
	void Init(void);
	void Update(float dTime);
	void Render(void);
	void Release(void);
	void WndProc(HWND hWnd,
		UINT message, WPARAM wParam, LPARAM lParam);

	void ShowUI(string uiName);
	void HideUI(string uiName);

};

