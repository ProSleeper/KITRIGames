#pragma once
class baseUIControl;
class baseUIDialog
{
	PROPERTY_FUNC(string, Name, m_strName);

protected:
	bool			m_bIsVisible;
	baseUIControl*	m_pRoot;

public:
	virtual void Init(string _uiname, int _x, int _y) = 0;
	virtual void Update(float dTime);
	virtual void Render(void);
	virtual void Release(void);

	void WndProc(HWND hWnd, UINT message,
		WPARAM wParam, LPARAM lParam);

	void SetVisible(bool visible);

public:
	baseUIDialog();
	virtual ~baseUIDialog();
};

