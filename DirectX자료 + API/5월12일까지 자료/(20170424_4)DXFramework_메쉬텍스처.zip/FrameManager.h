#pragma once

#define FRAMEMGR FrameManager::GetInstance()

class FrameManager
{
	SINGLETONE(FrameManager);

	DWORD		m_dwDeltaTime;
	DWORD		m_OldDeltaTime;

	DWORD		m_dwFPS;
	DWORD		m_dwFPSCount;
	DWORD		m_dwOldFPS;

public:
	void Update(void);
	int GetFPS(void) { return (int)m_dwFPS; }
	float GetDeltaTime(void)
	{
		return m_dwDeltaTime / 1000.0f; 
	}
};

