#include "stdafx.h"
#include "Player.h"
#include "WorldAxis.h"
#include "WorldCamera.h"
#include "WorldGrid.h"
#include "GameManager.h"


GameManager::GameManager()
	: m_pPlayer(NULL)
	, m_pCamera(NULL)
	, m_pAxis(NULL)
	, m_pGrid(NULL)
	, m_pLightObject(NULL)
{
	ZeroMemory(&m_Light, sizeof(m_Light));
}


GameManager::~GameManager()
{
	Release();
}

void GameManager::Setup(void)
{
	DXMGR->Setup();
	INPUTMGR->SetUp();
	FONTMGR->Setup();

	// ���� //
	D3DLIGHT9 l;
	ZeroMemory(&l, sizeof(l));
	l.Type = D3DLIGHT_DIRECTIONAL;
	l.Diffuse = D3DXCOLOR(1, 1, 1, 1);
	l.Direction = D3DXVECTOR3(0, -1, 1);

	DEVICE->SetLight(0, &l);
	DEVICE->LightEnable(0, true);

	// ī�޶� �¾� //
	m_pCamera = new WorldCamera;
	m_pCamera->SetUp(D3DXVECTOR3(0, 5, -5));

	// ���� Ŭ���� //
	m_pAxis = new WorldAxis;
	m_pAxis->Setup();
	m_pGrid = new WorldGrid;
	m_pGrid->Setup();

	// ������Ʈ //
	m_pPlayer = new Player;
	m_pPlayer->Init();

	D3DXCreateSphere(DEVICE, 2.0f, 60, 60, 
		&m_pLightObject, NULL);
}

void GameManager::GameLoop(void)
{
	FRAMEMGR->Update();

	float dTime = FRAMEMGR->GetDeltaTime();

	Update(dTime);
	Render();
}

void GameManager::Update(float dTime)
{
	INPUTMGR->Update();

	m_pPlayer->Update(dTime);
}

void GameManager::Render(void)
{
	DEVICE->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,
					D3DXCOLOR(0.6f, 0.6f, 0.6f, 1), 1, 0);

	DEVICE->BeginScene();
	{
		// �Ʒ����� �׸���
		m_pPlayer->Render();

		// �� //
		D3DXMATRIX mTM;
		D3DXMatrixIdentity(&mTM);
		mTM._41 = 10.0f;
		DEVICE->SetTransform(D3DTS_WORLD, &mTM);

		D3DMATERIAL9 m;
		ZeroMemory(&m, sizeof(m));
		m.Diffuse = m.Ambient = D3DXCOLOR(1, 1, 1, 1);
		DEVICE->SetMaterial(&m);

		DEVICE->SetRenderState(D3DRS_LIGHTING, true);

		m_pLightObject->DrawSubset(0);
		DEVICE->SetRenderState(D3DRS_LIGHTING, false);


		// ������Ʈ �ٱ׸��� ���� Ŭ���� �׸���
		//m_pGrid->Render();
		//m_pAxis->Render();

		// ��Ʈ�� ���� ������
		DrawDebugFont();
	}
	DEVICE->EndScene();

	DEVICE->Present(NULL, NULL, NULL, NULL);
}

void GameManager::DrawDebugFont(void)
{
	int _x = 10;
	int _y = 10;

	D3DXCOLOR _color = D3DXCOLOR(0, 1, 0, 1);

	FONTMGR->DrawText(_x, _y, _color, "FPS : %d",
					FRAMEMGR->GetFPS());

	_y += 15;
	D3DFVF_XYZ_NORMAL_TEX1* pVtxs = 
					m_pPlayer->GetBoxVexAddr();
	for (int i = 0; i < 24; ++i)
	{
		D3DXVECTOR3 _vPos = pVtxs[i].vPos;
		D3DXVECTOR3 _vNor = pVtxs[i].vNormal;
		float u = pVtxs[i].u;
		float v = pVtxs[i].v;

		FONTMGR->DrawText(_x, _y += 15,
			D3DXCOLOR(0, 0, 0, 1),
			"(%d) pos(%.2f,%.2f,%.2f) nor(%.2f,%.2f,%.2f) u(%.2f) v(%.2f)",
			i, _vPos.x, _vPos.y, _vPos.z,
			_vNor.x, _vNor.y, _vNor.z, u, v);
			
	}
}

void GameManager::Release(void)
{
	SAFE_DELETE(m_pPlayer);
	SAFE_DELETE(m_pCamera);
	SAFE_DELETE(m_pAxis);
}

void GameManager::WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	m_pCamera->WndProc(hWnd, message, wParam, lParam);
}
