#pragma once
class UIImage;
class UIQuestInfo : public baseUIDialog
{
	GETTER(UIImage*, Dialog, m_pDialog);

public:
	void Init(string _uiname, int _x, int _y);

public:
	UIQuestInfo();
	virtual ~UIQuestInfo();
};

