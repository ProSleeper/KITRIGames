#include "stdafx.h"
#include "UICommon.h"
#include "UIQuestInfo.h"


void UIQuestInfo::Init(string _uiname, int _x, int _y)
{
	m_strName = _uiname;

	// ui dialog
	m_pDialog = new UIImage;
	m_pDialog->Init(0, 0, "UI/panel-info.png.png");

	// �������� ��Ʈ
	m_pRoot = m_pDialog;
}

UIQuestInfo::UIQuestInfo()
{
	m_strName = "UIQuestInfo";
}


UIQuestInfo::~UIQuestInfo()
{
}
