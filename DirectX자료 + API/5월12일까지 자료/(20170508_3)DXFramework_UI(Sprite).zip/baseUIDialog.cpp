#include "stdafx.h"
#include "baseUIControl.h"
#include "baseUIDialog.h"


void baseUIDialog::Update(float dTime)
{
	m_pRoot->Update(dTime);
}

void baseUIDialog::Render(void)
{
	m_pRoot->Render();
}

void baseUIDialog::Release(void)
{
	m_pRoot->Release();
}

void baseUIDialog::WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	m_pRoot->WndProc(hWnd, message, wParam, lParam);
}

void baseUIDialog::SetVisible(bool visible)
{
	m_pRoot->SetVisible(visible);
}

baseUIDialog::baseUIDialog()
	: m_strName("none")
	, m_bIsVisible(false)
{
	
}


baseUIDialog::~baseUIDialog()
{
}
