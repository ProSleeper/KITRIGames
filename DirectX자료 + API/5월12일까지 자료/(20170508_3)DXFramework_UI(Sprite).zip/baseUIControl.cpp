#include "stdafx.h"
#include "baseUIControl.h"


void baseUIControl::Init(int _x, int _y, int _w, int _h)
{
	m_vPos = D3DXVECTOR3(float(_x), float(_y), 0.0f);
	m_nWidth = _w;
	m_nHeight = _h;
}

void baseUIControl::Update(float dTime)
{
	if (m_bIsVisible == false)  return;

	D3DXMatrixTranslation(&m_mTrans,
		m_vPos.x, m_vPos.y, m_vPos.z);
	D3DXMatrixRotationYawPitchRoll(&m_mRot,
		m_vRot.y, m_vRot.x, m_vRot.z);
	D3DXMatrixScaling(&m_mScale,
		m_vScale.x, m_vScale.y, m_vScale.z);

	if (m_pParentUI)
	{
		m_mTM = m_mScale * m_mRot * m_mTrans
				* (m_pParentUI->GetTM());
	}
	else
		m_mTM = m_mScale * m_mRot * m_mTrans;

	// �ڽ� ȣ��
	for each(auto p in m_listChild)
	{
		p->Update(dTime);
	}
}

void baseUIControl::Render(void)
{
	if (m_bIsVisible == false)  return;

	// �ڽ� ȣ��
	for each(auto p in m_listChild)
	{
		p->Render();
	}
}

void baseUIControl::Release(void)
{
	// �ڽ� ȣ��
	for each(auto p in m_listChild)
	{
		p->Release();
	}

	delete this;
}

void baseUIControl::WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	if (m_bIsVisible == false)  return;

	// �ڽ� ȣ��
	for each(auto p in m_listChild)
	{
		p->WndProc(hWnd, message, wParam, lParam);
	}

	switch (message)
	{
	case WM_MOUSEMOVE:
		OnMouseMove(LOWORD(lParam), HIWORD(lParam));
		break;
	case WM_LBUTTONDOWN:
		OnLButtonDown(LOWORD(lParam), HIWORD(lParam));
		break;
	case WM_LBUTTONUP:
		OnLButtonUp(LOWORD(lParam), HIWORD(lParam));
		break;
	}
}

void baseUIControl::SetVisible(bool visible)
{
	m_bIsVisible = visible;

	for each(auto p in m_listChild)
		p->SetVisible(visible);
}

void baseUIControl::AddChild(baseUIControl * pUI)
{
	m_listChild.push_back(pUI);

	pUI->SetParentUI(this);
}

baseUIControl::baseUIControl()
	: m_pParentUI(NULL)
	, m_pUI(NULL)
	, m_nWidth(0)
	, m_nHeight(0)
	, m_bIsVisible(false)
	, m_bPtInRect(false)
	, m_vPos(0,0,0)
	, m_vRot(0,0,0)
	, m_vScale(1,1,1)
	, m_strName("none")
{
	m_listChild.clear();

	D3DXMatrixIdentity(&m_mTM);
	D3DXMatrixIdentity(&m_mTrans);
	D3DXMatrixIdentity(&m_mRot);
	D3DXMatrixIdentity(&m_mScale);
}


baseUIControl::~baseUIControl()
{
}
