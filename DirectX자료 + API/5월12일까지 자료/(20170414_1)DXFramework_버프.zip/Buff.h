#pragma once
class Buff
{
	PROPERTY_FUNC(D3DXMATRIX*, ParentTM, m_pParentTM);

	D3DFVF_XYZ_COLOR	m_arrVertexs[3];

	PROPERTY_FUNC(D3DXVECTOR3, Pos, m_vPos);
	GETTER(D3DXVECTOR3, CullPos, m_vCullPos);
	D3DXVECTOR3			m_vRot;
	D3DXVECTOR3			m_vScale;

	D3DXMATRIX			m_mTM;
	D3DXMATRIX			m_mTrans;
	D3DXMATRIX			m_mRot;
	D3DXMATRIX			m_mScale;

public:
	void Init(void);
	void Update(float dTime);
	void Render(void);
	void Release(void);

public:
	Buff();
	virtual ~Buff();
};

