#include "stdafx.h"
#include "Buff.h"


void Buff::Init(void)
{
	m_arrVertexs[0].vPos = D3DXVECTOR3(-0.5f, 0, 0);
	m_arrVertexs[0].color = D3DXCOLOR(1, 0, 0, 1);

	m_arrVertexs[1].vPos = D3DXVECTOR3(0, 0.5f, 0);
	m_arrVertexs[1].color = D3DXCOLOR(0, 1, 0, 1);

	m_arrVertexs[2].vPos = D3DXVECTOR3(0.5f, 0, 0);
	m_arrVertexs[2].color = D3DXCOLOR(0, 0, 1, 1);

	m_pParentTM = GAMEMGR->GetPlayerTransTM();
}

void Buff::Update(float dTime)
{
	m_vRot.y += D3DX_PI * dTime;

	D3DXMatrixTranslation(&m_mTrans, m_vPos.x, m_vPos.y,
		m_vPos.z);
	D3DXMatrixScaling(&m_mScale, m_vScale.x,
		m_vScale.y, m_vScale.z);
	D3DXMatrixRotationYawPitchRoll(&m_mRot,
		m_vRot.y, m_vRot.x, m_vRot.z);

	if (m_pParentTM)
	{
		m_mTM = m_mScale  * m_mTrans * m_mRot * (*m_pParentTM);

		D3DXMATRIX moveTM;
		D3DXMatrixInverse(&moveTM, 0, &(m_mScale  * m_mTrans * m_mRot));
		

		D3DXVec3TransformCoord(&m_vCullPos, &m_vPos,
			&(moveTM*m_mTM));
	}
	else
		m_mTM = m_mScale  * m_mTrans * m_mRot;

}

void Buff::Render(void)
{
	DEVICE->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
		DEVICE->SetTransform(D3DTS_WORLD, &m_mTM);

	DEVICE->SetRenderState(D3DRS_LIGHTING, false);
	DEVICE->SetFVF(D3DFVF_XYZ_COLOR::FVF);
	DEVICE->DrawPrimitiveUP(
		D3DPT_TRIANGLELIST,		// �׸��¹��
		1,						// �ﰢ�� ����
		&m_arrVertexs,			// ���ؽ� ����
		sizeof(D3DFVF_XYZ_COLOR)// �������� ������
	);

	DEVICE->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);
}

void Buff::Release(void)
{
}

Buff::Buff()
	: m_vPos(3, 0, 0)
	, m_vRot(0, 0, 0)
	, m_vScale(1, 1, 1)
	, m_pParentTM(NULL)
	, m_vCullPos(0,0,0)
{
	D3DXMatrixIdentity(&m_mTM);
	D3DXMatrixIdentity(&m_mTrans);
	D3DXMatrixIdentity(&m_mRot);
	D3DXMatrixIdentity(&m_mScale);
}


Buff::~Buff()
{
	Release();
}
