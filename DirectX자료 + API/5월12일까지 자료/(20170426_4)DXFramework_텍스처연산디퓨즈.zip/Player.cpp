#include "stdafx.h"
#include "Player.h"




void Player::Init(void)
{
	LPD3DXMESH orgMesh;
	D3DXCreateBox(DEVICE, 2, 2, 2, &orgMesh, NULL);
	orgMesh->CloneMeshFVF(orgMesh->GetOptions(),
		D3DFVF_XYZ_NORMAL_TEX1::FVF, DEVICE, &m_pMesh);
	SAFE_RELEASE(orgMesh);

	D3DFVF_XYZ_NORMAL_TEX1* meshVtxs;
	int numVextex = m_pMesh->GetNumVertices();
	m_pMesh->LockVertexBuffer(0, (void**)&meshVtxs);

	meshVtxs[0].u = 0;
	meshVtxs[0].v = 1;

	meshVtxs[1].u = 1;
	meshVtxs[1].v = 1;

	meshVtxs[2].u = 1;
	meshVtxs[2].v = 0;

	meshVtxs[3].u = 0;
	meshVtxs[3].v = 0;

	for (int i = 0; i < numVextex; ++i)
	{
		m_BoxVex[i].vPos = meshVtxs[i].vPos;
		m_BoxVex[i].vNormal = meshVtxs[i].vNormal;
		m_BoxVex[i].u = meshVtxs[i].u;
		m_BoxVex[i].v = meshVtxs[i].v;
	}

	m_pMesh->UnlockVertexBuffer();


	m_Material.Diffuse = m_Material.Ambient
		= D3DXCOLOR(1, 1, 1, 1);


	// ��ֶ���
	m_arrNormalLine[0].vPos = D3DXVECTOR3(0, 0.5f, 0);
	m_arrNormalLine[0].color = D3DXCOLOR(0, 1, 0, 1);

	m_arrNormalLine[1].vPos = D3DXVECTOR3(0, 0.5f, 5);
	m_arrNormalLine[1].color = D3DXCOLOR(0, 1, 0, 1);

	D3DXCreateTextureFromFile(DEVICE, "texture.jpg",
		&m_pTexture);
}

void Player::Update(float dTime)
{
	if (INPUTMGR->GetKey(VK_DOWN))
		m_vPos -= m_vDir * 5.0f * dTime;
	if (INPUTMGR->GetKey(VK_UP))
		m_vPos += m_vDir * 5.0f * dTime;

	if (INPUTMGR->GetKey(VK_LEFT))
	{
		m_vRot.y -= D3DX_PI *2 * dTime;
		D3DXVec3TransformNormal(&m_vDir,
			&m_vOrgDir, &m_mRot);
	}
	if (INPUTMGR->GetKey(VK_RIGHT))
	{
		m_vRot.y += D3DX_PI *2* dTime;
		D3DXVec3TransformCoord(&m_vDir,
			&m_vOrgDir, &m_mRot);
	}

	D3DXMatrixTranslation(&m_mTrans, m_vPos.x, m_vPos.y,
							m_vPos.z);
	D3DXMatrixScaling(&m_mScale, m_vScale.x,
				m_vScale.y, m_vScale.z);
	D3DXMatrixRotationYawPitchRoll(&m_mRot,
		m_vRot.y, m_vRot.x, m_vRot.z);

	m_mTM = m_mScale * m_mRot * m_mTrans;
}

void Player::Render(void)
{
	DEVICE->SetTransform(D3DTS_WORLD, &m_mTM);
	DEVICE->SetMaterial(&m_Material);
	DEVICE->SetRenderState(D3DRS_LIGHTING, true);

	DEVICE->SetTexture(0, m_pTexture);
	DEVICE->SetTextureStageState(0,
		D3DTSS_COLORARG1, D3DTA_DIFFUSE);
	DEVICE->SetTextureStageState(0,
		D3DTSS_COLOROP, D3DTOP_SELECTARG1);

	m_pMesh->DrawSubset(0);

	DEVICE->SetRenderState(D3DRS_LIGHTING, false);

	// ��ֶ���
	DEVICE->SetFVF(D3DFVF_XYZ_COLOR::FVF);
	DEVICE->DrawPrimitiveUP(D3DPT_LINELIST, 1,
		&m_arrNormalLine, sizeof(D3DFVF_XYZ_COLOR));

}

void Player::Release(void)
{
	SAFE_RELEASE(m_pMesh);
	SAFE_RELEASE(m_pTexture);

}

Player::Player()
	: m_vPos(0,0,0)
	, m_vRot(0,0,0)
	, m_vScale(1,1,1)
	, m_vDir(0,0,1)
	, m_vOrgDir(0, 0, 1)
	, m_pTexture(NULL)
	, m_pMesh(NULL)
{
	D3DXMatrixIdentity(&m_mTM);
	D3DXMatrixIdentity(&m_mTrans);
	D3DXMatrixIdentity(&m_mRot);
	D3DXMatrixIdentity(&m_mScale);

	ZeroMemory(&m_Material, sizeof(m_Material));
}


Player::~Player()
{
}

