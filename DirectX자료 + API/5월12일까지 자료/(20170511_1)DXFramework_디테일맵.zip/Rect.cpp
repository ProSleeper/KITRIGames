#include "stdafx.h"
#include "mouseRay.h"
#include "Rect.h"


void Rect::Init(void)
{
	m_arrVertexs[0].vPos = D3DXVECTOR3(-50, 0, -50);
	m_arrVertexs[0].u = 0;
	m_arrVertexs[0].v = 1;
	m_arrVertexs[0].u1 = 0;
	m_arrVertexs[0].v1 = 50;

	m_arrVertexs[1].vPos = D3DXVECTOR3(-50, 0, 50);
	m_arrVertexs[1].u = 0;
	m_arrVertexs[1].v = 0;
	m_arrVertexs[1].u1 = 0;
	m_arrVertexs[1].v1 = 0 ;

	m_arrVertexs[2].vPos = D3DXVECTOR3(50, 0, 50);
	m_arrVertexs[2].u = 1;
	m_arrVertexs[2].v = 0;
	m_arrVertexs[2].u1 = 50;
	m_arrVertexs[2].v1 = 0;

	m_arrVertexs[3].vPos = D3DXVECTOR3(-50, 0, -50);
	m_arrVertexs[3].u = 0;
	m_arrVertexs[3].v = 1;
	m_arrVertexs[3].u1 = 0;
	m_arrVertexs[3].v1 = 50;

	m_arrVertexs[4].vPos = D3DXVECTOR3(50, 0, 50);
	m_arrVertexs[4].u = 1;
	m_arrVertexs[4].v = 0;
	m_arrVertexs[4].u1 = 50;
	m_arrVertexs[4].v1 = 0;

	m_arrVertexs[5].vPos = D3DXVECTOR3(50, 0, -50);
	m_arrVertexs[5].u = 1;
	m_arrVertexs[5].v = 1;
	m_arrVertexs[5].u1 = 50;
	m_arrVertexs[5].v1 = 50;
	//D3DXCreateTextureFromFile(DEVICE, "texture.jpg", 
		//			&m_pTexture);
	D3DXCreateTextureFromFile(DEVICE, "Field1.dds", 
						&m_pTexture);
}

void Rect::Update(float dTime)
{
	//m_vRot.y += D3DX_PI *dTime;

	D3DXMatrixTranslation(&m_mTrans, m_vPos.x, m_vPos.y,
		m_vPos.z);
	D3DXMatrixScaling(&m_mScale, m_vScale.x,
		m_vScale.y, m_vScale.z);
	D3DXMatrixRotationYawPitchRoll(&m_mRot,
		m_vRot.y, m_vRot.x, m_vRot.z);

	m_mTM = m_mScale * m_mRot * m_mTrans;
}

void Rect::Render(void)
{
	DEVICE->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
	DEVICE->SetTransform(D3DTS_WORLD, &m_mTM);

	DEVICE->SetTexture(0, m_pTexture);
	DEVICE->SetTextureStageState(0, D3DTSS_COLOROP,
							D3DTOP_MODULATE);
	DEVICE->SetTextureStageState(0, D3DTSS_COLORARG1,
		D3DTA_TEXTURE);
	DEVICE->SetTextureStageState(0, D3DTSS_COLORARG2,
		D3DTA_DIFFUSE);
	DEVICE->SetTextureStageState(0,
		D3DTSS_TEXCOORDINDEX, 0);


	DEVICE->SetTexture(1, m_pTexture);
	DEVICE->SetTextureStageState(1, D3DTSS_COLOROP,
		D3DTOP_MODULATE);
	DEVICE->SetTextureStageState(1, D3DTSS_COLORARG1,
		D3DTA_TEXTURE);
	DEVICE->SetTextureStageState(1, D3DTSS_COLORARG2,
		D3DTA_CURRENT);
	DEVICE->SetTextureStageState(1,
		D3DTSS_TEXCOORDINDEX, 1);


	DEVICE->SetRenderState(D3DRS_LIGHTING, false);
	DEVICE->SetFVF(D3DFVF_XYZ_TEX2::FVF);
	DEVICE->DrawPrimitiveUP(
		D3DPT_TRIANGLELIST,		// �׸��¹��
		2,						// �ﰢ�� ����
		&m_arrVertexs,			// ���ؽ� ����
		sizeof(D3DFVF_XYZ_TEX2)// �������� ������
	);

	DEVICE->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);
}

void Rect::Release(void)
{
}

D3DXVECTOR3 Rect::GetPickPos(mouseRay ray)
{
	D3DXVECTOR3 vResult(0,0,0);
	float _u, _v, _dist;
	
	if (D3DXIntersectTri(&m_arrVertexs[0].vPos,
		&m_arrVertexs[1].vPos, &m_arrVertexs[2].vPos,
		&ray.Getpos(), &ray.Getdir(), &_u, &_v, &_dist))
	{
		//MessageBox(NULL, "���ʻﰢ�� ��ŷ", "����", MB_OK);
		//vResult = ray.Getpos() + ray.Getdir() * _dist;
		vResult = m_arrVertexs[0].vPos +
			(_u *(m_arrVertexs[1].vPos - m_arrVertexs[0].vPos))
			+ (_v *(m_arrVertexs[2].vPos - m_arrVertexs[0].vPos));
	}

	if (D3DXIntersectTri(&m_arrVertexs[3].vPos,
		&m_arrVertexs[4].vPos, &m_arrVertexs[5].vPos,
		&ray.Getpos(), &ray.Getdir(), &_u, &_v, &_dist))
	{
		//MessageBox(NULL, "�Ʒ��ﰢ�� ��ŷ", "����", MB_OK);
		//vResult = ray.Getpos() + ray.Getdir() * _dist;
		vResult = m_arrVertexs[3].vPos +
			(_u *(m_arrVertexs[4].vPos - m_arrVertexs[3].vPos))
			+ (_v *(m_arrVertexs[5].vPos - m_arrVertexs[3].vPos));
	}

	return vResult;
}

Rect::Rect()
	: m_vPos(0, 0, 0)
	, m_vRot(0, 0, 0)
	, m_vScale(1, 1, 1)
	, m_pCullSphere(NULL)
	, m_fRadius(1.0f)
{
	D3DXMatrixIdentity(&m_mTM);
	D3DXMatrixIdentity(&m_mTrans);
	D3DXMatrixIdentity(&m_mRot);
	D3DXMatrixIdentity(&m_mScale);
}


Rect::~Rect()
{
	Release();
}
