#include "stdafx.h"
#include "myTexture.h"
#include "UIPlane.h"


void UIPlane::Init(float _x, float _y)
{
	m_vPos.x = _x;
	m_vPos.y = _y;
	m_vPos.z = 1.0f;

	D3DFVF_XYZ_TEX1 _Vertexs[] =
	{
		{ D3DXVECTOR3(0, 0, 0), 0, 0},
		{ D3DXVECTOR3(1, 0, 0), 1, 0 },
		{ D3DXVECTOR3(0, 1, 0), 0, 1 },
		{ D3DXVECTOR3(1, 1, 0), 1, 1 },
	};

	DEVICE->CreateVertexBuffer(
		sizeof(_Vertexs),
		0,
		D3DFVF_XYZ_TEX1::FVF,
		D3DPOOL_DEFAULT,
		&m_pVB, NULL);

	void* pData = NULL;
	m_pVB->Lock(0, sizeof(_Vertexs), &pData, 0);
	memcpy(pData, _Vertexs, sizeof(_Vertexs));
	m_pVB->Unlock();

	m_pTexture = TEXMGR->GetTexture("UI/collmap.bmp");
}

void UIPlane::Update(float dTime)
{
	D3DXMatrixScaling(&m_mScale,
		(float)m_pTexture->GetWidth(),
		(float)m_pTexture->GetHight(),
		1.0);
	D3DXMatrixTranslation(&m_mTrans,
		m_vPos.x, m_vPos.y, m_vPos.z);

	m_mTM = m_mScale * m_mTrans;
}

void UIPlane::Render(void)
{
 	DEVICE->SetRenderState(D3DRS_ALPHABLENDENABLE, true);
 	DEVICE->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
 	DEVICE->SetRenderState(D3DRS_DESTBLEND, 
 								D3DBLEND_INVSRCALPHA);

	DEVICE->SetTransform(D3DTS_WORLD, &m_mTM);
	DEVICE->SetStreamSource(0, m_pVB, 0,
		sizeof(D3DFVF_XYZ_TEX1));
	DEVICE->SetFVF(D3DFVF_XYZ_TEX1::FVF);
	DEVICE->SetTexture(0, m_pTexture ?
		m_pTexture->GetTexture() : NULL);

	DEVICE->DrawPrimitive(D3DPT_TRIANGLESTRIP,
		0, 2);

	DEVICE->SetTexture(0, NULL);
}

void UIPlane::Release(void)
{
	SAFE_RELEASE(m_pVB);
}

UIPlane::UIPlane()
	: m_pVB(NULL)
	, m_pTexture(NULL)
	, m_vPos(0,0,0)
{
	D3DXMatrixIdentity(&m_mTrans);
	D3DXMatrixIdentity(&m_mTM);
	D3DXMatrixIdentity(&m_mScale);
}


UIPlane::~UIPlane()
{
	Release();
}
