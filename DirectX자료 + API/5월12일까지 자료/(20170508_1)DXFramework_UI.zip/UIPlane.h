#pragma once
class myTexture;
class UIPlane
{
	LPDIRECT3DVERTEXBUFFER9 m_pVB;
	myTexture*				m_pTexture;

	D3DXMATRIX				m_mTM;
	D3DXMATRIX				m_mScale;
	D3DXMATRIX				m_mTrans;

	D3DXVECTOR3				m_vPos;

public:
	void Init(float _x, float _y);
	void Update(float dTime);
	void Render(void);
	void Release(void);

public:
	UIPlane();
	virtual ~UIPlane();
};

