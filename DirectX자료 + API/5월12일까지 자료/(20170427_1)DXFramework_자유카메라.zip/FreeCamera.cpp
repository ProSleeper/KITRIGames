#include "stdafx.h"
#include "FreeCamera.h"


FreeCamera::FreeCamera()
	: m_vEye(0,0,0)
	, m_vLookat(0,0,0)
	, m_vOrgUp(0,1,0)
	, m_vUp(0,1,0)
	, m_vDir(0,0,0)
	, m_vHoriz(0,0,0)
	, m_fSpeed(0)
	, m_tangleY(0)
{
	D3DXMatrixIdentity(&m_mView);
	D3DXMatrixIdentity(&m_mProj);
}


FreeCamera::~FreeCamera()
{
	
}

void FreeCamera::Init(D3DXVECTOR3 eye, 
	D3DXVECTOR3 lookat, float speed)
{
	m_vEye = eye;
	m_vLookat = lookat;
	m_fSpeed = speed;

	// �ٶ󺸴� ���⺤��
	m_vDir = m_vLookat - m_vEye;
	D3DXVec3Normalize(&m_vDir, &m_vDir);

	// ������
	D3DXVec3Cross(&m_vHoriz, &m_vOrgUp, &m_vDir);
	D3DXVec3Normalize(&m_vHoriz, &m_vHoriz);

	// ������
	D3DXVec3Cross(&m_vUp, &m_vDir, &m_vHoriz);
	D3DXVec3Normalize(&m_vUp, &m_vUp);

	ViewTransform();
	ProjectionTransform();

	m_ptOrgMouse = GetClinetPoint();
}

void FreeCamera::Update(float dTime)
{
	if (INPUTMGR->GetKey('W'))
		MoveForward(dTime);
	if (INPUTMGR->GetKey('S'))
		MoveForward(-dTime);
	if (INPUTMGR->GetKey('A'))
		MoveHorizontal(-dTime);
	if (INPUTMGR->GetKey('D'))
		MoveHorizontal(dTime);
	if (INPUTMGR->GetKey('Q'))
		MoveUp(dTime);
	if (INPUTMGR->GetKey('E'))
		MoveUp(-dTime);


	//  ȸ��
	POINT ptCurrent = GetClinetPoint();

	int _x = ptCurrent.x - m_ptOrgMouse.x;
	int _y = ptCurrent.y - m_ptOrgMouse.y;

	RotateX(_y / 100.0f);
	RotateY(_x / 100.0f);

	m_ptOrgMouse = ptCurrent;
}

void FreeCamera::MoveForward(float dTime)
{
	m_vEye += m_vDir * m_fSpeed * dTime;
	m_vLookat += m_vDir * m_fSpeed * dTime;

	ViewTransform();
}

void FreeCamera::MoveHorizontal(float dTime)
{
	m_vEye += m_vHoriz * m_fSpeed * dTime;
	m_vLookat += m_vHoriz * m_fSpeed * dTime;

	ViewTransform();
}

void FreeCamera::MoveUp(float dTime)
{
	m_vEye += m_vOrgUp * m_fSpeed * dTime;
	m_vLookat += m_vOrgUp * m_fSpeed * dTime;

	ViewTransform();
}

void FreeCamera::RotateX(float angle)
{
	D3DXMATRIX mRot;
	//D3DXMatrixRotationX(&mRot, angle);
	D3DXMatrixRotationAxis(&mRot, &m_vHoriz, angle);
	D3DXVec3TransformNormal(&m_vDir, &m_vDir, &mRot);
	D3DXVec3TransformNormal(&m_vUp, &m_vUp, &mRot);

	m_vLookat = m_vEye + m_vDir * 10.0f;
	ViewTransform();
}

void FreeCamera::RotateY(float angle)
{
	D3DXMATRIX mRot;
	D3DXMatrixRotationY(&mRot, angle);
	D3DXVec3TransformNormal(&m_vDir, &m_vDir, &mRot);
	//D3DXVec3TransformNormal(&m_vHoriz, &m_vHoriz, &mRot);
	D3DXVec3Cross(&m_vHoriz, &m_vOrgUp, &m_vDir);

	m_vLookat = m_vEye + m_vDir * 10.0f;
	ViewTransform();
}

void FreeCamera::ViewTransform(void)
{
	D3DXMatrixLookAtLH(&m_mView,
		&m_vEye, &m_vLookat, &m_vOrgUp);
	DEVICE->SetTransform(D3DTS_VIEW, &m_mView);
}

void FreeCamera::ProjectionTransform(void)
{
	D3DXMatrixPerspectiveFovLH(&m_mProj,
		D3DX_PI / 4,
		(float)DXMGR->GetWidth() / DXMGR->GetHeight(),
		1.0f, 1000.0f);
	DEVICE->SetTransform(D3DTS_PROJECTION, &m_mProj);
}
