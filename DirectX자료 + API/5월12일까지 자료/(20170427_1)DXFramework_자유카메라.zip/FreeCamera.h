#pragma once
class FreeCamera
{
	D3DXVECTOR3		m_vEye;
	D3DXVECTOR3		m_vLookat;
	D3DXVECTOR3		m_vUp;

	GETTER(D3DXVECTOR3, Dir,	m_vDir);
	GETTER(D3DXVECTOR3, Horiz,		m_vHoriz);
	GETTER(D3DXVECTOR3, OrgUp,		m_vOrgUp);

	float			m_fSpeed;

	D3DXMATRIX		m_mView;
	D3DXMATRIX		m_mProj;

	POINT			m_ptOrgMouse;

	float			m_tangleY;

public:
	void Init(D3DXVECTOR3 eye, D3DXVECTOR3 lookat,
		float speed);
	void Update(float dTime);
	void MoveForward(float dTime);
	void MoveHorizontal(float dTime);
	void MoveUp(float dTime);

	void RotateX(float angle);
	void RotateY(float angle);

	void ViewTransform(void);
	void ProjectionTransform(void);

public:
	FreeCamera();
	virtual ~FreeCamera();
};

