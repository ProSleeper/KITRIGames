#include "DXCommon.h"
#include "WinCommon.h"
#include "NormalLine.h"

//===========================================================================//
//
// ����׿� ��ֶ��� ��¿�
//
//===========================================================================//

extern bool g_bNormalLine;

void NormalLineRender(NORMAILLINEINFO info)
{
	if( g_bNormalLine )
	{
		NORMALLINE line[2];

		D3DXVec3TransformCoord(&info.vPos, &info.vOrgPos, &info.mTM);
		line[0].vPos = info.vPos;
		line[1].vPos = info.vPos + info.vDir * info.Lenth;
		line[0].color = info.color;
		line[1].color = info.color;

		D3DXMATRIX	mWorld;	
		D3DXMatrixIdentity(&mWorld);
		g_pDevice->SetTransform(D3DTS_WORLD, &mWorld);
		g_pDevice->SetFVF(FVF_LINE);
		g_pDevice->DrawPrimitiveUP(D3DPT_LINELIST, 1, &line[0], sizeof(NORMALLINE));
	}
}
