#include "DXCommon.h"
#include "WinCommon.h"
#include "QuadTree.h"

QuadTree::QuadTree(int vX, int vY)
{
	m_iVertexX	= vX;
	m_iVertexZ	= vY;
}

QuadTree::~QuadTree(void)
{
	ReleaseQuadTree();
}

//
// ���� Ʈ�� ����
//
void QuadTree::QuadCreate( D3DFVF_XYZ_NORMAL_TEX2* pVertexTerrain, int level )
{
	// ����
	m_iMaxLevel	= level;

	// �ֻ��� Ʈ�� ����
	QuadTreeNode* pNode = new QuadTreeNode(m_iVertexX, m_iVertexZ);
	m_pTop				= pNode;

	m_pTop->CreateNode( pVertexTerrain, m_pTop->m_nCorner, m_iMaxLevel, 0,  NULL);
	m_pTop->CreateChild();
}

//
// ���� ��� ã��
//
bool QuadTree::FindQuadNode( D3DXVECTOR3 pos, float radius, TERRAINQUADINFO info, GetIndexFunc pFun)
{
	return m_pTop->IsIn( pos, radius, info, pFun );
}

void QuadTree::ReleaseQuadTree( void )
{
	m_pTop->ReleaseNode();

	SAFE_DELETE(m_pTop);
}