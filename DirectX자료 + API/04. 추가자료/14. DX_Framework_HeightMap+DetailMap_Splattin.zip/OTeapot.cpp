#include "DXCommon.h"
#include "WinCommon.h"
#include "DXTerrain.h"
#include "OTeapot.h"

extern DXTerrain*					g_pTerrain;

OTeapot::OTeapot(void)
{
	m_vDir			= D3DXVECTOR3(1,0,0);
	m_vPos			= D3DXVECTOR3(0,1,0);
	m_vRot			= D3DXVECTOR3(0,0,0);
	m_vScale		= D3DXVECTOR3(0.5,0.5,0.5);

	m_vOrgDir		= m_vDir;

	D3DXMatrixIdentity(&m_mTM);
	D3DXMatrixIdentity(&m_mTrans);
	D3DXMatrixIdentity(&m_mRot);
	D3DXMatrixIdentity(&m_mScale);
}

OTeapot::~OTeapot(void)
{
	ReleaseObject();
}

void OTeapot::InitObject( void )
{
	D3DXCreateTeapot(g_pDevice, &m_pTeapot, NULL);	
}

void OTeapot::UpdateObject( float dTime )
{
	D3DXVec3TransformNormal(&m_vDir, &m_vOrgDir, &m_mRot);

	if( KeyDown(DIK_LEFT) )
		m_vRot.y -= 2.0f * dTime;
	if( KeyDown(DIK_RIGHT) )
		m_vRot.y += 2.0f * dTime;
	if( KeyDown(DIK_UP) )
		m_vPos += 2.0f * m_vDir * dTime;
	if( KeyDown(DIK_DOWN) )
		m_vPos -= 2.0f * m_vDir * dTime;

	m_vPos.y = g_pTerrain->GetTerrainHeight(m_vPos) + 0.4f;

	D3DXMatrixScaling(&m_mScale, m_vScale.x, m_vScale.y, m_vScale.z);
	D3DXMatrixRotationYawPitchRoll(&m_mRot, m_vRot.y, m_vRot.x, m_vRot.z);
	D3DXMatrixTranslation(&m_mTrans, m_vPos.x, m_vPos.y, m_vPos.z);

	m_mTM = m_mScale * m_mRot * m_mTrans;
}

void OTeapot::RenderObject( void )
{
	D3DMATERIAL9 m;
	ZeroMemory(&m, sizeof(m));
	m.Diffuse = m.Ambient = D3DXCOLOR(1, 0, 0, 1);
	g_pDevice->SetMaterial(&m);
	g_pDevice->SetTexture(0, NULL);
	g_pDevice->SetRenderState(D3DRS_LIGHTING, TRUE);	 
	g_pDevice->SetTransform(D3DTS_WORLD, &m_mTM); 

	m_pTeapot->DrawSubset(0);
}

void OTeapot::ReleaseObject( void )
{
	SAFE_RELEASE(m_pTeapot);
}