#pragma once

class CameraFPS : public Camera
{
public:
	void _KeyControl(float dTime);
	void _RotateX(float angle);
	void _RotateY(float angle);

	void _MoveX(float move);
	void _MoveY(float move);
	void _MoveZ(float move);

public:
	CameraFPS(CAMERAINFO info);
	virtual ~CameraFPS(void);
};
