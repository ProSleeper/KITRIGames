#pragma once

class CameraFree : public Camera
{
public:
	void _KeyControl(float dTime);

public:
	CameraFree(CAMERAINFO info);
	virtual ~CameraFree(void);
};
