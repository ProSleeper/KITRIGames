#include "DXCommon.h"
#include "WinCommon.h"
#include "QuadTreeNode.h"

int QuadTreeNode::m_iTotalNodeCount = 0;
int QuadTreeNode::m_iVertexX = 0;
int QuadTreeNode::m_iVertexZ = 0;

QuadTreeNode::QuadTreeNode(int vX, int vY)
{
	m_pParentNode	= NULL;
	m_iVertexX		= vX;
	m_iVertexZ		= vY;

	for( int i = 0; i < 4; i++ )
		m_pChildNodeList[i] = NULL;

	// �ε��� ��ȣ ����
	m_nCorner[QT_LT]	= 0;
	m_nCorner[QT_RT]	= vX - 1;
	m_nCorner[QT_LB]	= vX * (vY - 1);
	m_nCorner[QT_RB]	= vX * vY - 1;
	m_nCorner[QT_CN]	= (m_nCorner[QT_LT] + m_nCorner[QT_RT] 
							+m_nCorner[QT_LB] + m_nCorner[QT_RB] ) / 4;
}

QuadTreeNode::QuadTreeNode(void)
{
	m_pParentNode	= NULL;

	for( int i = 0; i < 4; i++ )
		m_pChildNodeList[i] = NULL;
}

QuadTreeNode::~QuadTreeNode(void)
{
}

void QuadTreeNode::CreateNode( D3DFVF_XYZ_NORMAL_TEX2* pVertexTerrain, int corner[5], int maxLevel, int currLevel, QuadTreeNode* pParent )
{
	m_pVertexTerrain	= pVertexTerrain;

	m_nCorner[QT_LT]	= corner[QT_LT];
	m_nCorner[QT_RT]	= corner[QT_RT];
	m_nCorner[QT_LB]	= corner[QT_LB];
	m_nCorner[QT_RB]	= corner[QT_RB];
	m_nCorner[QT_CN]	= (m_nCorner[QT_LT] + m_nCorner[QT_RT] 
							+m_nCorner[QT_LB] + m_nCorner[QT_RB] ) / 4;

	m_iMaxLevel			= maxLevel;
	m_iLevel			= currLevel;
	m_pParentNode		= pParent;

	m_iTotalNodeCount++;
}

void QuadTreeNode::CreateChild( void )
{
	//           QT_LT      QT_RT
	//              0---------1
	//              |		  |
	//              |  QT_CN  |
	//              |         |
	//              2---------3
	//			 QT_LB      QT_RB


	// �ε��� ����
	int idxSp	= m_nCorner[QT_LT];
	int idxW	= (m_nCorner[QT_RT] - m_nCorner[QT_LT]) / 2;
	int idxH	= idxW;
	
	int			nCorner[QT_MAX];
	int			idx = 0;

	for( int j = 0; j < 2; ++j )
	{
		for( int i = 0; i < 2; ++i )
		{
			// �ε���
			int	StartIdx	= idxSp + ((j*idxH) * (m_iVertexX)) + idxW * i;
			nCorner[QT_LT]	= StartIdx;
			nCorner[QT_RT]	= StartIdx + idxW;
			nCorner[QT_LB]	= StartIdx + (idxH * m_iVertexX);
			nCorner[QT_RB]	= StartIdx + (idxH * m_iVertexX) + idxW;


			// �ڽĳ�� ���
			m_pChildNodeList[idx] = new QuadTreeNode();

			m_pChildNodeList[idx]->CreateNode(m_pVertexTerrain, nCorner, m_iMaxLevel, m_iLevel+1, this);

			// ���������� �ִٸ� ���ȣ��
			if( m_iLevel + 1 < m_iMaxLevel )
				m_pChildNodeList[idx]->CreateChild();

			idx++;
		}
	}
}


//
// ��ġ�� ���� ��� ���� �˻�
//
QuadTreeNode* QuadTreeNode::IsIn( D3DXVECTOR3 pos )
{
	QuadTreeNode* pNode = NULL;

	// ���� �ȿ� �ִٸ�
	if( (pos.x >= m_pVertexTerrain[m_nCorner[QT_LT]].vPos.x 
		&&  pos.x <= m_pVertexTerrain[m_nCorner[QT_RT]].vPos.x ) &&

		(pos.z >= m_pVertexTerrain[m_nCorner[QT_LB]].vPos.z 
		&&  pos.z <= m_pVertexTerrain[m_nCorner[QT_LT]].vPos.z )
		)
	{	
		for( int i = 0; i < 4; ++i )
		{
			if( m_pChildNodeList[i] == NULL )
				continue;

			pNode = m_pChildNodeList[i]->IsIn(pos);

			if( pNode )
				return pNode;
		}

		return this;
	}
	
	return pNode;
}

void QuadTreeNode::ReleaseNode( void )
{
	for( int i = 0; i < 4; i++ )
	{
		if( !m_pChildNodeList[i] )
			continue;

		m_pChildNodeList[i]->ReleaseNode();

		SAFE_DELETE(m_pChildNodeList[i]);
	}
}