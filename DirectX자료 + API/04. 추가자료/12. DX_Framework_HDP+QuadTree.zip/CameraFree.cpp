#include "WinCommon.h"
#include "DXCommon.h"
#include "Camera.h"
#include "CameraFree.h"

CameraFree::CameraFree(CAMERAINFO info) : Camera(info)
{
}

CameraFree::~CameraFree(void)
{
}

void CameraFree::_KeyControl( float dTime )
{
	// ȸ��
	LONG x, y, z;
	float fac = 0.003f;
	GetMouseRelativePt(&x, &y, &z);
	_RotateY(x * fac);
	_RotateX(y * fac);

	// �̵�
	static float fMove = 0.0f;
	fMove = dTime * 10.0f;

	if( KeyDown(DIK_A) )
		_MoveX(-fMove);
	if( KeyDown(DIK_D) )
		_MoveX(fMove);
	if( KeyDown(DIK_W) )
		_MoveZ(fMove);
	if( KeyDown(DIK_S) )
		_MoveZ(-fMove);
	if( KeyDown(DIK_Q) )
		_MoveY(fMove);
	if( KeyDown(DIK_E) )
		_MoveY(-fMove);
}