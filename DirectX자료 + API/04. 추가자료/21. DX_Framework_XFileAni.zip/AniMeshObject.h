#pragma once

#define anikeyinterval 150

class AniMeshObject
{
public:
	LPD3DXFRAME							m_pFrameRoot;
	LPD3DXANIMATIONCONTROLLER			m_pAnimController;

	// ��ũ�� ��� ���� �ִ� ����
	int									m_iMaxBones;
	D3DXMATRIX*							m_pmBones;

	ANIMATION							m_Animation;
	float								m_fCurrFrame;
	

public:
	D3DXMATRIX							m_mTM;
	D3DXMATRIX							m_mTrans, m_mRot, m_mScale;
	D3DXMATRIX							m_mInvRot;
	D3DXVECTOR3							m_vPos, m_vScale, m_vRot;
	
public:
	void Load(char* fileName);
	void PathDivision(char* name, char* path, char* rname);
	void SetupBoneMatrices( D3DXFRAME_EXTENDED *pFrame );
	void UpdateFrameMatrices( const D3DXFRAME* pFrameRoot, const D3DXMATRIX* pParentMatrix );
	void UpdateSkinnedMesh( const D3DXFRAME *frameBase );
	void RenderFrame(LPD3DXFRAME frame, LPD3DXMATRIX pMatrix);
	void RenderMeshContainer(LPD3DXMESHCONTAINER meshContainerBase, LPD3DXFRAME frameBase, LPD3DXMATRIX pMatrix);
	LPD3DXANIMATIONCONTROLLER CloneAniController();

	void Update(float dTime);
	void Render(void);
	void Release(void);

public:
	AniMeshObject(void);
	virtual ~AniMeshObject(void);
};
