#include "DXCommon.h"
#include "WinCommon.h"
#include "Camera.h"
#include "NormalLine.h"
#include "OTeapot.h"
#include "QuadTreeNode.h"
#include "QuadTree.h"
#include "DXTerrain.h"

extern bool								g_bLight;
extern D3DXVECTOR3						g_vDirection;
extern D3DXCOLOR						g_cAmbient;
extern D3DXCOLOR						g_cDiffuse;

extern Camera*							g_pCamera;
extern bool								g_bRenderHeightMap;
extern bool								g_bHeightNormal;
extern bool								g_bNormalLine;

extern bool								g_bLODCulling;
extern OTeapot							g_bTeapotObject;
 
DXTerrain::DXTerrain(void)
{
	m_iPatchCntX		= 0;
	m_iPatchCntZ		= 0;
	m_iVertexCntX		= 0;
	m_iVertexCntZ		= 0;
	m_iTotalVertexCnt	= 0;
	m_fPatchOffset		= 0.0f;

	m_pOrgVB			= NULL;	
	m_pOrgIB			= NULL;	

	m_pTerrainVB		= NULL;
	m_pTerrainIB		= NULL;

	//<�߰��ڵ�>
	m_pLODTerrainIB		= NULL;
	m_pLODIB			= NULL;
	m_iLODFaceCount		= 0;

	for( int i = 0; i < 3; i++ )
	{
		m_vWalkFace[i] = D3DXVECTOR3(0,0,0);
		m_vPickFace[i] = D3DXVECTOR3(0,0,0);
	}

	m_iPickFaceNum			= 0;
}

DXTerrain::~DXTerrain(void)
{
	ReleaseTerrain();
}

// ���� �ʱ�ȭ �Լ�
//
void DXTerrain::InitTerrain( TERRAININFO info)
{
	m_TerrainInfo		= info;

	// for���� ���������� �Լ��� ����
	for( int i = 0; i < TERRAININFO::TM_MAX; ++i )
		_LoadTexture(m_TerrainInfo.strTextureName[i], &m_TerrainInfo.pTextrue[i]);

	// ���̸� ���� ���
	_LoadHeightMapInfo();

	InitVB();
	InitIB();

	D3DXMatrixIdentity(&m_mTerrainTM);

	CreateNormal();
	UpdateNormal();

	// ��������
	ZeroMemory(&m_Material, sizeof(D3DMATERIAL9));
	m_Material.Diffuse	= D3DXCOLOR(1,1,1,1);
	m_Material.Ambient	= D3DXCOLOR(1,1,1,1);


	_QuadTreeCreate(7);
}

//
// ���ؽ� ���� ����
//
void DXTerrain::InitVB( void )
{
	m_iTotalVertexCnt	= m_iVertexCntX * m_iVertexCntZ;
	m_pOrgVB			= new D3DFVF_XYZ_NORMAL_TEX2[m_iTotalVertexCnt];

	// ��� ��ü ����
	m_pOrgNormal = new D3DXVECTOR3[ m_iTotalVertexCnt ]; 
	m_pHeightNormal = new D3DXVECTOR3[ m_iTotalVertexCnt ]; 

	ZeroMemory(m_pOrgVB, sizeof(D3DFVF_XYZ_NORMAL_TEX2) * m_iTotalVertexCnt);

	float startX = -(m_iPatchCntX * m_fPatchOffset / 2 );
	float startZ =  (m_iPatchCntZ * m_fPatchOffset / 2 );

	// ��Ʈ�� �ȼ� ���� ��
	D3DLOCKED_RECT		pixelRect;
	m_TerrainInfo.pTextrue[TERRAININFO::TM_HEIGHT]->LockRect(0, &pixelRect, NULL, D3DLOCK_READONLY);

	for( int j = 0; j < m_iVertexCntZ; ++j )
	{
		for( int i = 0; i < m_iVertexCntX; ++i )
		{
			int pos = j * m_iVertexCntX + i;

			D3DFVF_XYZ_NORMAL_TEX2& vertex = m_pOrgVB[pos];

			vertex.vPos.x = startX + ( i * m_fPatchOffset );
			vertex.vPos.y = 0;//_GetHeight(pixelRect, i, j);
			vertex.vPos.z = startZ - ( j * m_fPatchOffset );

			vertex.vNormal = D3DXVECTOR3(0, 1, 0);

			vertex.u = (float)i / m_iPatchCntX;
			vertex.v = (float)j / m_iPatchCntZ;

			vertex.u2 = (float)i;
			vertex.v2 = (float)j;
		}
	}

	// ��� �� �� ����
	m_TerrainInfo.pTextrue[TERRAININFO::TM_HEIGHT]->UnlockRect(0);

	if(FAILED(g_pDevice->CreateVertexBuffer( sizeof(D3DFVF_XYZ_NORMAL_TEX2) * m_iTotalVertexCnt, 0, FVF_XYZ_NORMAL_TEX2, D3DPOOL_MANAGED, &m_pTerrainVB, NULL)))	
		return; 

	D3DFVF_XYZ_NORMAL_TEX2* pVB = NULL;

	if(FAILED(m_pTerrainVB->Lock(0, NULL, (void**)&pVB, 0)))  
		return;	

	memcpy(pVB, m_pOrgVB, sizeof(D3DFVF_XYZ_NORMAL_TEX2) * m_iTotalVertexCnt);

	m_pTerrainVB->Unlock();
}

//
// �ε��� ���� ����
//
void DXTerrain::InitIB( void )
{
	m_iTotalFaceCnt	    = m_iPatchCntX * m_iPatchCntZ * 2;
	int size			= sizeof(D3DINDEX) * m_iTotalFaceCnt;
	m_pOrgIB			= new D3DINDEX[m_iTotalFaceCnt];

	//<�߰��ڵ�>
	m_pLODIB			=  new D3DINDEX[m_iTotalFaceCnt];

	ZeroMemory(m_pOrgIB, size);

	D3DINDEX* pIndex = m_pOrgIB;
	D3DINDEX  _index;

	for( int j = 0; j < m_iVertexCntZ - 1; ++j )
	{
		for( int i = 0; i <  m_iVertexCntX - 1; ++i )
		{
			if( j % 2 == 0 )
			{
				if( i % 2 == 0 )
				{
					_index._A = j * m_iVertexCntX + i;
					_index._B = j * m_iVertexCntX + i + 1;
					_index._C = (j+1) * m_iVertexCntX + i;

					*pIndex++ = _index;
					
					_index._A = (j+1) * m_iVertexCntX + i;
					_index._B = j * m_iVertexCntX + i + 1;
					_index._C = (j+1) * m_iVertexCntX + i + 1;

					*pIndex++ = _index;
									}
				else
				{
					_index._A = (j+1) * m_iVertexCntX + i;
					_index._B = j * m_iVertexCntX + i;
					_index._C = (j+1) * m_iVertexCntX + i + 1;

					*pIndex++ = _index;
					
					_index._A = j * m_iVertexCntX + i;
					_index._B = j * m_iVertexCntX + i + 1;
					_index._C = (j+1) * m_iVertexCntX + i + 1;

					*pIndex++ = _index;
				}
			}

			else
			{
				if( i % 2 == 0 )
				{
					_index._A = (j+1) * m_iVertexCntX + i;
					_index._B = j * m_iVertexCntX + i;
					_index._C = (j+1) * m_iVertexCntX + i + 1;

					*pIndex++ = _index;
					
					_index._A = j * m_iVertexCntX + i;
					_index._B = j * m_iVertexCntX + i + 1;
					_index._C = (j+1) * m_iVertexCntX + i + 1;

					*pIndex++ = _index;
				}
				else
				{
					_index._A = j * m_iVertexCntX + i;
					_index._B = j * m_iVertexCntX + i + 1;
					_index._C = (j+1) * m_iVertexCntX + i;

					*pIndex++ = _index;

					_index._A = (j+1) * m_iVertexCntX + i;
					_index._B = j * m_iVertexCntX + i + 1;
					_index._C = (j+1) * m_iVertexCntX + i + 1;

					*pIndex++ = _index;
				}
			}
		}
	}

	// �Ϲ� �ε��� ����
	if(FAILED(g_pDevice->CreateIndexBuffer( size, 0, D3DFMT_INDEX32, D3DPOOL_MANAGED, &m_pTerrainIB, NULL )))
		return;

	//<�߰��ڵ�>
	// LOD �ε��� ����
	if(FAILED(g_pDevice->CreateIndexBuffer( size, 0, D3DFMT_INDEX32, D3DPOOL_MANAGED, &m_pLODTerrainIB, NULL )))
		return;


	D3DINDEX*	pI;
	if(FAILED(m_pTerrainIB->Lock(0, size, (void**)&pI, 0)))  return;	
	memcpy(pI, m_pOrgIB, size);
	m_pTerrainIB->Unlock();
}

//
// ���̴� ���� 
//
void DXTerrain::UpdateTerrain( float dTime )
{
	if( g_bLODCulling )
		LODCulling();
}


//
// ���� ������
//
void DXTerrain::RenderTerrain( void )
{
	RenderTerrainTnL();
}

//
// TnL ���� ������
//
void DXTerrain::RenderTerrainTnL( void )
{
	g_pDevice->SetMaterial(&m_Material);

	g_pDevice->SetRenderState(D3DRS_LIGHTING, g_bLight);

	g_pDevice->SetStreamSource( 0, m_pTerrainVB, 0, sizeof(D3DFVF_XYZ_NORMAL_TEX2) );
	g_pDevice->SetFVF( FVF_XYZ_NORMAL_TEX2 );
	g_pDevice->SetTransform(D3DTS_WORLD, &m_mTerrainTM);

	if( g_bRenderHeightMap )
	{
		g_pDevice->SetTexture(0, m_TerrainInfo.pTextrue[TERRAININFO::TM_HEIGHT]);
	}
	else
	{
		g_pDevice->SetTexture(0, m_TerrainInfo.pTextrue[TERRAININFO::TM_DIFFUSE]);
		g_pDevice->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_MODULATE);
		g_pDevice->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_CURRENT);
		g_pDevice->SetTextureStageState(0, D3DTSS_COLORARG2, D3DTA_TEXTURE);
		g_pDevice->SetTextureStageState(0, D3DTSS_TEXCOORDINDEX, 0);
		
		// ������ �� 
		g_pDevice->SetTexture(1, m_TerrainInfo.pTextrue[TERRAININFO::TM_DIFFUSE]);
		g_pDevice->SetTextureStageState(1, D3DTSS_COLOROP, D3DTOP_MODULATE);
		g_pDevice->SetTextureStageState(1, D3DTSS_COLORARG1, D3DTA_CURRENT);
		g_pDevice->SetTextureStageState(1, D3DTSS_COLORARG2, D3DTA_TEXTURE);
		g_pDevice->SetTextureStageState(1, D3DTSS_TEXCOORDINDEX, 1);

		g_pDevice->SetSamplerState(1, D3DSAMP_ADDRESSU, D3DTADDRESS_MIRROR);	
		g_pDevice->SetSamplerState(1, D3DSAMP_ADDRESSV, D3DTADDRESS_MIRROR);

		// ��ǻ��
		g_pDevice->SetTextureStageState(2, D3DTSS_COLOROP, D3DTOP_MODULATE);
		g_pDevice->SetTextureStageState(2, D3DTSS_COLORARG1, D3DTA_CURRENT);
		g_pDevice->SetTextureStageState(2, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
	}
	

	//<�߰��ڵ�>
	g_pDevice->SetIndices( g_bLODCulling ? m_pLODTerrainIB : m_pTerrainIB );
	g_pDevice->DrawIndexedPrimitive( D3DPT_TRIANGLELIST, 0, 0, m_iTotalVertexCnt, 0, 
		g_bLODCulling ? m_iLODFaceCount : m_iTotalFaceCnt );


	g_pDevice->SetRenderState(D3DRS_LIGHTING, false);
	g_pDevice->SetSamplerState(1, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);		
	g_pDevice->SetSamplerState(1, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);
	g_pDevice->SetTextureStageState(1, D3DTSS_COLOROP, D3DTOP_DISABLE);
	g_pDevice->SetTextureStageState(0, D3DTSS_COLOROP,   D3DTOP_MODULATE);
	g_pDevice->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
	g_pDevice->SetTextureStageState(0, D3DTSS_COLORARG2, D3DTA_DIFFUSE);


	// ��ֶ���
	if( g_bNormalLine )
		RightLineDebugRender();
}



//
// �޸� ��ȯ �� ����
//
void DXTerrain::ReleaseTerrain( void )
{
	SAFE_DELETE_ARRAY(m_pOrgVB);
	SAFE_DELETE_ARRAY(m_pOrgIB);
	SAFE_RELEASE(m_pTerrainVB);
	SAFE_RELEASE(m_pTerrainIB);

	for( int i = 0; i < TERRAININFO::TM_MAX; ++i )
		SAFE_RELEASE(m_TerrainInfo.pTextrue[i]);

	SAFE_DELETE(m_pQuadTree);
}

// �ؽ��� �ε� �Լ�
//
void DXTerrain::_LoadTexture( char* name, LPDIRECT3DTEXTURE9* ppTexture )
{
	if( FAILED(D3DXCreateTextureFromFile(g_pDevice, name, ppTexture)) )
	{
		char Msg[256] = {0};
		sprintf(Msg, "Texture Load Failed.\n name:%s", name);
		MessageBox(NULL, Msg, "Error", MB_OK);
	}
}

// ���̸� ���� ��� �Լ�
void DXTerrain::_LoadHeightMapInfo( void )
{
	// �ؽ��� ���� ���
	D3DSURFACE_DESC	 sfInfo;
	m_TerrainInfo.pTextrue[TERRAININFO::TM_HEIGHT]->GetLevelDesc(0, &sfInfo);
	

	// �Ϲ������� ���̸� �ؽ����� ���
	// 2�� ����� ũ��� ���۵Ǿ�� ��.
	// ��, ���� ���� : ���̸� �ȼ� + 1
	// ����, ����Ʈ�� ����� ����

	// ��ġ����
	m_iPatchCntX		= sfInfo.Width;
	m_iPatchCntZ		= sfInfo.Height;
	m_fPatchOffset		= m_TerrainInfo.PatchOffset;

	// ��������
	m_iVertexCntX		= m_iPatchCntX + 1;
	m_iVertexCntZ		= m_iPatchCntZ + 1;

	// �� ���� ����
	m_iTotalVertexCnt	= m_iVertexCntX * m_iVertexCntZ;

	// �� ���̽� ����
	m_iTotalFaceCnt		= m_iPatchCntX * m_iPatchCntZ * 2;
}

// ���̸��� ���̰� ���
float DXTerrain::_GetHeight( D3DLOCKED_RECT& MapLock, int i, int j )
{
	float height = 0.0f;

	// ��Ʈ�� ���� �����̹Ƿ�
	// ���ü� �ִ� ���� 0 ~ 255 ����
	// ���� ũ�ٸ� ������ ���� �ʿ�
	int pos		= j * (MapLock.Pitch/4) + i;			// rgba 4����Ʈ ���
	DWORD pixel = ((DWORD*)MapLock.pBits)[pos];			// �ش���ġ�� �ȼ�
	height		= (pixel & 0x000000ff) / 20.0f;			// ������ ���� ����

	return height;
}

//
// ��ֶ��� �׸���
//
void DXTerrain::RightLineDebugRender( void )
{
	for( int i = 0; i < m_iTotalVertexCnt; ++i )
	{
		NORMAILLINEINFO info;
		ZeroMemory(&info, sizeof(NORMAILLINEINFO));

		info.color	= D3DXCOLOR(0,1,0,1);
		info.Lenth	= 0.5f;
		info.mTM	= m_mTerrainTM;
		info.vDir	= m_pOrgVB[i].vNormal;
		info.vPos	= m_pOrgVB[i].vPos;
		info.vOrgPos= info.vPos;
		NormalLineRender(info);
	}
}

void DXTerrain::CreateNormal( void )
{
	// �⺻���
	for( int i = 0; i < m_iTotalVertexCnt; i++ )
		m_pOrgNormal[i] = m_pOrgVB[i].vNormal;


	D3DXVECTOR3		vVec;
	for( int i = 0; i < m_iTotalFaceCnt; i++ )
	{
		int _0 = (int)m_pOrgIB[i]._A;
		int _1 = (int)m_pOrgIB[i]._B;
		int _2 = (int)m_pOrgIB[i]._C;

		D3DXVECTOR3 vTemp0 = m_pOrgVB[_1].vPos - m_pOrgVB[_0].vPos;
		D3DXVECTOR3 vTemp1 = m_pOrgVB[_2].vPos - m_pOrgVB[_0].vPos;

		// ���̽� ��� ���ϱ�
		D3DXVec3Cross(&vVec, &vTemp0, &vTemp1);

		// ���ߴٸ� �� 3���� ��ְ� ����
		m_pHeightNormal[_0] = m_pOrgNormal[_0] + vVec;
		m_pHeightNormal[_1] = m_pOrgNormal[_1] + vVec;
		m_pHeightNormal[_2] = m_pOrgNormal[_2] + vVec;

		D3DXVec3Normalize(&m_pHeightNormal[_0], &m_pHeightNormal[_0]);
		D3DXVec3Normalize(&m_pHeightNormal[_1], &m_pHeightNormal[_1]);
		D3DXVec3Normalize(&m_pHeightNormal[_2], &m_pHeightNormal[_2]);
	}
}	

void DXTerrain::UpdateNormal( void )
{
	DWORD size = m_iTotalVertexCnt * sizeof(D3DFVF_XYZ_NORMAL_TEX2);

	if( g_bHeightNormal )
	{
		for( int i = 0; i < m_iTotalVertexCnt; i++ )
			m_pOrgVB[i].vNormal = m_pHeightNormal[i];
	}
	else
	{
		for( int i = 0; i < m_iTotalVertexCnt; i++ )
			m_pOrgVB[i].vNormal = m_pOrgNormal[i];
	}

	D3DFVF_XYZ_NORMAL_TEX2* pVB = NULL;
	if(FAILED(m_pTerrainVB->Lock(0, NULL, (void**)&pVB, 0)))  
		return ;	

	memcpy(pVB, m_pOrgVB, size);
	m_pTerrainVB->Unlock();	
}


float DXTerrain::GetTerrainHeight( D3DXVECTOR3 pos )
{
	D3DXVECTOR3		vPos = pos + D3DXVECTOR3(0, 100, 0);	// ���� �浹(����Ʈ)�� ����� ��������
															// ���� ��ġ���� ���� ����
	D3DXVECTOR3		vDir = D3DXVECTOR3(0,-1,0);				// Ȯ�� ������ �Ʒ�

	return _FindFace(vPos, vDir, m_vWalkFace);
}


float DXTerrain::_FindFace( D3DXVECTOR3& vObjPos, D3DXVECTOR3& vObjDir, D3DXVECTOR3 Face[3], int* pPIckFaceNum )
{
	float		fHeight = 0.0f;
	float		fDist	= 0.0f;
	D3DXVECTOR3	vPos[3];

	//<�߰��ڵ�>
	//	LOD �ø� ���������� ���� ��ü ��ŷ�� �˻��Ͽ�����
	//  ���� �� �ø��� ������ �˻�
	int			iTotalFaceCnt	= g_bLODCulling ? m_iLODFaceCount : m_iTotalFaceCnt;
	D3DINDEX*	pOrgIB			= g_bLODCulling ? m_pLODIB : m_pOrgIB;

	for( int i = 0; i < iTotalFaceCnt; ++i )
	{
		// �ε��� ������ ���� ���� �ε��� ���
		int _VIdx1 = pOrgIB[i]._A;
		int _VIdx2 = pOrgIB[i]._B;
		int _VIdx3 = pOrgIB[i]._C;

		// ���ؽ� ���� ���
		vPos[0]	= m_pOrgVB[_VIdx1].vPos;
		vPos[1]	= m_pOrgVB[_VIdx2].vPos;
		vPos[2]	= m_pOrgVB[_VIdx3].vPos;

		float _u, _v;

		// DirectX �Լ��� ���� �浹�˻�
		// �浹�̶�� true
		if( D3DXIntersectTri(&vPos[0], &vPos[1], &vPos[2],
			&vObjPos, &vObjDir, &_u, &_v, &fDist) )
		{
			// �浹�̶��
			// ���ϵ� uv���� ���� ���� �� ����ó��
			fHeight = vPos[0].y + ( _u * (vPos[1].y - vPos[0].y) )
				+ ( _v * (vPos[2].y - vPos[0].y));

			// ȭ�� ��¿� �ﰢ��
			Face[0] = vPos[0];
			Face[1] = vPos[1];
			Face[2] = vPos[2];

			// ��ŷ�� �ﰢ�� �ε���
			if( pPIckFaceNum )
				*pPIckFaceNum = i;

			break;
		}
	}

	return fHeight;
}




//
// ���� Ʈ�� ����
//
void DXTerrain::_QuadTreeCreate( int quadLevel )
{
	//           QT_LT      QT_RT
	//              0---------1
	//              |		  |
	//              |  QT_CN  |
	//              |         |
	//              2---------3
	//			 QT_LB      QT_RB

	// ���� ��ġ ���ϱ�(�𵨰���) //
	float _x = -(m_iPatchCntX * m_fPatchOffset / 2);
	float _z =  (m_iPatchCntZ * m_fPatchOffset / 2);
	float _w =  (m_iPatchCntX * m_fPatchOffset    );
	float _h =  (m_iPatchCntZ * m_fPatchOffset    );

	D3DXVECTOR3 vPos[QT_MAX];
	vPos[QT_LT]	= D3DXVECTOR3( _x,		0.0f,	_z		);	// ����   ��
	vPos[QT_RT]	= D3DXVECTOR3( _x+_w,	0.0f,	_z		);	// ������ ��
	vPos[QT_LB]	= D3DXVECTOR3( _x,		0.0f,	_z-_h	);	// ����   �Ʒ�
	vPos[QT_RB]	= D3DXVECTOR3( _x+_w,	0.0f,	_z-_h	);	// ������ �Ʒ�
	vPos[QT_CN]	= D3DXVECTOR3( _x+_w/2,	0.0f,	_z-_h/2	);	// ����(�߾�)

	// ���� Ʈ�� ����
	m_pQuadTree = new QuadTree(m_iVertexCntX, m_iVertexCntZ);
	m_pQuadTree->QuadCreate(m_pOrgVB, quadLevel);
}


//
// ��LOD �ø�
//
void DXTerrain::LODCulling( void )
{
	m_iLODFaceCount		= 0;
	ZeroMemory(m_pLODIB, sizeof(D3DINDEX) * m_iTotalFaceCnt);

	LOD_TERRAININFO LODInfo;
	LODInfo.iLODFaceCount = &m_iLODFaceCount;
	LODInfo.pLODIB		  = m_pLODIB;
	LODInfo.pVertexTerrain= m_pOrgVB;
	LODInfo.vPos		  = g_bTeapotObject.m_vPos;

	m_pQuadTree->LOD_Culling(LODInfo);

	// �ø��� �ε������۷� �籸��
	D3DINDEX* pIB;
	int size = sizeof(D3DINDEX) * m_iLODFaceCount;

	m_pLODTerrainIB->Lock(0, NULL, (void**)&pIB, 0);
	memcpy(pIB, m_pLODIB, size);
	m_pLODTerrainIB->Unlock();
}
