#include "WinCommon.h"
#include "DXCommon.h"
#include "Camera.h"
#include "CameraFPS.h"

CameraFPS::CameraFPS(CAMERAINFO info) : Camera(info)
{
}

CameraFPS::~CameraFPS(void)
{
}

void CameraFPS::_KeyControl( float dTime )
{
	// ȸ��
	LONG x, y, z;
	float fac = 0.003f;
	GetMouseRelativePt(&x, &y, &z);
	_RotateY(x * fac);
	_RotateX(y * fac);

	// �̵�
	static float fMove = 0.0f;
	fMove = dTime * 10.0f;

	if( KeyDown(DIK_A) )
		_MoveX(-fMove);
	if( KeyDown(DIK_D) )
		_MoveX(fMove);
	if( KeyDown(DIK_W) )
		_MoveZ(fMove);
	if( KeyDown(DIK_S) )
		_MoveZ(-fMove);
}

void CameraFPS::_RotateX( float angle )
{
	D3DXMatrixRotationAxis(&m_mRot, &m_vHorz, angle);
	D3DXVec3TransformNormal(&m_vNView, &m_vNView, &m_mRot);
	D3DXVec3Cross(&m_vUp, &m_vNView, &m_vHorz);

	m_vLookAt = m_vEye + m_vNView * 10.0f;

	_SetView();
}

void CameraFPS::_RotateY( float angle )
{
	D3DXMatrixRotationAxis(&m_mRot, &m_vOrgUp, angle);	// ī�޶� �� ȸ��
	D3DXVec3TransformNormal(&m_vNView, &m_vNView, &m_mRot);
	D3DXVec3Cross(&m_vHorz, &m_vOrgUp, &m_vNView);

	m_vLookAt = m_vEye + m_vNView * 10.0f;

	_SetView();
}

void CameraFPS::_MoveX( float move )
{
	D3DXVECTOR3 vMove;
	D3DXVec3Normalize(&vMove, &m_vHorz);

	vMove = vMove * move;

	m_vEye		+= vMove;
	m_vLookAt	+= vMove;

	_SetView();
}

void CameraFPS::_MoveY( float move )
{
	D3DXVECTOR3 vMove;
	D3DXVec3Normalize(&vMove, &m_vUp);

	vMove = vMove * move;

	m_vEye		+= vMove;
	m_vLookAt	+= vMove;

	_SetView();
}

void CameraFPS::_MoveZ( float move )
{
	D3DXVECTOR3 vMove;
	D3DXVec3Normalize(&vMove, &m_vNView);

	vMove.y = 0.0f;

	vMove = vMove * move;

	m_vEye		+= vMove;
	m_vLookAt	+= vMove;

	_SetView();
}